document.writeln("<script type=\"text/javascript\">");
document.writeln("    /*960*60 创建于 2014-11-08*/");
document.writeln("    var cpro_id = \"u1798161\";");
document.writeln("</script>");
document.writeln("<script src=\"http://cpro.baidustatic.com/cpro/ui/c.js\" type=\"text/javascript\"></script>");