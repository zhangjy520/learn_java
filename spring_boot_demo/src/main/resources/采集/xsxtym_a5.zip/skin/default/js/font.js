function TplTextSelect(){
	document.writeln("	<div id=\"TextSelect\">");
	document.writeln("	<div class=\"ts1\">");
	document.writeln("	<span>选择背景颜色：<\/span><a href=\"javascript:void(0)\" onclick=\"SetBgColor(\'#dcecf5\')\"><img");
	document.writeln("	src=\"\/skin/default/images\/icon01.gif\" width=\"15\" height=\"18\" border=\"0\"");
	document.writeln("	alt=\"\" \/><\/a> <a href=\"javascript:void(0)\" onclick=\"SetBgColor(\'#e7f4fe\')\">");
	document.writeln("	<img src=\"\/skin/default/images\/icon02.gif\" width=\"15\" height=\"18\" border=\"0\"");
	document.writeln("	alt=\"\" \/><\/a> <a href=\"javascript:void(0)\" onclick=\"SetBgColor(\'#edf6d0\')\">");
	document.writeln("	<img src=\"\/skin/default/images\/icon03.gif\" width=\"15\" height=\"18\" border=\"0\"");
	document.writeln("	alt=\"\" \/><\/a> <a href=\"javascript:void(0)\" onclick=\"SetBgColor(\'#f5f1e7\')\">");
	document.writeln("	<img src=\"\/skin/default/images\/icon04.gif\" width=\"15\" height=\"18\" border=\"0\"");
	document.writeln("	alt=\"\" \/><\/a> <a href=\"javascript:void(0)\" onclick=\"SetBgColor(\'#eae8f7\')\">");
	document.writeln("	<img src=\"\/skin/default/images\/icon05.gif\" width=\"15\" height=\"18\" border=\"0\"");
	document.writeln("	alt=\"\" \/><\/a> <a href=\"javascript:void(0)\" onclick=\"SetBgColor(\'#fef4f0\')\">");
	document.writeln("	<img src=\"\/skin/default/images\/icon06.gif\" width=\"15\" height=\"18\" border=\"0\"");
	document.writeln("	alt=\"\" \/><\/a> <a href=\"javascript:void(0)\" onclick=\"SetBgColor(\'#ebf4ef\')\">");
	document.writeln("	<img src=\"\/skin/default/images\/icon07.gif\" width=\"15\" height=\"18\" border=\"0\"");
	document.writeln("	alt=\"\" \/><\/a> <a href=\"javascript:void(0)\" onclick=\"SetBgColor(\'#fafafa\')\">");
	document.writeln("	<img src=\"\/skin/default/images\/icon08.gif\" width=\"15\" height=\"18\" border=\"0\"");
	document.writeln("	alt=\"\" \/><\/a>");
	document.writeln("	<\/div>");
	document.writeln("	<div class=\"ts2\">");
	document.writeln("	<span>选择字体：<\/span><a href=\"javascript:void(0)\" onclick=\"SetfontSize(17)\"><img src=\"\/skin/default/images\/icon09.gif\"");
	document.writeln("	width=\"21\" height=\"21\" border=\"0\" alt=\"\" \/><\/a> <a href=\"javascript:void(0)\" onclick=\"SetfontSize(12)\">");
	document.writeln("	<img src=\"\/skin/default/images\/icon10.gif\" width=\"21\" height=\"21\" border=\"0\"");
	document.writeln("	alt=\"\" \/><\/a> <a href=\"javascript:void(0)\" onclick=\"SetfontSize(10)\">");
	document.writeln("	<img src=\"\/skin/default/images\/icon11.gif\" width=\"21\" height=\"21\" border=\"0\"");
	document.writeln("	alt=\"\" \/><\/a><\/div>");
	document.writeln("	<div class=\"ts3\">");
	document.writeln("	<span>滚动速度：<\/span><a href=\"javascript:void(0)\" onclick=\"SetSpeed(1)\"><img src=\"\/skin/default/images\/icon12.gif\"");
	document.writeln("	width=\"21\" height=\"21\" border=\"0\" alt=\"\" \/><\/a> <a href=\"javascript:void(0)\" onclick=\"SetSpeed(20)\">");
	document.writeln("	<img src=\"\/skin/default/images\/icon13.gif\" width=\"21\" height=\"21\" border=\"0\"");
	document.writeln("	alt=\"\" \/><\/a> <a href=\"javascript:void(0)\" onclick=\"SetSpeed(40)\">");
	document.writeln("	<img src=\"\/skin/default/images\/icon14.gif\" width=\"21\" height=\"21\" border=\"0\"");
	document.writeln("	alt=\"\" \/><\/a><\/div>");
	document.writeln("	<div class=\"ts4\"><a href=\"javascript:void(0)\" onclick=\"YaHei()\">雅黑字体<\/a>&nbsp;&nbsp;<a");
	document.writeln("	href=\"javascript:void(0)\" onclick=\"SetDefault()\">默认字体<\/a>&nbsp;&nbsp;<a href=\"javascript:void(0)\" ");
	document.writeln("	onclick=\"SetFont()\">设置字体<\/a>&nbsp;&nbsp;<a href=\"javascript:void(0)\" ");
	document.writeln("	onclick=\"CopyText()\">复制内容<\/a>&nbsp;&nbsp;<a href=\"javascript:void(0)\" ");
	document.writeln("	onclick=\"FormatText()\">自动排版<\/a><\/div>");
	document.writeln("	<\/div>");
}
// ---
function CopyText() {
	var ttx = m(document.getElementById("booktext").innerHTML);
	ttx = tbooktitle + " " + tcptitle + "\r\n\r\n" + location.href + "\r\n\r\n" + ttx + "\r\n\r\n" + location.href;
	window.clipboardData.setData("text",ttx);
	alert("章节内容已经复制到剪贴板 ^_^");
}
function FormatText()
{
	var body = document.getElementById("booktext").innerText;
        body = m(body);
        document.getElementById("booktext").innerText = body;
}
function m(key){
	var str = key;
	var reStr;
	//去掉一些非法字符，如空格，制表符等等
	reStr = /[\f\t\v　 ]/ig;
	str = str.replace(reStr,"");
	
	//将带有1个或多个的回车换行符替换成1个回车换行+4个空格
	reStr = /(\r\n){1,}/ig;
	str = str.replace(reStr,"\r\n\r\n　　");
	
	//去掉开头的回车换行以及空白字符
	reStr = /^\s*/ig;
	str = str.replace(reStr,"");
	
	//去掉结尾的回车换行以及空白字符
	reStr = /\s*$/ig;
	str = str.replace(reStr,"");
	
	reStr = /<BR>/ig;
	str = str.replace(reStr,"\r\n");

	reStr = /&nbsp;|<!--go-->|<!--over-->/ig;
	str = str.replace(reStr,"");
	//首位加4个空格
	return("　　"+str);
}
function GotoCpList(o) {
	//alert(o);
	location.href = o;
}
function isNum(s) {
	var pattern = /^\d+(\.\d+)?$/;
	return pattern.test(s)
}
var timer;
function StopScroll() {
	clearInterval(timer);
}
function BeginScroll() {
	timer = setInterval("Scrolling()", $.cookie("cp_speed_8x"));
}
function SetSpeed(o) {
	$.cookie("cp_speed_8x", o);
}
function Scrolling() {
	currentpos = document.documentElement.scrollTop;
	window.scroll(0, ++currentpos);
	if (currentpos != document.documentElement.scrollTop) {
		clearInterval(timer);
	}
}
function LoadUserPro() {
	if ($.cookie("cp_speed_8x") == false) {
		SetSpeed(20);
	} else {
		SetSpeed($.cookie("cp_speed_8x"));
	}
	if ($.cookie("cp_fontsize_8x") == false) {
		SetfontSize(12);
	} else {
		SetfontSize($.cookie("cp_fontsize_8x"));
	}
	if ($.cookie("cp_bg_8x") == false) {
		SetBgColor("#FAFAFA");
	} else {
		SetBgColor($.cookie("cp_bg_8x"));
	}
	if ($.cookie("cp_fontFamily_8x") != false) {
		document.getElementById("booktext").style.fontFamily = $.cookie("cp_fontFamily_8x");
	}
}
function SetfontSize(o) {
	var Divs = document.getElementById("booktext");
	if (Divs != null) {
		Divs.style.fontSize = o + "pt";
	}
	$.cookie("cp_fontsize_8x", o);
}
function SetBgColor(o) {
	document.getElementById("bgdiv").style.backgroundColor = o;
	$.cookie("cp_bg_8x", o);
}
function SetFont() {
	var tempA = window.prompt("请输入您喜欢的字体,默认为微软雅黑,如果不存在则为宋体.", "微软雅黑");
	if (tempA == "") {
		tempA = "微软雅黑";
	}
	document.getElementById("booktext").style.fontFamily = tempA;
	$.cookie("cp_fontFamily_8x", tempA);
	tempA = window.prompt("请输入字体大小,默认为 12PX .", "12");
	if (tempA == "" || !isNum(tempA)) {
		tempA = 12;
	}
	SetfontSize(tempA);
}
function SetDefault() {
	SetSpeed(20);
	SetfontSize(12);
	$.cookie("cp_fontFamily_8x", "宋体");
	document.getElementById("booktext").style.fontFamily = $.cookie("cp_fontFamily_8x");
}
function YaHei(){
	$.cookie("cp_fontFamily_8x", "微软雅黑");
	document.getElementById("booktext").style.fontFamily = $.cookie("cp_fontFamily_8x");
}

document.onmousedown = StopScroll;
document.ondblclick = BeginScroll;