// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PreferenceConstants.java

package com.fap.ide.preferences;


public class PreferenceConstants
{

    public PreferenceConstants()
    {
    }

    public static final String URL = "url";
    public static final String USER = "user";
    public static final String PASSWORD = "password";
    public static final String TOGETHER = "";
    public static final String PROJECT = "project";
    public static final String SOURCE_PATH_TABLE_MODEL = "tableModelPath";
    public static final String SOURCE_PATH_TABLE_API = "tableAPIPath";
    public static final String SOURCE_PATH_TABLE_XML = "tableXMLPath";
    public static final String SOURCE_PATH_PACKAGE_API = "packageAPIPath";
    public static final String SOURCE_PATH_PACKAGE_XML = "packageXMLPath";
    public static final String JDBC_PATH = "jdbcPath";
}
