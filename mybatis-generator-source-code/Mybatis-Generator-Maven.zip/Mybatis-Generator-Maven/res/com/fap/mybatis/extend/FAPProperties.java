// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FAPProperties.java

package com.fap.mybatis.extend;


public class FAPProperties
{

    public FAPProperties()
    {
    }

    public static String MAPPER_INTERFACE = "com.rrtx.fap.frame.jdbc.IFAPMybatisEntityMapper<V extends IFAPBean,K,S>";
    public static String MODEL_ROOT_CLASS = "com.rrtx.fap.frame.data.AbstractFAPBean";
    public static String ROWBOUND_TYPE = "com.rrtx.fap.frame.jdbc.FAPRowBounds";

}
