// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AbstractJavaMapperMethodGenerator.java

package org.mybatis.generator.codegen.mybatis3.javamapper.elements;

import org.mybatis.generator.api.dom.java.Interface;
import org.mybatis.generator.codegen.AbstractGenerator;

public abstract class AbstractJavaMapperMethodGenerator extends AbstractGenerator
{

    public abstract void addInterfaceElements(Interface interface1);

    public AbstractJavaMapperMethodGenerator()
    {
    }
}
