// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   IntrospectedTableIbatis2Java5Impl.java

package org.mybatis.generator.codegen.ibatis2;


// Referenced classes of package org.mybatis.generator.codegen.ibatis2:
//            IntrospectedTableIbatis2Java2Impl

public class IntrospectedTableIbatis2Java5Impl extends IntrospectedTableIbatis2Java2Impl
{

    public IntrospectedTableIbatis2Java5Impl()
    {
    }

    public boolean isJava5Targeted()
    {
        return true;
    }
}
