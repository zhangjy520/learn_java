// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Element.java

package org.mybatis.generator.api.dom.xml;


public abstract class Element
{

    public Element()
    {
    }

    public abstract String getFormattedContent(int i);
}
