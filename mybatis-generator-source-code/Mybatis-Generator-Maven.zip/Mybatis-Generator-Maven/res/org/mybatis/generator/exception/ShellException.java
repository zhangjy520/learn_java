// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ShellException.java

package org.mybatis.generator.exception;


public class ShellException extends Exception
{

    public ShellException()
    {
    }

    public ShellException(String arg0)
    {
        super(arg0);
    }

    public ShellException(String arg0, Throwable arg1)
    {
        super(arg0, arg1);
    }

    public ShellException(Throwable arg0)
    {
        super(arg0);
    }

    static final long serialVersionUID = 0xe3df365697a10410L;
}
