/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50713
Source Host           : localhost:3306
Source Database       : mooc_db

Target Server Type    : MYSQL
Target Server Version : 50713
File Encoding         : 65001

Date: 2016-12-02 14:26:19
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for db_versions
-- ----------------------------
DROP TABLE IF EXISTS `db_versions`;
CREATE TABLE `db_versions` (
  `installed_rank` int(11) NOT NULL,
  `version` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `script` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `checksum` int(11) DEFAULT NULL,
  `installed_by` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int(11) NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `db_versions_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of db_versions
-- ----------------------------
INSERT INTO `db_versions` VALUES ('1', '1.0.0', 'create table and init data', 'SQL', 'V1.0.0__create_table_and_init_data.sql', '-1978359536', 'root', '2016-11-24 11:59:18', '12868', '1');
INSERT INTO `db_versions` VALUES ('2', '1.0.1', 'alter table edu course kpoint and init data', 'SQL', 'V1.0.1__alter_table_edu_course_kpoint_and_init_data.sql', '626894287', 'root', '2016-11-24 11:59:20', '2008', '1');
INSERT INTO `db_versions` VALUES ('3', '1.0.2', 'alter table edu course kpoint and init data', 'SQL', 'V1.0.2__alter_table_edu_course_kpoint_and_init_data.sql', '-417663390', 'root', '2016-11-24 11:59:20', '21', '0');

-- ----------------------------
-- Table structure for edu_article
-- ----------------------------
DROP TABLE IF EXISTS `edu_article`;
CREATE TABLE `edu_article` (
  `ARTICLE_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '文章ID',
  `TITLE` varchar(100) DEFAULT NULL COMMENT '文章标题',
  `SUMMARY` varchar(200) DEFAULT NULL COMMENT '文章摘要',
  `KEY_WORD` varchar(50) DEFAULT NULL COMMENT '文章关键字',
  `IMAGE_URL` varchar(100) DEFAULT NULL COMMENT '文章图片URL',
  `SOURCE` varchar(50) DEFAULT NULL COMMENT '文章来源',
  `AUTHOR` varchar(10) DEFAULT NULL COMMENT '文章作者',
  `CREATE_TIME` timestamp NULL DEFAULT NULL COMMENT '文章创建时间',
  `PUBLISH_TIME` timestamp NULL DEFAULT NULL COMMENT '文章发布时间',
  `LINK` varchar(100) DEFAULT NULL COMMENT '文章访问链接',
  `ARTICLE_TYPE` tinyint(4) DEFAULT '0' COMMENT '文章类型 2文章',
  `CLICK_NUM` int(11) DEFAULT '0' COMMENT '文章点击量',
  `PRAISE_COUNT` int(11) DEFAULT '0' COMMENT '点赞数量',
  `COMMENT_NUM` int(11) DEFAULT '0' COMMENT '评论数',
  `SORT` int(11) DEFAULT '0' COMMENT '排序值',
  PRIMARY KEY (`ARTICLE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文章信息表';

-- ----------------------------
-- Records of edu_article
-- ----------------------------

-- ----------------------------
-- Table structure for edu_article_content
-- ----------------------------
DROP TABLE IF EXISTS `edu_article_content`;
CREATE TABLE `edu_article_content` (
  `ARTICLE_ID` int(11) DEFAULT '0' COMMENT '文章ID',
  `CONTENT` text COMMENT '文章内容'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文章内容表';

-- ----------------------------
-- Records of edu_article_content
-- ----------------------------

-- ----------------------------
-- Table structure for edu_authen_type
-- ----------------------------
DROP TABLE IF EXISTS `edu_authen_type`;
CREATE TABLE `edu_authen_type` (
  `AUTHEN_ID` int(11) NOT NULL AUTO_INCREMENT,
  `AUTHEN_NAME` varchar(255) DEFAULT NULL COMMENT '验证类型',
  PRIMARY KEY (`AUTHEN_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of edu_authen_type
-- ----------------------------

-- ----------------------------
-- Table structure for edu_class
-- ----------------------------
DROP TABLE IF EXISTS `edu_class`;
CREATE TABLE `edu_class` (
  `CLASS_ID` varchar(50) NOT NULL COMMENT '班级id',
  `CLASS_NAME` varchar(255) DEFAULT NULL COMMENT '班级名称',
  `LEVEL_NAME` varchar(255) DEFAULT NULL COMMENT '学段名称，如：小学，初中，高中',
  `RXND` int(11) DEFAULT NULL COMMENT '入学年度',
  `GRADE` int(11) DEFAULT NULL COMMENT '所属年级，小学（1-6），初中(7-9)，高中(10-12)，如果值不在这里面则表示不在这三类学段中',
  `BYND` int(11) DEFAULT NULL COMMENT '毕业年度',
  `SCHOOL_ID` bigint(50) DEFAULT NULL COMMENT '学校ID',
  `IS_AVALIABLE` int(11) DEFAULT NULL COMMENT '是否可用',
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of edu_class
-- ----------------------------

-- ----------------------------
-- Table structure for edu_classuser
-- ----------------------------
DROP TABLE IF EXISTS `edu_classuser`;
CREATE TABLE `edu_classuser` (
  `USER_ID` bigint(50) DEFAULT NULL COMMENT '用户id',
  `CLASS_ID` bigint(50) DEFAULT NULL COMMENT '班级id',
  KEY `user_id` (`USER_ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='学生班级关联';

-- ----------------------------
-- Records of edu_classuser
-- ----------------------------
INSERT INTO `edu_classuser` VALUES ('1000018227598', '1000018227537');
INSERT INTO `edu_classuser` VALUES ('0', '0');

-- ----------------------------
-- Table structure for edu_comment
-- ----------------------------
DROP TABLE IF EXISTS `edu_comment`;
CREATE TABLE `edu_comment` (
  `COMMENT_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '评论表',
  `USER_ID` int(11) DEFAULT '0' COMMENT '用户id',
  `P_COMMENT_ID` int(11) DEFAULT NULL COMMENT '父级评论id(为0则是一级评论,不为0则是回复)',
  `CONTENT` varchar(1000) DEFAULT NULL COMMENT '评论内容',
  `ADDTIME` datetime DEFAULT NULL COMMENT '创建时间',
  `OTHER_ID` int(11) DEFAULT NULL COMMENT '评论的相关id',
  `PRAISE_COUNT` int(11) DEFAULT '0' COMMENT '点赞数量',
  `REPLY_COUNT` int(11) DEFAULT '0' COMMENT '回复数量',
  `TYPE` int(11) DEFAULT '0' COMMENT '1文章 2课程',
  PRIMARY KEY (`COMMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of edu_comment
-- ----------------------------

-- ----------------------------
-- Table structure for edu_course
-- ----------------------------
DROP TABLE IF EXISTS `edu_course`;
CREATE TABLE `edu_course` (
  `COURSE_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '课程编号',
  `COURSE_NAME` varchar(300) NOT NULL DEFAULT '' COMMENT '课程名称',
  `IS_AVALIABLE` int(10) NOT NULL DEFAULT '0' COMMENT '1上架2下架3删除',
  `SUBJECT_ID` int(11) DEFAULT '0' COMMENT '课程专业ID',
  `SUBJECT_LINK` varchar(255) DEFAULT NULL COMMENT '课程专业链',
  `ADD_TIME` timestamp NULL DEFAULT NULL COMMENT '添加时间',
  `SOURCE_PRICE` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '课程原价格（只显示）',
  `CURRENT_PRICE` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '课程销售价格（实际支付价格）设置为0则可免费观看',
  `TITLE` varchar(200) NOT NULL DEFAULT '' COMMENT '课程简介',
  `CONTEXT` longtext NOT NULL COMMENT '课程详情',
  `LESSION_NUM` int(11) NOT NULL DEFAULT '0' COMMENT '总课时',
  `LOGO` varchar(200) NOT NULL DEFAULT '' COMMENT '图片路径',
  `UPDATE_TIME` timestamp NULL DEFAULT NULL COMMENT '最后更新时间',
  `PAGE_BUYCOUNT` int(11) DEFAULT '0' COMMENT '销售数量',
  `PAGE_VIEWCOUNT` int(11) NOT NULL DEFAULT '0' COMMENT '浏览数量',
  `END_TIME` timestamp NULL DEFAULT NULL COMMENT '有效结束时间',
  `LOSETYPE` int(2) DEFAULT '0' COMMENT '有效期类型，0：到期时间，1：按天数',
  `LOSE_TIME` varchar(255) DEFAULT NULL COMMENT '有效期:商品订单过期时间点',
  `SEQUENCE` int(3) DEFAULT '0' COMMENT '序列',
  `COURSE_GROSS_INCOME` decimal(10,2) DEFAULT '0.00' COMMENT '该课程总共卖了多少钱（新加字段暂时没用到）',
  `SELL_TYPE` varchar(20) DEFAULT 'COURSE' COMMENT '课程类型：COURSE(课程) LIVE(直播)',
  `LIVE_BEGIN_TIME` datetime DEFAULT NULL COMMENT '直播开始时间',
  `LIVE_END_TIME` datetime DEFAULT NULL COMMENT '直播结束时间',
  `ROOM_ID` varchar(500) DEFAULT NULL COMMENT '直播房间号',
  PRIMARY KEY (`COURSE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='课程表';

-- ----------------------------
-- Records of edu_course
-- ----------------------------
INSERT INTO `edu_course` VALUES ('27', '2016难暑期高一课程', '1', '208', ',208,', '2016-03-28 10:32:43', '0.00', '0.00', '2016难暑期高一课程', '培养量化学习习惯的重要阶段。<br />\r\n启发孩子思维，为成长奠定良好基础 <br />\r\n从兴趣出发，涵盖全部课程，加强专题知识，培养考试能力。<br />\r\n<br />', '0', '/images/upload/course/20161115/1479202966843.png', '2016-11-15 17:42:47', '0', '74', '2020-01-01 17:00:00', '0', '', '0', '0.00', 'LIVE', '2016-03-29 08:00:00', '2020-01-01 17:00:00', null);
INSERT INTO `edu_course` VALUES ('29', '2016年暑期高二课程', '1', '210', ',210,', '2016-03-28 10:59:48', '0.00', '1.00', '2016年暑期高二课程', '培养量化学习习惯的重要阶段。<br />\r\n启发孩子思维，为成长奠定良好基础 <br />\r\n从兴趣出发，涵盖全部课程，加强专题知识，培养考试能力。<br />', '0', '/images/upload/course/20161115/1479202980513.png', '2016-11-16 11:06:12', '130', '2373', '2020-01-01 17:00:00', '0', '', '0', '0.00', 'LIVE', '2016-11-16 00:00:00', '2020-01-01 17:00:00', null);
INSERT INTO `edu_course` VALUES ('31', '2016年暑期高三课程', '1', '221', ',221,', '2016-03-28 11:38:55', '288.00', '1.00', '2016年暑期高三课程', '<p>\r\n	培养量化学习习惯的重要阶段。<br />\r\n启发孩子思维，为成长奠定良好基础 <br />\r\n从兴趣出发，涵盖全部课程，加强专题知识，培养考试能力。<br />\r\n</p>', '18', '/images/upload/course/20161115/1479202999952.png', '2016-11-15 17:43:22', '110', '894', '2020-01-01 17:00:00', '0', '', '0', '0.00', 'LIVE', '2016-03-01 00:00:00', '2020-01-01 17:00:00', null);
INSERT INTO `edu_course` VALUES ('32', '直播-零基础入门学习Python课程学习', '3', '251', ',223,251,', '2016-03-28 15:09:21', '98.00', '0.01', '直播-零基础入门学习Python课程学习', 'Python包含的内容很多，加上各种标准库、拓展库，乱花渐欲迷人眼。我一直希望写一个快速的、容易上手的Python教程，而且言语简洁，循序渐进，让没有背景的读者也可以从基础开始学习。我将在每一篇中专注于一个小的概念，希望在闲暇时可以很快读完。<br />\r\n<br />\r\n<br />\r\n小提醒<br />\r\n<br />\r\n    教程将专注于Python基础，语法基于Python 2.7 (我会提醒Python 3.x中有变化的地方，以方便读者适应3.X的情况)。测试环境为Linux。标准库的一些包不适用于Windows平台。如果文中的程序无法在你的平台上运行，欢迎讨论。<br />\r\n    我将专注于Python的主干，以便读者能以最快时间对Python形成概念。<br />\r\n    Linux命令行将以$开始，比如 $ls, $python<br />\r\n    Python命令行将以>>>开始，比如 >>>print \'Hello World!\'<br />\r\n    注释会以#开始<br />\r\n<br />\r\n<br />\r\n建议<br />\r\n<br />\r\n    将教程中的命令敲到Python中看看效果。<br />\r\n    看过教程之后，可以进行一些练习。<br />\r\n    参与文章评论区的讨论，可以更好的积累经验。', '8', '/images/upload/course/20150915/1442295455437.jpg', '2016-04-07 09:33:39', '315', '636', '2020-01-01 17:00:00', '0', '', '0', '0.00', 'LIVE', '2016-01-01 00:00:00', '2020-01-01 17:00:00', '356FE8D9FA0F535E9C33DC5901307461');
INSERT INTO `edu_course` VALUES ('33', '直播-XHTML CSS2 JS整站制作教程课程学习', '3', '203', ',202,203,', '2016-03-29 14:02:07', '380.00', '0.01', '直播-XHTML CSS2 JS整站制作教程课程学习', '可扩展超文本标记语言，是一种置标语言，表现方式与超文本标记语言类似，不过语法上更加严格。从继承关系上讲，HTML是一种基于标准通用置标语言的应\r\n用，是一种非常灵活的置标语言，而XHTML则基于可扩展标记语言，可扩展标记语言是标准通用置标语言的一个子集。XHTML \r\n1.0在2000年1月26日成为W3C的推荐标准。 \r\nCSS2.0提供给我们了一个机制，让程序员开发时可以不考虑显示和界面就可以制作>表单和界面，显示问题可由美工或是程序员后期再来编写相应的 \r\nCSS2.0样式来解决。不过由于CSS2.0目前尚未见过很好的编辑软件，所以无法做到所见即所得，编写起来不易。', '6', '/images/upload/course/20150915/1442295527931.jpg', '2016-11-15 15:34:41', '0', '24', '2020-01-01 17:00:00', '0', '', '0', '0.00', 'LIVE', '2016-01-08 08:00:00', '2020-01-01 17:00:00', null);
INSERT INTO `edu_course` VALUES ('34', '2016年暑期初二课程', '1', '202', ',202,', '2016-03-29 14:04:19', '0.00', '0.00', '2016年暑期初二课程', '培养量化学习习惯的重要阶段。<br />\r\n启发孩子思维，为成长奠定良好基础 <br />\r\n从兴趣出发，涵盖全部课程，加强专题知识，培养考试能力。<br />\r\n<br />', '9', '/images/upload/course/20161115/1479202817399.png', '2016-11-16 11:05:39', '891', '2079', '2020-01-01 17:00:00', '0', '', '46', '0.00', 'LIVE', '2016-11-16 00:00:00', '2020-01-01 17:00:00', null);
INSERT INTO `edu_course` VALUES ('35', '2016年暑期初一课程', '1', '223', ',223,', '2016-03-29 14:07:19', '0.00', '0.00', '2016年暑期初一课程', '培养量化学习习惯的重要阶段。<br />\r\n启发孩子思维，为成长奠定良好基础 <br />\r\n从兴趣出发，涵盖全部课程，加强专题知识，培养考试能力。<br />\r\n<br />', '8', '/images/upload/course/20161115/1479202794005.png', '2016-11-16 11:05:05', '1209', '4236', '2020-01-31 17:00:00', '0', '', '100', '0.00', 'LIVE', '2016-11-16 00:00:00', '2020-01-31 17:00:00', null);
INSERT INTO `edu_course` VALUES ('36', '直播-搜索引擎优化技术', '3', '214', ',210,214,', '2016-04-06 19:21:15', '10.00', '0.01', '直播-搜索引擎优化技术', '<img src=\"http://p.qpic.cn/qqke_course_info/ajNVdqHZLLDBBDm1tRSibKKW1l7m9xzRnTFXicwMHnHmpdXNFfZAoWBOH929pc9lnUwchKYnibldJ4/\" height=\"466\" width=\"850\" />', '3', '/images/upload/course/20150915/1442302852837.jpg', '2016-04-07 09:32:45', '23', '123', '2020-01-01 17:00:00', '0', '', '0', '0.00', 'LIVE', '2016-04-07 00:00:00', '2020-01-01 17:00:00', '356FE8D9FA0F535E9C33DC5901307461');
INSERT INTO `edu_course` VALUES ('37', '技术开发套餐', '1', '222', ',221,222,', '2016-05-12 09:55:37', '168.00', '88.00', '技术开发套餐', 'Python包含的内容很多，加上各种标准库、拓展库，乱花渐欲迷人眼。我一直希望写一个快速的、容易上手的Python教程，而且言语简洁，循序渐进，让没有背景的读者也可以从基础开始学习。我将在每一篇中专注于一个小的概念，希望在闲暇时可以很快读完。<br />\r\n<br />\r\n<br />\r\n小提醒<br />\r\n<br />\r\n&nbsp;&nbsp;&nbsp; 教程将专注于Python基础，语法基于Python 2.7 (我会提醒Python 3.x中有变化的地方，以方便读者适应3.X的情况)。测试环境为Linux。标准库的一些包不适用于Windows平台。如果文中的程序无法在你的平台上运行，欢迎讨论。<br />\r\n&nbsp;&nbsp;&nbsp; 我将专注于Python的主干，以便读者能以最快时间对Python形成概念。<br />\r\n&nbsp;&nbsp;&nbsp; Linux命令行将以$开始，比如 $ls, $python<br />\r\n&nbsp;&nbsp;&nbsp; Python命令行将以&gt;&gt;&gt;开始，比如 &gt;&gt;&gt;print \'Hello World!\'<br />\r\n&nbsp;&nbsp;&nbsp; 注释会以#开始<br />\r\n<br />\r\n<br />\r\n建议<br />\r\n<br />\r\n&nbsp;&nbsp;&nbsp; 将教程中的命令敲到Python中看看效果。<br />\r\n&nbsp;&nbsp;&nbsp; 看过教程之后，可以进行一些练习。<br />\r\n&nbsp;&nbsp;&nbsp; 参与文章评论区的讨论，可以更好的积累经验。<br />', '4', '/images/upload/course/20150915/1442295455437.jpg', '2016-05-12 09:55:37', '0', '18', '2020-01-01 17:00:00', '1', '90', '0', '0.00', 'PACKAGE', '2016-03-01 00:00:00', '2020-01-01 17:00:00', '356FE8D9FA0F535E9C33DC5901307461');
INSERT INTO `edu_course` VALUES ('38', '0526 15:04 测试bbbbbb', '1', '251', ',223,251,', '2016-05-26 15:05:34', '11.00', '11.00', '这是简介', '这是详情<br />', '12', '', '2016-10-31 11:32:25', '115', '64', '2020-01-01 17:00:00', '0', '', '111', '0.00', 'PACKAGE', '2016-05-26 15:04:24', '2020-01-01 17:00:00', null);
INSERT INTO `edu_course` VALUES ('39', '2016/05/27', '3', '206', ',202,206,', '2016-05-27 11:36:40', '188.00', '100.00', '000', '0000', '10', '', '2016-05-27 11:36:40', '1', '19', '2020-01-01 17:00:00', '0', '', '0', '0.00', 'LIVE', '2016-05-27 11:35:17', '2020-01-01 17:00:00', 'B8286D0F24BDF3A69C33DC5901307461');
INSERT INTO `edu_course` VALUES ('40', '哈哈哈哈', '3', '206', ',202,206,', '2016-10-27 09:15:44', '0.01', '0.01', '1111', '111111', '10', 'website/showPicture?picPath=/images/upload/course/20161027/1477530935876.png', '2016-10-27 09:15:44', '1112', '1112', '2020-01-01 17:00:00', '0', '', '0', '0.00', 'LIVE', '2016-10-27 00:00:00', '2020-01-01 17:00:00', 'D50EAC1FDDD061519C33DC5901307461');
INSERT INTO `edu_course` VALUES ('41', '12345345678', '3', '214', ',210,214,', '2016-10-27 10:47:32', '0.00', '0.00', 'AAAA', 'AAAAA', '0', '', '2016-10-27 10:47:32', '0', '2', '2020-01-01 17:00:00', '0', '', '0', '0.00', 'LIVE', '2016-10-27 00:00:00', '2020-01-01 17:00:00', 'E06913D56DF993059C33DC5901307461');
INSERT INTO `edu_course` VALUES ('42', '2016年暑期初三课程', '1', '221', ',221,', '2016-11-11 14:02:33', '0.00', '0.00', '2016年暑期初三课程', '培养量化学习习惯的重要阶段。<br />\r\n启发孩子思维，为成长奠定良好基础 <br />\r\n从兴趣出发，涵盖全部课程，加强专题知识，培养考试能力。<br />\r\n<br />', '5', '/images/upload/course/20161115/1479202946442.png', '2016-11-16 11:05:55', '0', '26', '2016-12-31 00:00:00', '0', '', '5', '0.00', 'LIVE', '2016-11-16 00:00:00', '2016-12-31 00:00:00', null);
INSERT INTO `edu_course` VALUES ('43', 'adfadadfa', '1', '223', ',223,', '2016-11-18 14:15:11', '200.00', '50.00', 'dadsfdasf', 'asdfasdfasdfadsfasdfasd', '5', '/images/upload/course/20161118/1479449699349.png', '2016-11-18 14:15:11', '0', '0', '2016-11-30 00:00:00', '0', '', '0', '0.00', 'PACKAGE', null, null, '6BD11DF135FE1C3D9C33DC5901307461');

-- ----------------------------
-- Table structure for edu_course_card
-- ----------------------------
DROP TABLE IF EXISTS `edu_course_card`;
CREATE TABLE `edu_course_card` (
  `COURSE_CARD_ID` int(11) NOT NULL,
  `CARD_NUMBER` varchar(32) DEFAULT NULL COMMENT '卡号',
  `CARD_PASSWORD` varchar(32) DEFAULT NULL COMMENT '密码',
  `CARD_PACKAGE` int(11) DEFAULT NULL COMMENT '对应课程ID',
  `CARD_STATUS` int(11) DEFAULT NULL COMMENT '使用状态',
  `CARD_USER` int(11) DEFAULT NULL COMMENT '用户',
  `CARD_USE_TIME` datetime DEFAULT NULL COMMENT '使用时间',
  PRIMARY KEY (`COURSE_CARD_ID`),
  KEY `CARD_NUM` (`CARD_NUMBER`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of edu_course_card
-- ----------------------------
INSERT INTO `edu_course_card` VALUES ('1', '123456789', '123456', '34', '1', '100', '2016-05-26 14:58:57');
INSERT INTO `edu_course_card` VALUES ('2', '123466788', '123456', '38', '1', '100', '2016-05-26 15:11:46');
INSERT INTO `edu_course_card` VALUES ('3', '123456777', '123456', '39', '1', '100', '2016-05-27 11:39:21');

-- ----------------------------
-- Table structure for edu_course_favorites
-- ----------------------------
DROP TABLE IF EXISTS `edu_course_favorites`;
CREATE TABLE `edu_course_favorites` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `COURSE_ID` int(11) DEFAULT '0' COMMENT '课程id',
  `USER_ID` int(11) DEFAULT '0' COMMENT '用户ID',
  `ADD_TIME` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`ID`),
  KEY `user_id` (`USER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COMMENT='收藏';

-- ----------------------------
-- Records of edu_course_favorites
-- ----------------------------
INSERT INTO `edu_course_favorites` VALUES ('1', '10', '2', '2015-04-07 02:43:45');
INSERT INTO `edu_course_favorites` VALUES ('2', '13', '2', '2015-04-07 02:45:00');
INSERT INTO `edu_course_favorites` VALUES ('3', '12', '2', '2015-04-07 02:45:05');
INSERT INTO `edu_course_favorites` VALUES ('5', '14', '2', '2015-04-08 18:29:37');
INSERT INTO `edu_course_favorites` VALUES ('6', '15', '2', '2015-04-08 18:29:43');
INSERT INTO `edu_course_favorites` VALUES ('7', '16', '2', '2015-04-08 18:39:41');
INSERT INTO `edu_course_favorites` VALUES ('8', '17', '2', '2015-04-08 18:39:48');
INSERT INTO `edu_course_favorites` VALUES ('9', '18', '2', '2015-04-08 18:39:53');
INSERT INTO `edu_course_favorites` VALUES ('11', '10', '13', '2015-04-13 05:49:29');
INSERT INTO `edu_course_favorites` VALUES ('12', '12', '23', '2015-04-13 07:44:47');
INSERT INTO `edu_course_favorites` VALUES ('13', '12', '13', '2015-04-13 07:49:51');
INSERT INTO `edu_course_favorites` VALUES ('14', '16', '13', '2015-04-13 07:50:15');
INSERT INTO `edu_course_favorites` VALUES ('15', '17', '13', '2015-04-13 08:22:11');
INSERT INTO `edu_course_favorites` VALUES ('25', '10', '11', '2015-09-10 09:50:56');
INSERT INTO `edu_course_favorites` VALUES ('30', '11', '1', '2015-10-30 09:06:35');
INSERT INTO `edu_course_favorites` VALUES ('31', '31', '7', '2016-03-30 18:15:00');
INSERT INTO `edu_course_favorites` VALUES ('32', '35', '7', '2016-03-31 09:55:46');

-- ----------------------------
-- Table structure for edu_course_kpoint
-- ----------------------------
DROP TABLE IF EXISTS `edu_course_kpoint`;
CREATE TABLE `edu_course_kpoint` (
  `KPOINT_ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `COURSE_ID` int(11) DEFAULT '0' COMMENT '课程id',
  `NAME` varchar(300) DEFAULT NULL COMMENT '节点名称',
  `PARENT_ID` int(11) DEFAULT '0' COMMENT '父级ID',
  `ADD_TIME` datetime DEFAULT NULL COMMENT '添加时间',
  `SORT` int(11) DEFAULT '0' COMMENT '显示排序',
  `PLAY_COUNT` int(11) DEFAULT '0' COMMENT '播放次数',
  `IS_FREE` tinyint(1) DEFAULT '0' COMMENT '是否可以试听1免费2收费',
  `VIDEO_URL` varchar(500) DEFAULT NULL COMMENT '教师端视频地址',
  `TEACHER_ID` int(11) DEFAULT '0' COMMENT '讲师id',
  `play_time` varchar(100) DEFAULT '' COMMENT '播放时间',
  `KPOINT_TYPE` int(1) DEFAULT '0' COMMENT '节点类型 0文件目录 1视频',
  `VIDEO_TYPE` varchar(30) DEFAULT NULL COMMENT '视频类型',
  `FILE_TYPE` varchar(20) DEFAULT NULL COMMENT 'VIDEO视频 AUDIO音频 FILE文档 TXT文本 ATLAS图片集',
  `CONTENT` longtext COMMENT '文本',
  `PAGE_COUNT` int(11) DEFAULT NULL COMMENT '页数',
  `LIVE_BEGIN_TIME` datetime DEFAULT NULL COMMENT '直播开始时间',
  `LIVE_END_TIME` datetime DEFAULT NULL COMMENT '直播结束时间',
  `LIVE_URL` varchar(200) DEFAULT NULL COMMENT '直播地址',
  `LIVE_STATUS` int(11) DEFAULT NULL COMMENT '直播状态',
  `STUDENT_URL` varchar(500) DEFAULT NULL COMMENT '学生端视频地址',
  `T_MODERATOR_PW` varchar(200) DEFAULT NULL COMMENT '讲师进入直播间密钥',
  `S_ATTENDEE_PW` varchar(200) DEFAULT NULL COMMENT '学生进入直播间密钥',
  `PLAY_BACK_URL` varchar(1000) DEFAULT NULL COMMENT '直播回放url',
  `IS_PUBLISHED` tinyint(1) DEFAULT '0' COMMENT '0未发布 1已发布',
  `IS_HAVE_RECORDINGURL` tinyint(1) DEFAULT NULL COMMENT '是否有录制url    0代表有   1代表无',
  PRIMARY KEY (`KPOINT_ID`),
  KEY `course_id` (`COURSE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='知识点的基本信息';

-- ----------------------------
-- Records of edu_course_kpoint
-- ----------------------------
INSERT INTO `edu_course_kpoint` VALUES ('1', '10', '第一章', '0', '2015-03-31 17:17:11', '10', '520', '2', null, '74', '', '0', 'IFRAME', 'VIDEO', null, null, '2016-11-11 13:22:14', '2016-11-12 13:22:27', null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('3', '10', '第二章', '0', '2015-04-01 10:11:59', '9', '0', '1', null, '74', '', '0', 'IFRAME', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('4', '10', '第一节', '3', '2015-04-01 10:12:02', '0', '3', '2', 'BFA2FECB0988F57A9F3D3540379DB73D', '74', '33:00', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('5', '10', '优酷视频', '1', '2015-04-01 10:12:03', '0', '1', '1', 'http://player.youku.com/embed/XMTUxMTg4MTIyNA==', '76', '01:20', '1', 'IFRAME', 'VIDEO', '', '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('13', '19', '第一章节：首先教学搭建开发环境', '0', '2015-04-13 21:31:16', '0', '0', '1', null, '83', '', '0', 'IFRAME', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('14', '20', '课程视频', '0', '2015-04-13 21:38:28', '0', '0', '2', 'BFA2FECB0988F57A9F3D3540379DB73D', '83', '56:80', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('15', '14', '第一章', '0', '2015-05-12 15:45:45', '0', '0', '1', '', '74', '', '0', 'IFRAME', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('16', '14', 'XHTML CSS2 JS整站制作教程课1', '15', '2015-05-12 15:46:14', '0', '0', '1', 'BFA2FECB0988F57A9F3D3540379DB73D', '78', '', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('17', '19', '第一课时：输入与输出和用户交互', '13', '2015-09-01 17:10:19', '0', '0', '1', 'BFA2FECB0988F57A9F3D3540379DB73D', '82', '', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('18', '19', '第二课时：输入出和用户交互', '13', '2015-09-01 17:10:55', '0', '0', '2', 'BFA2FECB0988F57A9F3D3540379DB73D', '75', '', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('19', '19', '第二章节：首先教学搭建开发环境', '0', '2015-09-01 17:21:12', '0', '0', '1', null, '73', '', '0', 'IFRAME', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('20', '19', '第一课时', '19', '2015-09-01 17:21:47', '0', '0', '2', 'BFA2FECB0988F57A9F3D3540379DB73D', '78', '', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('32', '14', '第二章', '0', '2015-09-10 11:33:58', '0', '0', '1', null, '82', '', '0', 'IFRAME', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('33', '14', 'XHTML CSS2 JS 第二章 一节', '32', '2015-09-10 11:34:19', '0', '0', '1', 'BFA2FECB0988F57A9F3D3540379DB73D', '80', '', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('34', '14', 'XHTML CSS2 JS整站制作教程课2', '15', '2015-09-10 11:37:49', '0', '0', '1', 'BFA2FECB0988F57A9F3D3540379DB73D', '77', '', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('35', '16', '第一章', '0', '2015-09-10 11:40:32', '0', '0', '1', null, '74', '', '0', 'IFRAME', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('36', '16', '第二章', '0', '2015-09-10 11:40:48', '0', '0', '1', null, '75', '', '0', 'IFRAME', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('37', '16', '第一节', '35', '2015-09-10 11:41:05', '0', '2', '1', 'http://yuntv.letv.com/bcloud.html?uu=xwl9w2wafn&vu=d5fe1553d9&pu=52ea1567f7&auto_play=1&gpcflag=1&width=640&height=360', '76', '', '1', 'LETV', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('38', '16', '第一节', '36', '2015-09-10 11:41:44', '0', '0', '2', 'BFA2FECB0988F57A9F3D3540379DB73D', '82', '', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('39', '16', '第二节', '35', '2015-09-10 11:43:02', '0', '0', '2', 'BFA2FECB0988F57A9F3D3540379DB73D', '78', '', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('40', '17', '第一章', '0', '2015-09-10 13:35:14', '0', '0', '1', null, '75', '', '0', 'IFRAME', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('41', '17', '第一节', '40', '2015-09-10 13:35:41', '0', '8', '2', 'F5247E2609A9570CB2E19C4D71FA5909', '78', '', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('49', '11', '课程一', '0', '2015-11-04 10:01:41', '0', '23', '1', 'F5247E2609A9570CB2E19C4D71FA5909', '77', '23:60', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('50', '12', '第一节', '0', '2015-11-04 10:02:47', '0', '43', '1', 'F5247E2609A9570CB2E19C4D71FA5909', '75', '10:29', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('51', '13', '第一章', '0', '2015-11-04 10:03:36', '0', '0', '1', '', '77', '', '0', '', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('52', '13', '课时1', '51', '2015-11-04 10:04:01', '0', '6', '1', 'F5247E2609A9570CB2E19C4D71FA5909', '78', '56:00', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('53', '15', '第一节', '0', '2015-11-04 10:04:54', '0', '12', '1', 'F5247E2609A9570CB2E19C4D71FA5909', '80', '45:80', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('54', '24', '第一节', '0', '2015-11-04 10:06:03', '0', '0', '2', 'F5247E2609A9570CB2E19C4D71FA5909', '78', '86:20', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('55', '23', '主讲课程', '0', '2015-11-04 10:13:40', '0', '1', '2', 'F5247E2609A9570CB2E19C4D71FA5909', '80', '45:80', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('56', '21', '第一节', '0', '2015-11-04 10:14:33', '0', '45', '2', 'F5247E2609A9570CB2E19C4D71FA5909', '73', '56:12', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('57', '18', '视频一', '0', '2015-11-04 10:15:53', '0', '2', '2', 'F5247E2609A9570CB2E19C4D71FA5909', '77', '89:20', '1', 'INXEDUVIDEO', 'VIDEO', null, null, null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('58', '10', '第三章', '0', '2016-02-29 16:46:04', '0', '0', '1', '', '73', '', '0', 'IFRAME', 'VIDEO', null, '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('61', '10', '课程音频', '3', '2016-03-01 09:53:26', '0', '2', '2', '435D41CC463D4E9AC9FAA3C8ECC17B67', '83', '3:28', '1', 'IFRAME', 'AUDIO', '', '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('62', '10', '课程学习文本', '58', '2016-03-01 10:29:17', '0', '2', '2', '', '82', '', '1', 'IFRAME', 'TXT', '<p class=\"MsoNormal\">\n	<b><span style=\"font-family:宋体;font-weight:bold;font-size:10.5000pt;\">一、基本文体知识识记 </span></b><b><span style=\"font-family:宋体;font-weight:bold;font-size:10.5000pt;\"></span></b>\n</p>\n<p class=\"MsoNormal\">\n	<span style=\"font-family:宋体;font-size:10.5000pt;\">（一）表达方式：记叙、描写、抒情、议论、说明 </span><span style=\"font-family:宋体;font-size:10.5000pt;\"></span>\n</p>\n<p class=\"MsoNormal\">\n	<span style=\"font-family:宋体;font-size:10.5000pt;\">（二）修辞手法：比喻、拟人、排比、夸张、反复、借代、反问、设问、引用、对比 </span><span style=\"font-family:宋体;font-size:10.5000pt;\"></span>\n</p>\n<p class=\"MsoNormal\" style=\"text-indent:31.5000pt;\">\n	<span style=\"font-family:宋体;font-size:10.5000pt;\">常见的</span><b><span style=\"font-family:宋体;font-weight:bold;font-size:10.5000pt;\">表现手法</span></b><span style=\"font-family:宋体;font-size:10.5000pt;\">：象征、对比、衬托、借景抒情、托物言志、借古讽今、借物喻人、寓理于事、寄情于事、运用典故、先（后）抑后（先）扬、欲扬先抑。 </span><span style=\"font-family:宋体;font-size:10.5000pt;\"></span>\n</p>\n<p class=\"MsoNormal\">\n	<span style=\"font-family:宋体;font-size:10.5000pt;\">（三）说明文分类： </span><span style=\"font-family:宋体;font-size:10.5000pt;\"></span>\n</p>\n<p class=\"MsoNormal\">\n	<span style=\"font-family:宋体;font-size:10.5000pt;\">１、实物说明文、事理说明文 </span><span style=\"font-family:宋体;font-size:10.5000pt;\"></span>\n</p>\n<p class=\"MsoNormal\">\n	<span style=\"font-family:宋体;font-size:10.5000pt;\">２、科技性说明文、文艺性说明文（科学小品或知识小品） </span><span style=\"font-family:宋体;font-size:10.5000pt;\"></span>\n</p>\n<p class=\"MsoNormal\">\n	<span style=\"font-family:宋体;font-size:10.5000pt;\">（四）说明顺序： </span><span style=\"font-family:宋体;font-size:10.5000pt;\"></span>\n</p>\n<p class=\"MsoNormal\">\n	<span style=\"font-family:宋体;font-size:10.5000pt;\">１、时间顺序 ', '1', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('64', '10', '课程学习图片集', '58', '2016-03-01 11:44:04', '0', '4', '2', '', '83', '', '1', 'IFRAME', 'ATLAS', null, '3', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('69', '10', '9件事把你从消极情绪中解救出来', '1', '2016-03-14 18:36:49', '3', '0', '2', '435D41CC463D4E9AC9FAA3C8ECC17B67', '81', '', '1', 'IFRAME', 'PDF', '', '3', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('70', '10', '随堂练习', '58', '2016-03-26 09:31:01', '0', '6', '2', '', '83', '', '1', 'IFRAME', 'TXT', '1。指出下列各句的病因，填写在句后的括号中。（8分）<br />\n<br />\nA。主语残缺B谓语残缺C宾语残缺D主谓搭配不当E。动宾搭配不当F语序不当G不合书理<br />\n<br />\n①中国人民正在努力为建设一个现代化的社会主义强国。（）<br />\n<br />\n②我们来到大海边，呼吸着新鲜空气、阳光和海水。（）<br />\n<br />\n③清晨，雄鸡报晓三更时，我就起床，准备出发了。（）<br />\n<br />\n④农业生产必须走现代化。（）<br />\n<br />\n⑤听了姜素椿的报告，使我们受到了很大的教育。（）<br />\n<br />\n⑥我国有世界上没有的万里长城。（）<br />\n<br />\n⑦我们必须及时纠正并随时发现学习过程中的缺点。（）<br />\n<br />\n⑧黑黑的乌云和瓢泼的大雨从空中倾泻下来。（）<br />\n<br />\n2016中考备战：25个中考语文病句经典题！<br />\n<br />\n2。下列句子没有语病的是（3分）（）<br />\n<br />\nA。在建设三峡大坝的过程中，无论工人们遇到什么样的困难，他们却能披荆斩棘，一往无前。<br />\n<br />\nB。在列车长粗暴的干涉下，使爱迪生在火车上边卖报边做实验的愿望破灭了。<br />\n<br />\nC。中国残疾人艺术团在香港演出大型音乐舞蹈《我的梦》，受到观众的热烈欢迎。<br />\n<br />\nD。为了防止非典疫情不再反弹，市领导要求各单位进一一步加强管理，制定严密的防范措施。<br />\n<br />\n3。下列句子中没有语病的一句是（3分）（）<br />\n<br />\nA。白衣天使奋战在抗击非典的第一线，他们动人的事迹和牺牲精神在广大人民心中传扬。<br />\n<br />\nB。在阅读文学名著的过程中，使我明白了许多做人的道理。感悟了人生的真谛。<br />\n<br />\nC。我们要与自然和谐相处，保护好属于我们人类自已的家园一一地球。<br />\n<br />\nD。那蝉声在晨光之中非常分外轻逸，似远似近，似近似远，又似有似无。<br />\n<br />\n4。下列各句中，没有语病的一句是（3分）（）<br />\n<br />\nA。把北山建设成省级森林公园，是当地政府实施可持续发展的一项重要工程。<br />\n<br />\nB。发电站每年的发电量，除了供应给杭州使用外，还向上海、南京等地输送。<br />\n<br />\nC。自编自演的课本剧在发展个性、引导学生阅读名著，都有一定的作用。<br />\n<br />\nD。街道希望通过多种渠道，大力开展法制教育，防止青少年不违法犯法。<br />\n<br />\n5。下列句子中没有语病的一项是（3分）（）<br />\n<br />\nA。实践证明，一个人知识的多寡，成就的大小。关键在于勤的程度。<br />\n<br />\nB。记者又到学校采访到了许多张老师的事迹。<br />\n<br />\nC。就目前来讲中国人民的文化程度普遍偏低，还确切地需要大大提高。<br />\n<br />\nD。通过中国男子足球队的表现，使我们认识到良好的心理素质的重要。<br />\n<br />\n2016中考备战：25个中考语文病句经典题！<br />\n<br />\n6。下面四个都是病句，其中只有一句有成分残缺的毛病，请选出来（3分）（）<br />\n<br />\nA。食物就是一种能够构成躯体和供应能量。B。欢乐的歌曲响彻了大江南北。<br />\n<br />\nC。我们认真倾听了他那慈祥的面容和感人的报告。D。连绵不断的小雨似瓢泼一般倾泻而下。<br />\n<br />\n7。选出下列四句中画线部分修改、分析完全对的一项。（4分）（）<br />\n<br />\n①我在海上远航过，在空中飞行过。但在我们的母亲河长江上，第一次为这样一种大自然威力（改为“伟力”）所吸引了。<br />\n<br />\n②无数（删去）层峦叠蟑之上，迷蒙雨雾之中，忽然出现一团红雾。<br />\n<br />\n③县里的医生跳下汽车，就立刻插手（改为“参加”）诊断、治疗。<br />\n<br />\n④虽然天山这时并不是春天，但是有哪一个春天的花园能比得过这时天山的无边繁花。（改为“繁花无比的天山”）<br />\n<br />\nA。①用词准确；②简洁，避免语意重复；③词感情色彩切合句意；④与主语“花园”搭配恰当。<br />\n<br />\nB。①与“大自然”一词搭配恰当；②简洁，避免语意重复；③用闻准确；④语序恰当。<br />\n<br />\nC。①感情色彩更鲜明；②避免夸张失实；③词的感情色彩切合文意；④语序更恰当。<br />\n<br />\nD。①用词准确；③避免夸张失实；③用词准确；④与主语“花园”搭配恰当。', '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('83', '10', '爱奇艺视频', '1', '2016-03-26 14:18:45', '0', '3', '1', '435D41CC463D4E9AC9FAA3C8ECC17B67', '0', '', '1', 'IFRAME', 'VIDEO', null, '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('85', '10', '土豆网视频', '1', '2016-03-26 14:44:30', '0', '2', '1', 'http://www.tudou.com/programs/view/html5embed.action?type=2&code=WQCLM9yoKn8&lcode=xluM-tnusyY&resourceId=80484112_06_05_99', '0', '', '1', 'IFRAME', 'VIDEO', null, '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('86', '10', '搜狐视频', '1', '2016-03-26 14:45:57', '0', '1', '1', 'http://tv.sohu.com/upload/static/share/share_play.html#1136657_5360218_0_1_1', '0', '', '1', 'IFRAME', 'VIDEO', null, '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('87', '10', '腾讯视频', '1', '2016-03-26 14:48:15', '0', '3', '1', 'http://v.qq.com/iframe/player.html?vid=c001997hh1h&tiny=0&auto=0', '0', '', '1', 'IFRAME', 'VIDEO', null, '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('88', '10', '56视频', '1', '2016-03-26 14:50:20', '0', '3', '1', 'http://www.56.com/iframe/MTQwNjExNzYx', '0', '', '1', 'IFRAME', 'VIDEO', null, '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('89', '10', 'pptv视频', '1', '2016-03-26 14:52:21', '0', '3', '1', 'http://player.pptv.com/iframe/index.html#id=24554313&ctx=o%3Dv_share', '0', '', '1', 'IFRAME', 'VIDEO', null, '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('90', '33', '第一章', '0', '2016-03-29 14:26:39', '0', '0', '1', '', '0', '', '0', 'IFRAME', 'VIDEO', null, '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('91', '33', '第一节', '90', '2016-03-29 14:27:03', '23', '0', '2', '435D41CC463D4E9AC9FAA3C8ECC17B67', '82', '', '1', 'IFRAME', 'LIVE', null, '0', '2016-03-29 09:00:00', '2016-03-29 20:00:00', null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('92', '33', '第二节', '90', '2016-03-29 15:06:28', '5', '0', '2', '435D41CC463D4E9AC9FAA3C8ECC17B67', '76', '', '1', 'IFRAME', 'LIVE', null, '0', '2016-04-21 12:00:00', '2016-04-21 19:00:00', null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('96', '34', '第一章', '0', '2016-03-29 16:36:58', '0', '0', '2', '', '0', '', '0', 'IFRAME', 'LIVE', null, '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('97', '34', '入门课程学习课时1', '96', '2016-03-29 16:37:10', '200', '0', '2', 'undefined', '82', '', '1', 'IFRAME', 'LIVE', null, '0', '2016-11-17 10:25:00', '2016-11-30 19:00:00', null, '0', '0', '111,111', '222,222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('98', '34', '入门课程学习课时2', '96', '2016-03-29 16:38:07', '80', '0', '2', 'undefined', '77', '', '1', 'IFRAME', 'LIVE', null, '0', '2016-11-25 12:01:20', '2016-11-30 12:01:39', null, '0', '0', '111,111', '222,222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('99', '34', '入门课程学习课时3', '96', '2016-03-29 16:38:53', '10', '0', '2', 'undefined', '77', '', '1', 'IFRAME', 'LIVE', null, '0', '2016-11-25 09:00:00', '2016-11-30 19:00:00', null, '0', '0', '111,111', '222,222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('100', '34', '入门课程学习课时4', '96', '2016-03-29 16:39:32', '6', '0', '2', 'undefined', '75', '', '1', 'IFRAME', 'LIVE', null, '0', '2016-11-28 09:00:00', '2016-11-30 19:00:00', null, '0', '0', '111,111', '222,222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('101', '31', '第一章', '0', '2016-03-29 16:40:26', '0', '0', '2', 'http://live.baofengcloud.com/33197041/bfcloud.html?servicetype=2&uid=33197041&fid=5C91361D08F35704E4BCBB2FE27392D144B87711&width=1024&height=576&auto=1&si=1&vr=0', '0', '', '0', 'IFRAME', 'LIVE', null, '0', null, null, null, null, '11111', '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('102', '31', '零基础第一节', '101', '2016-03-29 16:41:35', '20', '0', '2', 'undefined', '80', '', '1', 'IFRAME', 'LIVE', null, '0', '2016-05-01 09:00:00', '2016-11-03 19:00:00', null, '0', '0', '111,111', '222,222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('103', '33', '第二章', '0', '2016-03-29 16:49:16', '0', '0', '2', '', '0', '', '0', 'IFRAME', 'LIVE', null, '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('104', '31', '零基础第二节', '101', '2016-03-29 16:51:18', '5', '0', '2', 'undefined', '83', '', '1', 'IFRAME', 'LIVE', null, '0', '2016-05-01 09:00:00', '2016-11-30 12:00:00', null, '0', '0', '111,111', '222,222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('105', '27', '第一章', '0', '2016-03-31 14:34:39', '0', '0', '2', 'undefined', '0', '', '0', 'IFRAME', 'LIVE', null, '0', '2016-11-11 13:22:14', '2016-11-12 13:23:10', null, '0', '0', '111,111', '222,222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('106', '27', '第二章', '0', '2016-03-31 14:35:38', '0', '0', '2', 'undefined', '0', '', '0', 'IFRAME', 'LIVE', null, '0', '2016-11-11 13:22:14', '2016-11-12 13:23:10', null, '0', '0', '111,111', '222,222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('107', '27', '第三章', '0', '2016-03-31 14:39:00', '0', '0', '2', 'undefined', '0', '', '0', 'IFRAME', 'LIVE', null, '0', '2016-11-11 13:22:14', '2016-11-12 13:23:10', null, '0', '0', '111,111', '222,222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('108', '27', '期末考试精讲1', '105', '2016-03-31 14:39:26', '0', '0', '2', 'undefined', '73', '', '1', 'IFRAME', 'LIVE', null, '0', '2016-11-17 13:22:14', '2016-11-19 13:23:10', null, '0', '0', '111,111', '222,222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('109', '27', '期末考试精讲2', '106', '2016-03-31 14:40:44', '0', '0', '2', 'undefined', '74', '', '1', 'IFRAME', 'LIVE', null, '0', '2016-11-19 13:22:14', '2016-11-20 13:23:10', null, '0', '0', '111,111,111,111', '222,222,222,222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('110', '27', '期末考试精讲3', '107', '2016-03-31 14:41:27', '0', '0', '2', 'undefined', '82', '', '1', 'IFRAME', 'LIVE', null, '0', '2016-11-20 09:00:00', '2016-11-21 13:23:10', null, '0', '0', '111,111', '222,222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('111', '35', '精品课程', '0', '2016-03-31 14:42:46', '0', '0', '2', 'undefined', '0', '', '0', 'IFRAME', 'LIVE', null, '0', null, null, null, '0', '0', '111,111', '222,222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('112', '33', '第一节', '103', '2016-03-31 14:44:26', '0', '0', '2', 'http://live.baofengcloud.com/33197041/bfcloud.html?servicetype=2&uid=33197041&fid=5C91361D08F35704E4BCBB2FE27392D144B87711&width=1024&height=576&auto=1&si=1&vr=0', '74', '', '1', 'IFRAME', 'LIVE', null, '0', '2016-07-01 13:00:00', '2016-07-01 16:00:00', null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('113', '29', '第一节', '0', '2016-04-01 14:07:26', '0', '0', '2', 'http://live.baofengcloud.com/33197041/bfcloud.html?servicetype=2&uid=33197041&fid=5C91361D08F35704E4BCBB2FE27392D144B87711&width=1024&height=576&auto=1&si=1&vr=0', '80', '', '1', 'IFRAME', 'LIVE', null, '0', '2016-04-06 13:00:00', '2016-04-06 17:00:00', null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('114', '29', '第二节', '0', '2016-04-01 14:09:00', '0', '0', '2', 'http://live.baofengcloud.com/33197041/bfcloud.html?servicetype=2&uid=33197041&fid=5C91361D08F35704E4BCBB2FE27392D144B87711&width=1024&height=576&auto=1&si=1&vr=0', '76', '', '1', 'IFRAME', 'LIVE', null, '0', '2016-04-14 13:00:00', '2016-04-14 17:00:00', null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('115', '29', '第三节', '0', '2016-04-01 14:09:36', '0', '0', '2', 'http://live.baofengcloud.com/33197041/bfcloud.html?servicetype=2&uid=33197041&fid=5C91361D08F35704E4BCBB2FE27392D144B87711&width=1024&height=576&auto=1&si=1&vr=0', '77', '', '1', 'IFRAME', 'LIVE', null, '0', '2016-04-15 09:00:00', '2016-04-16 17:00:00', null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('116', '29', '第四节', '0', '2016-04-01 14:10:21', '0', '0', '2', 'http://live.baofengcloud.com/33197041/bfcloud.html?servicetype=2&uid=33197041&fid=5C91361D08F35704E4BCBB2FE27392D144B87711&width=1024&height=576&auto=1&si=1&vr=0', '82', '', '1', 'IFRAME', 'LIVE', null, '0', '2016-04-30 09:00:00', '2016-04-30 12:00:00', null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('117', '10', '暴风视频', '1', '2016-04-07 09:48:29', '10', '49', '1', '435D41CC463D4E9AC9FAA3C8ECC17B67', '0', '', '1', 'INXEDUVIDEO', 'VIDEO', '', '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('118', '10', '课后作业', '1', '2016-04-09 10:04:34', '0', '0', '2', '14755', '0', '', '1', 'INXEDUVIDEO', 'EXERCISES', '零基础入门学习Python课程学习-课后练习', '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('119', '10', '第二章作业', '3', '2016-04-11 17:59:28', '0', '0', '2', '14756', '0', '', '1', 'INXEDUVIDEO', 'EXERCISES', '零基础入门学习Python课程学习-第二章练习', '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('122', '10', '课程总练习', '58', '2016-04-13 09:18:15', '0', '0', '2', '14757', '0', '', '1', 'INXEDUVIDEO', 'EXERCISES', '零基础入门学习Python课程学习-总练习', '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('123', '11', '练习', '0', '2016-04-14 14:21:07', '0', '0', '2', '14730.0', '0', '', '1', 'INXEDUVIDEO', 'EXERCISES', '影想力摄影小课堂-练习', '0', null, null, null, null, null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('124', '38', '第一章', '0', '2016-05-26 15:06:45', '0', '0', '1', '', '0', '', '0', 'INXEDUVIDEO', 'LIVE', null, '0', null, null, null, '0', '', '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('125', '38', '随便吧', '124', '2016-05-26 15:07:05', '0', '0', '2', '8', '76', '', '1', 'INXEDUVIDEO', 'LIVE', null, '0', '2016-05-26 15:07:17', '2016-05-27 12:20:24', null, '0', '8', '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('126', '38', '第二节课', '124', '2016-05-26 15:24:33', '0', '0', '2', '0', '76', '', '1', 'INXEDUVIDEO', 'LIVE', null, '0', '2016-05-26 15:26:08', '2016-05-26 15:28:13', null, '0', '0', '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('128', '38', '新创建视频', '124', '2016-05-26 16:28:43', '0', '0', '1', null, '0', null, '1', 'INXEDUVIDEO', 'LIVE', null, '0', null, null, null, '0', null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('129', '38', '新创建视频', '0', '2016-05-26 16:46:30', '0', '0', '1', null, '0', null, '0', 'INXEDUVIDEO', 'LIVE', null, '0', null, null, null, '0', null, '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('130', '38', '第三节课', '124', '2016-05-26 16:46:35', '0', '0', '2', '0', '76', '', '1', 'INXEDUVIDEO', 'LIVE', null, '0', '2016-05-26 16:49:27', '2016-05-28 16:49:39', null, '0', '0', '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('131', '39', '第一章', '0', '2016-05-27 11:37:07', '0', '0', '1', '0', '0', '', '0', 'INXEDUVIDEO', 'LIVE', null, '0', null, null, null, '0', '0', '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('132', '39', '第一节课', '131', '2016-05-27 11:37:25', '0', '0', '2', '0', '76', '', '1', 'INXEDUVIDEO', 'LIVE', null, '0', '2016-05-27 11:37:36', '2016-05-28 11:37:39', null, '0', '0', '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('133', '40', '测试1', '0', '2016-10-27 09:33:41', '1', '0', '2', '0', '82', '', '0', 'INXEDUVIDEO', 'LIVE', null, '0', '2016-10-27 00:00:00', '2016-10-30 00:00:00', null, '0', '0', '111', '222', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('185', '42', '第一章', '0', '2016-11-11 14:02:43', '1', '0', '1', 'undefined', '0', '', '0', 'INXEDUVIDEO', 'LIVE', null, '0', null, null, null, '0', '0', 'teacher,teacher,teacher,teacher', 'student,student,student,student', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('187', '42', '第二节复习', '185', '2016-11-11 14:02:51', '1', '0', '2', 'undefined', '83', '', '1', 'INXEDUVIDEO', 'LIVE', null, '0', '2016-11-18 00:00:00', '2016-11-19 00:00:00', null, '0', '0', 'teacher,teacher,teacher,teacher', 'student,student,student,student', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('188', '42', '第一节有理数', '185', '2016-11-11 14:04:18', '2', '0', '2', 'undefined', '73', '', '1', 'INXEDUVIDEO', 'LIVE', null, '0', '2016-11-16 00:00:00', '2016-11-25 00:00:00', null, '0', '0', 'teacher,teacher,teacher,teacher,teacher,teacher,teacher,teacher', 'student,student,student,student,student,student,student,student', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('190', '33', '新创建视频', '0', '2016-11-15 15:37:51', '0', '0', '1', null, '0', null, '0', 'INXEDUVIDEO', 'LIVE', null, '0', null, null, null, '0', null, null, null, null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('192', '35', '第一节', '111', '2016-11-16 17:32:59', '0', '0', '2', 'undefined', '83', '', '1', 'INXEDUVIDEO', 'LIVE', null, '0', '2016-11-16 00:00:00', '2016-12-01 15:00:00', null, '0', '0', 't_11,11', 's_22,22', 'http://test.gukeer.cc/playback/presentation/0.9.0/playback.html?meetingId=19a448c01aa2e7d55979473b647e282459995b85-1479872053654', '1', null);
INSERT INTO `edu_course_kpoint` VALUES ('193', '35', '第二节', '111', '2016-11-16 17:43:20', '0', '0', '2', 'undefined', '83', '', '1', 'INXEDUVIDEO', 'LIVE', null, '0', '2016-11-17 00:00:00', '2016-11-24 00:00:00', null, '0', '0', 't_11,11', 's_11,11', 'http://test.gukeer.cc/playback/presentation/0.9.0/playback.html?meetingId=f67462663a512121ffada791890b558ee8b38773-1478844371490', '0', null);
INSERT INTO `edu_course_kpoint` VALUES ('194', '43', '新创建视频1', '0', '2016-11-18 14:15:20', '0', '0', '1', '', '0', '', '0', 'INXEDUVIDEO', 'VIDEO', null, '0', null, null, null, '0', '0', 't_', 's_', null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('195', '43', '新创建视频', '0', '2016-11-18 14:15:21', '0', '0', '1', null, '0', null, '0', 'INXEDUVIDEO', 'VIDEO', null, '0', null, null, null, '0', null, null, null, null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('196', '43', '新创建视频', '0', '2016-11-18 14:15:22', '0', '0', '1', null, '0', null, '0', 'INXEDUVIDEO', 'VIDEO', null, '0', null, null, null, '0', null, null, null, null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('197', '43', '新创建视频a', '194', '2016-11-18 14:15:28', '0', '0', '1', 'http://ofjgoo6qa.bkt.clouddn.com/o_1b1r17ti9f0i1ocjfpn150aqvh9.mp4', '0', '', '1', 'INXEDUVIDEO', 'VIDEO', null, '0', null, null, null, '0', null, null, null, null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('198', '43', '新创建视频b', '195', '2016-11-18 14:15:30', '0', '0', '1', 'http://ofjgoo6qa.bkt.clouddn.com/o_1b1r3ae3e7bd18pk1clk1ebltgb9.mov', '0', '', '1', 'INXEDUVIDEO', 'VIDEO', null, '0', null, null, null, '0', null, null, null, null, null, null);
INSERT INTO `edu_course_kpoint` VALUES ('199', '43', '新创建视频', '196', '2016-11-18 14:15:31', '0', '0', '1', 'http://file.ckmooc.com/o_1b1rb66ck1v610e7m1c114cfjo9.png', '0', null, '1', 'INXEDUVIDEO', 'VIDEO', null, '0', null, null, null, '0', null, null, null, null, null, null);

-- ----------------------------
-- Table structure for edu_course_studyhistory
-- ----------------------------
DROP TABLE IF EXISTS `edu_course_studyhistory`;
CREATE TABLE `edu_course_studyhistory` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL COMMENT '用户id',
  `COURSE_ID` int(11) NOT NULL COMMENT '课程id',
  `KPOINT_ID` int(11) NOT NULL COMMENT '节点id',
  `PLAYERCOUNT` int(11) NOT NULL DEFAULT '0' COMMENT '观看次数,累加',
  `COURSE_NAME` varchar(50) DEFAULT NULL COMMENT '课程名称',
  `KPOINT_NAME` varchar(50) DEFAULT NULL COMMENT '节点名称',
  `DATABACK` text COMMENT 'playercount小于20时记录,备注观看的时间，叠加',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT '最后观看时间',
  PRIMARY KEY (`ID`),
  KEY `user_course_id` (`USER_ID`,`COURSE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COMMENT='课程播放记录(学习记录)';

-- ----------------------------
-- Records of edu_course_studyhistory
-- ----------------------------
INSERT INTO `edu_course_studyhistory` VALUES ('1', '7', '19', '17', '43', '听力口语', '第一课时：输入与输出和用户交互', '2015-09-08 06:11:56,2015-09-08 06:10:23,2015-09-08 05:35:42,2015-09-08 05:33:20,2015-09-08 03:20:59,2015-09-08 03:18:42,2015-09-08 02:22:56,2015-09-07 07:10:08,2015-09-07 07:09:10,2015-09-07 07:08:14,2015-09-07 07:00:17,2015-09-07 06:57:51,2015-09-07 06:57:12,2015-09-07 06:57:05,2015-09-07 06:56:24,2015-09-07 06:56:17,2015-09-07 06:55:40,2015-09-07 06:54:26,2015-09-07 06:52:53,2015-09-07 06:52:08,2015-09-07 06:47:17,2015-09-07 06:46:44,2015-09-07 06:42:31,2015-09-07 06:40:39,2015-09-07 06:38:23,', '2015-09-08 14:11:56');
INSERT INTO `edu_course_studyhistory` VALUES ('2', '7', '19', '18', '4', '听力口语', '第二课时：输入出和用户交互', '2015-09-07 06:56:20,2015-09-07 06:55:44,2015-09-07 06:54:36,2015-09-06 02:55:27,', '2015-09-07 14:56:20');
INSERT INTO `edu_course_studyhistory` VALUES ('3', '7', '10', '5', '137', '零基础入门学习Python课程学习', '优酷视频', '2016-05-16 07:20:35,2016-05-04 01:02:42,2016-03-26 07:56:08,2016-03-26 07:53:31,2016-03-26 06:54:05,2016-03-26 06:39:38,2016-03-26 03:27:32,2016-03-26 02:40:37,2016-03-26 02:36:36,2016-03-26 02:12:42,2016-03-26 01:20:49,2016-03-26 01:15:45,2016-03-26 01:15:14,2016-03-25 01:36:19,2016-03-25 01:35:03,2016-03-25 01:32:01,2016-03-25 01:30:19,2016-03-25 01:12:50,2016-03-24 11:24:38,2016-03-24 09:57:26,2016-03-24 06:20:34,2016-03-24 06:20:24,2016-03-24 06:17:26,2016-03-24 05:41:48,2016-03-24 03:58:15,', '2016-05-16 15:20:35');
INSERT INTO `edu_course_studyhistory` VALUES ('4', '7', '14', '16', '11', 'XHTML CSS2 JS整站制作教程课程学习', 'XHTML CSS2 JS整站制作教程课1', '2016-03-08 06:53:28,2016-03-08 06:51:18,2015-10-29 09:26:02,2015-10-29 09:25:51,2015-10-29 09:25:37,2015-09-08 09:35:18,2015-09-08 09:34:34,2015-09-08 09:34:01,2015-09-08 09:32:56,2015-09-08 09:32:07,2015-09-08 09:31:46,', '2016-03-08 14:53:28');
INSERT INTO `edu_course_studyhistory` VALUES ('5', '7', '10', '2', '53', '零基础入门学习Python课程学习', '第二节', '2016-03-25 05:45:55,2016-03-25 01:36:17,2016-03-25 01:35:02,2016-03-25 01:31:59,2016-03-25 01:30:18,2016-03-25 01:12:49,2016-03-24 11:24:37,2016-03-24 09:57:34,2016-03-24 09:57:34,2016-03-24 09:57:24,2016-03-24 06:20:33,2016-03-24 06:20:23,2016-03-24 05:41:50,2016-03-24 03:58:16,2016-03-24 03:20:47,2016-03-24 03:05:05,2016-03-24 02:57:41,2016-03-24 02:43:56,2016-03-12 06:13:49,2016-03-12 02:21:37,2015-10-14 07:06:24,2015-10-14 06:42:16,2015-10-14 03:50:56,2015-09-29 01:34:59,2015-09-29 01:34:01,', '2016-03-25 13:45:55');
INSERT INTO `edu_course_studyhistory` VALUES ('6', '10', '10', '5', '1', '零基础入门学习Python课程学习', '少年时代', '2015-09-09 20:30:57,', '2015-09-09 16:30:57');
INSERT INTO `edu_course_studyhistory` VALUES ('7', '6', '14', '16', '2', 'XHTML CSS2 JS整站制作教程课程学习', 'XHTML CSS2 JS整站制作教程课1', '2015-09-24 02:26:54,2015-09-10 03:39:11,', '2015-09-24 10:26:54');
INSERT INTO `edu_course_studyhistory` VALUES ('8', '6', '14', '34', '2', 'XHTML CSS2 JS整站制作教程课程学习', 'XHTML CSS2 JS整站制作教程课2', '2015-09-10 03:39:24,2015-09-10 03:39:17,', '2015-09-10 11:39:24');
INSERT INTO `edu_course_studyhistory` VALUES ('9', '6', '14', '33', '1', 'XHTML CSS2 JS整站制作教程课程学习', 'XHTML CSS2 JS 第二章 一节', '2015-09-10 03:39:21,', '2015-09-10 11:39:21');
INSERT INTO `edu_course_studyhistory` VALUES ('10', '7', '10', '4', '39', '零基础入门学习Python课程学习', '第一节', '2016-05-04 01:47:18,2016-03-26 06:39:41,2016-03-26 03:27:31,2016-03-26 02:40:41,2016-03-26 02:37:32,2016-03-26 02:36:40,2016-03-26 02:27:00,2016-03-26 02:26:19,2016-03-26 02:12:44,2016-03-26 02:01:33,2016-03-26 01:25:00,2016-03-26 01:20:59,2016-03-25 01:35:05,2016-03-25 01:32:02,2016-03-25 01:30:22,2016-03-24 05:41:52,2016-03-24 03:05:09,2016-03-24 02:43:58,2016-03-12 02:21:32,2015-10-14 07:06:30,2015-10-14 06:42:26,2015-10-14 06:42:22,2015-10-14 03:51:35,2015-10-14 03:51:01,2015-09-29 01:35:01,', '2016-05-04 09:47:18');
INSERT INTO `edu_course_studyhistory` VALUES ('11', '7', '10', '44', '182', '零基础入门学习Python课程学习', '主讲课程', '2016-03-24 06:16:17,2016-03-24 06:15:58,2016-03-24 06:14:48,2016-03-24 06:09:01,2016-03-24 06:07:51,2016-03-24 05:46:31,2016-03-24 05:41:45,2016-03-24 03:58:13,2016-03-24 03:58:05,2016-03-24 03:57:44,2016-03-24 03:33:57,2016-03-24 03:31:36,2016-03-24 03:20:44,2016-03-24 03:05:02,2016-03-24 03:02:35,2016-03-24 02:58:30,2016-03-24 02:57:39,2016-03-24 02:51:38,2016-03-24 02:44:41,2016-03-24 02:43:52,2016-03-24 02:43:32,2016-03-24 01:37:15,2016-03-24 01:12:08,2016-03-23 09:53:11,2016-03-23 09:52:07,', '2016-03-24 14:16:17');
INSERT INTO `edu_course_studyhistory` VALUES ('12', '7', '10', '54', '4', '零基础入门学习Python课程学习', '乐视云视频', '2015-09-29 01:35:17,2015-09-28 10:24:11,2015-09-19 09:13:58,2015-09-19 05:40:45,', '2015-09-29 09:35:17');
INSERT INTO `edu_course_studyhistory` VALUES ('13', '7', '10', '49', '2', '零基础入门学习Python课程学习', '新创建视频1', '2015-10-14 03:51:07,2015-10-14 03:51:03,', '2015-10-14 11:51:07');
INSERT INTO `edu_course_studyhistory` VALUES ('14', '7', '10', '53', '1', '零基础入门学习Python课程学习', '新创建视频2', '2015-10-14 03:51:04,', '2015-10-14 11:51:04');
INSERT INTO `edu_course_studyhistory` VALUES ('15', '7', '14', '34', '1', 'XHTML CSS2 JS整站制作教程课程学习', 'XHTML CSS2 JS整站制作教程课2', '2015-10-29 09:25:40,', '2015-10-29 17:25:40');
INSERT INTO `edu_course_studyhistory` VALUES ('16', '7', '14', '33', '1', 'XHTML CSS2 JS整站制作教程课程学习', 'XHTML CSS2 JS 第二章 一节', '2015-10-29 09:25:54,', '2015-10-29 17:25:54');
INSERT INTO `edu_course_studyhistory` VALUES ('17', '6', '16', '37', '4', '20世纪西方音乐', '第一节', '2016-03-09 07:45:51,2016-02-02 06:41:09,2016-02-02 06:39:12,2016-01-30 08:57:38,', '2016-03-09 15:45:51');
INSERT INTO `edu_course_studyhistory` VALUES ('18', '10', '16', '37', '1', '20世纪西方音乐', '第一节', '2016-01-30 08:58:49,', '2016-01-30 16:58:49');
INSERT INTO `edu_course_studyhistory` VALUES ('19', '66', '24', '54', '1', 'XHTML CSS2 JS整站制作教程课程学习(2)', '第一节', '2016-02-01 02:13:11,', '2016-02-01 10:13:11');
INSERT INTO `edu_course_studyhistory` VALUES ('20', '66', '10', '44', '2', '零基础入门学习Python课程学习', '主讲课程', '2016-02-01 02:30:23,2016-02-01 02:13:55,', '2016-02-01 10:30:23');
INSERT INTO `edu_course_studyhistory` VALUES ('21', '66', '10', '5', '1', '零基础入门学习Python课程学习', '第一节', '2016-02-01 02:30:26,', '2016-02-01 10:30:26');
INSERT INTO `edu_course_studyhistory` VALUES ('22', '6', '11', '49', '2', '影想力摄影小课堂', '课程一', '2016-02-02 01:18:33,2016-02-02 01:17:47,', '2016-02-02 09:18:33');
INSERT INTO `edu_course_studyhistory` VALUES ('23', '7', '16', '37', '77', '20世纪西方音乐', '第一节', '2016-04-14 07:02:45,2016-04-14 07:01:16,2016-03-23 05:39:59,2016-03-10 06:00:17,2016-03-10 05:52:45,2016-03-10 05:46:00,2016-03-10 05:44:23,2016-03-10 05:43:53,2016-03-10 05:42:32,2016-03-10 05:38:08,2016-03-10 05:35:01,2016-03-10 03:51:18,2016-03-10 03:50:29,2016-03-10 03:49:09,2016-03-10 03:48:30,2016-03-10 03:47:47,2016-03-10 03:46:53,2016-03-10 03:45:13,2016-03-10 03:43:11,2016-03-10 03:41:22,2016-03-10 03:40:47,2016-03-10 03:40:17,2016-03-10 03:39:38,2016-03-10 03:38:30,2016-03-10 03:36:08,', '2016-04-14 15:02:45');
INSERT INTO `edu_course_studyhistory` VALUES ('24', '7', '16', '39', '5', '20世纪西方音乐', '第二节', '2016-03-10 06:00:17,2016-03-10 05:54:15,2016-03-10 03:22:31,2016-03-10 03:22:28,2016-03-08 08:55:24,', '2016-03-10 14:00:17');
INSERT INTO `edu_course_studyhistory` VALUES ('25', '7', '16', '38', '1', '20世纪西方音乐', '第一节', '2016-03-08 08:55:29,', '2016-03-08 16:55:29');
INSERT INTO `edu_course_studyhistory` VALUES ('26', '7', '17', '41', '11', 'MySql从入门到精通', '第一节', '2016-05-12 07:51:38,2016-05-12 07:45:10,2016-05-12 07:26:37,2016-05-12 07:26:05,2016-05-12 07:25:35,2016-05-12 07:24:25,2016-05-12 07:23:53,2016-05-12 07:22:04,2016-03-23 05:35:23,2016-03-09 07:53:04,2016-03-09 07:50:55,', '2016-05-12 15:51:38');
INSERT INTO `edu_course_studyhistory` VALUES ('27', '7', '10', '59', '27', '零基础入门学习Python课程学习', '视频-iframe 添加测试', '2016-03-25 01:35:08,2016-03-25 01:32:05,2016-03-25 01:30:25,2016-03-24 06:20:26,2016-03-24 05:41:59,2016-03-24 03:34:44,2016-03-24 03:31:50,2016-03-24 03:20:50,2016-03-24 03:05:12,2016-03-24 02:44:00,2016-03-23 09:32:08,2016-03-23 09:29:30,2016-03-23 05:43:22,2016-03-16 08:14:37,2016-03-16 08:13:26,2016-03-12 05:43:30,2016-03-12 05:42:40,2016-03-12 05:41:55,2016-03-12 05:34:20,2016-03-12 02:56:03,2016-03-12 02:23:54,2016-03-12 02:21:59,2016-03-12 02:20:48,2016-03-12 02:20:26,2016-03-10 08:00:08,', '2016-03-25 09:35:08');
INSERT INTO `edu_course_studyhistory` VALUES ('28', '7', '10', '62', '78', '零基础入门学习Python课程学习', '课程学习文本', '2016-05-16 07:54:13,2016-03-26 06:39:44,2016-03-26 03:27:55,2016-03-26 03:27:27,2016-03-26 02:40:48,2016-03-26 02:37:35,2016-03-26 02:37:08,2016-03-26 02:26:45,2016-03-26 02:26:43,2016-03-26 02:26:23,2016-03-26 01:54:20,2016-03-26 01:48:36,2016-03-26 01:29:23,2016-03-26 01:25:01,2016-03-26 01:23:38,2016-03-26 01:23:35,2016-03-26 01:23:34,2016-03-26 01:23:33,2016-03-26 01:23:31,2016-03-26 01:21:12,2016-03-25 06:45:58,2016-03-25 06:45:09,2016-03-25 05:46:08,2016-03-25 01:35:11,2016-03-25 01:32:52,', '2016-05-16 15:54:13');
INSERT INTO `edu_course_studyhistory` VALUES ('29', '7', '10', '60', '37', '零基础入门学习Python课程学习', '视频-乐视 添加测试', '2016-03-25 01:35:09,2016-03-25 01:32:06,2016-03-25 01:30:27,2016-03-24 06:20:27,2016-03-24 05:42:00,2016-03-24 03:32:38,2016-03-24 03:31:52,2016-03-24 03:20:51,2016-03-24 03:05:12,2016-03-24 02:44:43,2016-03-24 02:44:01,2016-03-24 01:37:25,2016-03-23 09:32:10,2016-03-23 09:29:34,2016-03-23 05:47:10,2016-03-16 08:14:33,2016-03-16 08:13:26,2016-03-12 05:43:35,2016-03-12 05:43:04,2016-03-12 05:42:23,2016-03-12 05:42:19,2016-03-12 05:42:03,2016-03-12 05:41:59,2016-03-12 05:34:18,2016-03-12 02:56:08,', '2016-03-25 09:35:09');
INSERT INTO `edu_course_studyhistory` VALUES ('30', '7', '10', '61', '62', '零基础入门学习Python课程学习', '课程音频', '2016-05-16 07:34:43,2016-05-12 06:40:43,2016-05-04 02:18:43,2016-05-04 02:17:10,2016-05-04 02:15:48,2016-05-04 01:17:21,2016-04-14 06:30:00,2016-04-08 10:41:42,2016-04-01 06:46:52,2016-04-01 06:41:13,2016-03-26 06:39:43,2016-03-26 03:27:25,2016-03-26 02:40:46,2016-03-26 02:37:35,2016-03-26 02:37:27,2016-03-26 02:26:24,2016-03-26 02:26:21,2016-03-26 02:01:28,2016-03-26 01:54:19,2016-03-26 01:23:36,2016-03-26 01:21:34,2016-03-26 01:21:05,2016-03-26 01:21:03,2016-03-25 06:45:11,2016-03-25 06:45:08,', '2016-05-16 15:34:43');
INSERT INTO `edu_course_studyhistory` VALUES ('31', '7', '10', '64', '54', '零基础入门学习Python课程学习', '课程学习图片集', '2016-05-16 07:53:48,2016-03-26 06:39:46,2016-03-26 03:27:58,2016-03-26 03:27:28,2016-03-26 02:40:50,2016-03-26 02:37:36,2016-03-26 02:37:07,2016-03-26 02:26:43,2016-03-26 01:54:20,2016-03-26 01:33:57,2016-03-25 06:45:10,2016-03-25 06:34:41,2016-03-25 06:22:30,2016-03-25 06:15:53,2016-03-25 01:35:12,2016-03-25 01:32:08,2016-03-25 01:30:41,2016-03-25 01:30:30,2016-03-24 06:07:54,2016-03-24 06:05:46,2016-03-24 05:42:04,2016-03-24 03:35:17,2016-03-24 03:32:50,2016-03-24 03:32:34,2016-03-24 03:32:29,', '2016-05-16 15:53:48');
INSERT INTO `edu_course_studyhistory` VALUES ('32', '7', '10', '65', '20', '零基础入门学习Python课程学习', '图片集一级', '2016-03-25 01:35:52,2016-03-25 01:35:13,2016-03-25 01:30:38,2016-03-24 05:42:06,2016-03-24 03:58:07,2016-03-24 03:34:34,2016-03-24 03:34:14,2016-03-24 03:21:00,2016-03-24 02:51:41,2016-03-24 01:37:16,2016-03-23 09:35:07,2016-03-23 06:36:22,2016-03-23 06:25:28,2016-03-23 06:09:27,2016-03-23 05:47:53,2016-03-16 08:12:59,2016-03-16 08:10:27,2016-03-15 07:09:21,2016-03-12 07:44:48,2016-03-12 06:11:57,', '2016-03-25 09:35:52');
INSERT INTO `edu_course_studyhistory` VALUES ('33', '7', '10', '66', '19', '零基础入门学习Python课程学习', '音频一级', '2016-03-25 01:35:51,2016-03-25 01:35:14,2016-03-25 01:30:39,2016-03-24 11:24:40,2016-03-24 05:42:07,2016-03-24 03:58:09,2016-03-24 03:34:26,2016-03-24 03:34:20,2016-03-24 03:20:56,2016-03-24 01:37:19,2016-03-23 09:31:25,2016-03-23 06:36:23,2016-03-23 06:25:29,2016-03-23 06:09:29,2016-03-23 05:47:55,2016-03-16 08:12:58,2016-03-16 08:10:31,2016-03-15 07:09:23,2016-03-12 06:11:59,', '2016-03-25 09:35:51');
INSERT INTO `edu_course_studyhistory` VALUES ('34', '7', '10', '67', '14', '零基础入门学习Python课程学习', '一级文本', '2016-03-25 01:35:15,2016-03-25 01:30:40,2016-03-24 05:42:08,2016-03-24 03:58:09,2016-03-24 03:34:40,2016-03-24 03:20:58,2016-03-24 01:37:19,2016-03-23 06:36:23,2016-03-23 06:25:30,2016-03-23 06:09:30,2016-03-23 05:47:57,2016-03-16 08:10:36,2016-03-15 07:09:25,2016-03-12 06:12:02,', '2016-03-25 09:35:15');
INSERT INTO `edu_course_studyhistory` VALUES ('35', '7', '10', '69', '139', '零基础入门学习Python课程学习', '9件事把你从消极情绪中解救出来', '2016-04-13 07:40:19,2016-04-07 01:56:47,2016-03-26 07:55:14,2016-03-26 07:53:28,2016-03-26 07:46:25,2016-03-26 06:54:04,2016-03-26 06:39:32,2016-03-26 06:17:25,2016-03-26 03:27:52,2016-03-26 03:27:32,2016-03-26 03:26:42,2016-03-26 03:25:55,2016-03-26 03:25:30,2016-03-26 03:24:53,2016-03-26 03:24:17,2016-03-26 03:23:39,2016-03-26 03:07:52,2016-03-26 03:03:28,2016-03-26 03:02:57,2016-03-26 02:46:43,2016-03-26 02:45:22,2016-03-26 02:45:00,2016-03-26 02:40:36,2016-03-26 02:39:14,2016-03-26 02:37:29,', '2016-04-13 15:40:19');
INSERT INTO `edu_course_studyhistory` VALUES ('36', '7', '12', '50', '22', '数学给宝宝带来的兴趣', '第一节', '2016-05-12 08:18:03,2016-05-12 06:36:37,2016-05-12 06:13:47,2016-05-12 03:47:15,2016-05-12 03:47:05,2016-05-07 05:49:40,2016-05-07 05:49:13,2016-05-06 08:15:11,2016-05-06 08:14:44,2016-05-06 08:13:34,2016-05-06 08:12:30,2016-04-14 07:00:25,2016-04-09 01:24:47,2016-04-08 09:47:58,2016-04-08 09:46:40,2016-04-08 09:46:07,2016-04-08 09:44:27,2016-04-07 01:43:56,2016-04-07 01:43:04,2016-04-07 01:41:52,2016-03-24 11:27:45,2016-03-23 05:34:42,', '2016-05-12 16:18:03');
INSERT INTO `edu_course_studyhistory` VALUES ('37', '7', '10', '70', '12', '零基础入门学习Python课程学习', '随堂练习', '2016-05-16 08:07:43,2016-05-16 08:03:48,2016-04-01 06:29:50,2016-03-26 06:39:59,2016-03-26 06:39:53,2016-03-26 03:27:28,2016-03-26 02:40:51,2016-03-26 02:37:36,2016-03-26 02:37:06,2016-03-26 02:26:48,2016-03-26 02:26:44,2016-03-26 01:33:59,', '2016-05-16 16:07:43');
INSERT INTO `edu_course_studyhistory` VALUES ('38', '7', '10', '76', '1', '零基础入门学习Python课程学习', '新创建视频', '2016-03-26 02:40:58,', '2016-03-26 10:40:58');
INSERT INTO `edu_course_studyhistory` VALUES ('39', '7', '10', '78', '1', '零基础入门学习Python课程学习', '新创建视频', '2016-03-26 02:45:24,', '2016-03-26 10:45:24');
INSERT INTO `edu_course_studyhistory` VALUES ('40', '7', '10', '79', '2', '零基础入门学习Python课程学习', '新创建视频', '2016-03-26 03:27:29,2016-03-26 02:46:47,', '2016-03-26 11:27:29');
INSERT INTO `edu_course_studyhistory` VALUES ('41', '7', '10', '80', '2', '零基础入门学习Python课程学习', '新创建视频', '2016-03-26 03:27:19,2016-03-26 03:26:54,', '2016-03-26 11:27:19');
INSERT INTO `edu_course_studyhistory` VALUES ('42', '7', '10', '81', '4', '零基础入门学习Python课程学习', '新创建视频', '2016-03-26 03:27:20,2016-03-26 03:27:17,2016-03-26 03:27:03,2016-03-26 03:26:56,', '2016-03-26 11:27:20');
INSERT INTO `edu_course_studyhistory` VALUES ('43', '7', '10', '83', '7', '零基础入门学习Python课程学习', '爱奇艺视频', '2016-05-16 07:32:43,2016-04-14 10:31:31,2016-03-26 06:54:08,2016-03-26 06:42:02,2016-03-26 06:42:00,2016-03-26 06:40:00,2016-03-26 06:39:55,', '2016-05-16 15:32:43');
INSERT INTO `edu_course_studyhistory` VALUES ('44', '7', '10', '85', '2', '零基础入门学习Python课程学习', '土豆网视频', '2016-04-14 10:33:47,2016-03-26 06:54:16,', '2016-04-14 18:33:47');
INSERT INTO `edu_course_studyhistory` VALUES ('45', '7', '10', '86', '1', '零基础入门学习Python课程学习', '搜狐视频', '2016-03-26 06:54:21,', '2016-03-26 14:54:21');
INSERT INTO `edu_course_studyhistory` VALUES ('46', '7', '10', '87', '3', '零基础入门学习Python课程学习', '腾讯视频', '2016-04-14 10:38:06,2016-04-14 10:32:30,2016-03-26 06:54:26,', '2016-04-14 18:38:06');
INSERT INTO `edu_course_studyhistory` VALUES ('47', '7', '10', '88', '3', '零基础入门学习Python课程学习', '56视频', '2016-04-14 10:34:30,2016-03-26 06:54:49,2016-03-26 06:54:28,', '2016-04-14 18:34:30');
INSERT INTO `edu_course_studyhistory` VALUES ('48', '7', '10', '89', '3', '零基础入门学习Python课程学习', 'pptv视频', '2016-05-04 01:04:28,2016-04-13 07:41:35,2016-03-26 06:54:46,', '2016-05-04 09:04:28');
INSERT INTO `edu_course_studyhistory` VALUES ('49', '7', '31', '102', '1', '直播-C4D零基础', 'C4D零基础第一节', '2016-03-30 03:29:35,', '2016-03-30 11:29:35');
INSERT INTO `edu_course_studyhistory` VALUES ('50', '7', '10', '117', '91', '零基础入门学习Python课程学习', '暴风视频', '2016-05-16 08:06:54,2016-05-16 08:04:18,2016-05-16 08:02:07,2016-05-16 08:01:34,2016-05-16 08:01:14,2016-05-16 07:58:01,2016-05-16 07:52:40,2016-05-16 07:49:34,2016-05-16 07:46:28,2016-05-16 07:45:58,2016-05-16 07:42:36,2016-05-16 07:41:55,2016-05-16 07:38:58,2016-05-16 07:38:51,2016-05-16 07:37:06,2016-05-16 07:31:09,2016-05-16 07:30:52,2016-05-16 07:28:04,2016-05-16 07:27:06,2016-05-16 07:26:59,2016-05-16 07:26:32,2016-05-16 07:25:06,2016-05-16 07:24:50,2016-05-16 07:24:35,2016-05-16 07:21:53,', '2016-05-16 16:06:54');
INSERT INTO `edu_course_studyhistory` VALUES ('51', '7', '13', '52', '6', '国家教师资格考试专用', '课时1', '2016-04-08 09:40:02,2016-04-08 09:38:27,2016-04-08 09:36:35,2016-04-08 09:35:13,2016-04-08 09:32:35,2016-04-08 09:31:02,', '2016-04-08 17:40:02');
INSERT INTO `edu_course_studyhistory` VALUES ('52', '7', '10', '118', '20', '零基础入门学习Python课程学习', '课后练习', '2016-04-14 10:16:04,2016-04-14 10:15:36,2016-04-14 10:13:11,2016-04-14 07:18:23,2016-04-14 07:17:40,2016-04-14 07:17:08,2016-04-14 07:16:28,2016-04-14 07:15:26,2016-04-14 07:08:57,2016-04-14 07:07:30,2016-04-14 06:53:29,2016-04-14 06:51:02,2016-04-14 06:26:15,2016-04-14 06:16:26,2016-04-14 06:15:22,2016-04-14 06:12:03,2016-04-13 07:42:51,2016-04-13 07:42:08,2016-04-09 08:06:51,2016-04-09 07:55:19,', '2016-04-14 18:16:04');
INSERT INTO `edu_course_studyhistory` VALUES ('53', '7', '10', '119', '3', '零基础入门学习Python课程学习', '第二章练习', '2016-05-04 02:12:00,2016-04-14 10:17:07,2016-04-13 07:43:34,', '2016-05-04 10:12:00');
INSERT INTO `edu_course_studyhistory` VALUES ('54', '7', '10', '122', '3', '零基础入门学习Python课程学习', '课程总练习', '2016-05-06 03:38:13,2016-04-13 07:51:46,2016-04-13 07:45:30,', '2016-05-06 11:38:13');
INSERT INTO `edu_course_studyhistory` VALUES ('55', '7', '18', '57', '2', 'Java精品课程', '视频一', '2016-05-12 07:15:37,2016-05-12 06:38:54,', '2016-05-12 15:15:37');

-- ----------------------------
-- Table structure for edu_course_subject
-- ----------------------------
DROP TABLE IF EXISTS `edu_course_subject`;
CREATE TABLE `edu_course_subject` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `COURSE_ID` int(11) NOT NULL DEFAULT '0' COMMENT '课程id',
  `SUBJECT_ID` int(11) NOT NULL DEFAULT '0' COMMENT '分类id',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `course_subject` (`COURSE_ID`,`SUBJECT_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

-- ----------------------------
-- Records of edu_course_subject
-- ----------------------------
INSERT INTO `edu_course_subject` VALUES ('13', '4', '222');
INSERT INTO `edu_course_subject` VALUES ('14', '5', '209');
INSERT INTO `edu_course_subject` VALUES ('15', '6', '209');
INSERT INTO `edu_course_subject` VALUES ('16', '3', '206');
INSERT INTO `edu_course_subject` VALUES ('17', '7', '210');
INSERT INTO `edu_course_subject` VALUES ('18', '8', '217');

-- ----------------------------
-- Table structure for edu_course_teacher
-- ----------------------------
DROP TABLE IF EXISTS `edu_course_teacher`;
CREATE TABLE `edu_course_teacher` (
  `COURSE_ID` int(11) DEFAULT NULL COMMENT '课程id',
  `TEACHER_ID` int(11) DEFAULT NULL COMMENT '讲师id',
  KEY `course_id` (`COURSE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='课程讲师关联';

-- ----------------------------
-- Records of edu_course_teacher
-- ----------------------------
INSERT INTO `edu_course_teacher` VALUES ('18', '74');
INSERT INTO `edu_course_teacher` VALUES ('22', '83');
INSERT INTO `edu_course_teacher` VALUES ('14', '75');
INSERT INTO `edu_course_teacher` VALUES ('14', '73');
INSERT INTO `edu_course_teacher` VALUES ('24', '77');
INSERT INTO `edu_course_teacher` VALUES ('24', '78');
INSERT INTO `edu_course_teacher` VALUES ('12', '77');
INSERT INTO `edu_course_teacher` VALUES ('12', '78');
INSERT INTO `edu_course_teacher` VALUES ('12', '73');
INSERT INTO `edu_course_teacher` VALUES ('19', '75');
INSERT INTO `edu_course_teacher` VALUES ('19', '74');
INSERT INTO `edu_course_teacher` VALUES ('19', '73');
INSERT INTO `edu_course_teacher` VALUES ('16', '75');
INSERT INTO `edu_course_teacher` VALUES ('16', '74');
INSERT INTO `edu_course_teacher` VALUES ('16', '73');
INSERT INTO `edu_course_teacher` VALUES ('17', '74');
INSERT INTO `edu_course_teacher` VALUES ('23', '74');
INSERT INTO `edu_course_teacher` VALUES ('23', '75');
INSERT INTO `edu_course_teacher` VALUES ('21', '74');
INSERT INTO `edu_course_teacher` VALUES ('13', '75');
INSERT INTO `edu_course_teacher` VALUES ('13', '74');
INSERT INTO `edu_course_teacher` VALUES ('13', '73');
INSERT INTO `edu_course_teacher` VALUES ('25', '80');
INSERT INTO `edu_course_teacher` VALUES ('25', '73');
INSERT INTO `edu_course_teacher` VALUES ('11', '75');
INSERT INTO `edu_course_teacher` VALUES ('11', '74');
INSERT INTO `edu_course_teacher` VALUES ('11', '73');
INSERT INTO `edu_course_teacher` VALUES ('36', '80');
INSERT INTO `edu_course_teacher` VALUES ('32', '80');
INSERT INTO `edu_course_teacher` VALUES ('32', '77');
INSERT INTO `edu_course_teacher` VALUES ('15', '74');
INSERT INTO `edu_course_teacher` VALUES ('20', '81');
INSERT INTO `edu_course_teacher` VALUES ('20', '83');
INSERT INTO `edu_course_teacher` VALUES ('10', '80');
INSERT INTO `edu_course_teacher` VALUES ('10', '73');
INSERT INTO `edu_course_teacher` VALUES ('10', '83');
INSERT INTO `edu_course_teacher` VALUES ('10', '82');
INSERT INTO `edu_course_teacher` VALUES ('37', '81');
INSERT INTO `edu_course_teacher` VALUES ('37', '76');
INSERT INTO `edu_course_teacher` VALUES ('39', '76');
INSERT INTO `edu_course_teacher` VALUES ('38', '76');
INSERT INTO `edu_course_teacher` VALUES ('33', '75');
INSERT INTO `edu_course_teacher` VALUES ('33', '76');
INSERT INTO `edu_course_teacher` VALUES ('27', '80');
INSERT INTO `edu_course_teacher` VALUES ('31', '76');
INSERT INTO `edu_course_teacher` VALUES ('35', '82');
INSERT INTO `edu_course_teacher` VALUES ('34', '76');
INSERT INTO `edu_course_teacher` VALUES ('34', '77');
INSERT INTO `edu_course_teacher` VALUES ('42', '81');
INSERT INTO `edu_course_teacher` VALUES ('29', '83');
INSERT INTO `edu_course_teacher` VALUES ('29', '82');
INSERT INTO `edu_course_teacher` VALUES ('43', '83');

-- ----------------------------
-- Table structure for edu_data_clean
-- ----------------------------
DROP TABLE IF EXISTS `edu_data_clean`;
CREATE TABLE `edu_data_clean` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(200) DEFAULT NULL COMMENT '名称',
  `desc` varchar(300) DEFAULT NULL COMMENT '描述',
  `sql` varchar(600) DEFAULT NULL COMMENT 'sql',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='数据清除表';

-- ----------------------------
-- Records of edu_data_clean
-- ----------------------------
INSERT INTO `edu_data_clean` VALUES ('1', '文章', '文章edu_article , 文章内容edu_article_content ,文章评论edu_comment，文章点赞记录 数据清除', 'TRUNCATE TABLE `edu_article`; TRUNCATE TABLE `edu_article_content`;DELETE FROM `edu_comment` WHERE `edu_comment`.`TYPE`=1;DELETE FROM `edu_praise` WHERE `edu_praise`.`TYPE`=3;');
INSERT INTO `edu_data_clean` VALUES ('2', '课程卡 学员卡', '课程卡主表，课程卡编码，学员卡主表，学员卡编码 ，课程卡和课程关联表，学员卡和课程关联表 数据删除', 'TRUNCATE TABLE `edu_card`; TRUNCATE TABLE `edu_card_code`; TRUNCATE TABLE `edu_card_course`;TRUNCATE TABLE `edu_card_user_course`;');
INSERT INTO `edu_data_clean` VALUES ('3', '优惠券 优惠券编码', '优惠券,优惠券编码,优惠券和课程/用户关联表edu_coupon_limit', 'TRUNCATE TABLE `edu_coupon`;TRUNCATE TABLE `edu_coupon_code`;TRUNCATE TABLE `edu_coupon_limit`;');
INSERT INTO `edu_data_clean` VALUES ('4', '课程', '课程表，用户课程收藏，课程章节，课程章节图片集，用户课程笔记，用户课程学习记录，课程和专业关联表，课程和讲师关联表， 推荐课程,课程评论,课程订单,用户课程购物车删除', 'TRUNCATE TABLE `edu_course`;TRUNCATE TABLE `edu_course_favorites`;TRUNCATE TABLE `edu_course_kpoint`;TRUNCATE TABLE `edu_course_kpoint_atlas`;TRUNCATE TABLE `edu_course_note`;TRUNCATE TABLE `edu_course_studyhistory`;TRUNCATE TABLE `edu_course_subject`;TRUNCATE TABLE `edu_course_teacher`;TRUNCATE TABLE `edu_website_course_detail`;DELETE FROM `edu_comment` WHERE `edu_comment`.`TYPE`=2;TRUNCATE TABLE `edu_orders`;TRUNCATE TABLE `edu_trxorder_detail`;TRUNCATE TABLE `edu_shopcart`;');
INSERT INTO `edu_data_clean` VALUES ('5', '邮件发送记录', '邮件发送记录 edu_emailsend_history 删除', 'DELETE FROM `edu_emailsend_history`;');
INSERT INTO `edu_data_clean` VALUES ('6', '帮助中心', '帮助中心 数据清除', 'TRUNCATE TABLE `edu_help_menu`;');
INSERT INTO `edu_data_clean` VALUES ('7', '手机短信发送记录', '手机短信发送记录 删除', 'TRUNCATE TABLE `edu_mobilesend_history`;');
INSERT INTO `edu_data_clean` VALUES ('8', '用户消息接收记录', '用户消息接收记录edu_msg_receive删除', 'TRUNCATE TABLE `edu_msg_receive`;');
INSERT INTO `edu_data_clean` VALUES ('9', '系统消息记录', '系统消息记录edu_msg_system删除', 'TRUNCATE TABLE `edu_msg_system`;');
INSERT INTO `edu_data_clean` VALUES ('10', '课程订单', '课程订单edu_orders 订单包含课程表 记录删除', 'TRUNCATE TABLE `edu_orders`;TRUNCATE TABLE `edu_trxorder_detail`;');
INSERT INTO `edu_data_clean` VALUES ('11', '问答', '问答列表,问答评论,问答评论点赞记录,问答和问答标签关联表 数据删除  ', 'TRUNCATE TABLE `edu_questions`;TRUNCATE TABLE `edu_questions_comment`;DELETE FROM `edu_praise` WHERE `edu_praise`.`TYPE`=1 OR `edu_praise`.`TYPE`=2;TRUNCATE TABLE `edu_questions_tag_relation`;');
INSERT INTO `edu_data_clean` VALUES ('12', '问答标签', '问答标签数据删除', 'DELETE FROM `edu_questions_tag`;');
INSERT INTO `edu_data_clean` VALUES ('13', '购物车', '购物车', 'TRUNCATE TABLE `edu_shopcart`;');
INSERT INTO `edu_data_clean` VALUES ('14', '网站统计', '网站统计', 'TRUNCATE TABLE `edu_statistics_day`;');
INSERT INTO `edu_data_clean` VALUES ('15', '讲师', '讲师', 'DELETE FROM `edu_teacher`;');
INSERT INTO `edu_data_clean` VALUES ('16', '用户', '用户列表 用户登录记录 用户第三方登录 ', 'DELETE FROM `edu_user`;TRUNCATE TABLE `edu_user_login_log`;TRUNCATE TABLE `edu_user_profile`;');
INSERT INTO `edu_data_clean` VALUES ('17', '广告图', '广告图', 'TRUNCATE TABLE `edu_website_images`;');
INSERT INTO `edu_data_clean` VALUES ('18', '后台用户登录日志', '后台用户登录日志', 'TRUNCATE TABLE `sys_login_log`;');
INSERT INTO `edu_data_clean` VALUES ('19', '专业', '专业', 'DELETE FROM `sys_subject`;');

-- ----------------------------
-- Table structure for edu_emailsend_history
-- ----------------------------
DROP TABLE IF EXISTS `edu_emailsend_history`;
CREATE TABLE `edu_emailsend_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` longtext,
  `user_id` int(11) DEFAULT '0',
  `title` varchar(300) DEFAULT '' COMMENT '邮箱标题',
  `content` text COMMENT '邮箱正文',
  `create_time` datetime DEFAULT NULL,
  `send_time` datetime DEFAULT NULL COMMENT '定时发送时间',
  `status` tinyint(3) DEFAULT '1' COMMENT '1 已发送 2 未发送',
  `type` tinyint(3) DEFAULT '1' COMMENT '1 普通 2 定时',
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COMMENT='邮件发送记录';

-- ----------------------------
-- Records of edu_emailsend_history
-- ----------------------------
INSERT INTO `edu_emailsend_history` VALUES ('1', '916033995@qq.com', '1', '元宵节', '元宵节快乐<br />', '2016-02-22 10:43:39', '2016-02-22 10:43:39', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('2', '916033995@qq.com', '1', '元宵节', '元宵节快乐<br />', '2016-02-22 10:56:34', '2016-02-22 10:56:34', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('3', '916033995@qq.com', '1', 'laosdong', 'laosdonglaosdonglaosdonglaosdonglaosdonglaosdonglaosdong<img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/2.gif\" alt=\"\" border=\"0\" />', '2016-05-11 15:29:08', '2016-05-11 15:29:08', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('4', '2907345246@qq.com', '1', 'fuqinlsoio', '12342222222222222222222', '2016-05-11 16:22:02', '2016-05-11 16:22:02', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('5', '2907345246@qq.com', '1', 'sosnooweno', '123412341234<img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/2.gif\" alt=\"\" border=\"0\" />', '2016-05-11 16:25:08', '2016-05-11 16:25:08', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('6', '2907345246@qq.com', '1', '定时邮件会有', '<span style=\"color:red;\">定时邮件会有</span><span style=\"color:red;\">定时邮件会有</span><span style=\"color:red;\">定时邮件会有</span><span style=\"color:red;\">定时邮件会有</span><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/10.gif\" alt=\"\" border=\"0\" />', '2016-05-11 16:30:43', '2016-05-11 16:30:43', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('7', '2907345246@qq.com', '1', 'qwerqwer', 'asdfasdfasdfasdfasdf<img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/13.gif\" alt=\"\" border=\"0\" />', '2016-05-11 16:45:31', '2016-05-11 16:45:31', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('8', '2907345246@qq.com', '1', '1234', '1234123412341', '2016-05-11 16:57:11', '2016-05-11 16:57:11', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('9', '2907345246@qq.com', '1', '1234', '12341234123412341234', '2016-05-11 17:08:00', '2016-05-11 17:08:00', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('10', '2907345246@qq.com', '1', '123412341', '1234123412341234', '2016-05-11 17:09:21', '2016-05-11 17:09:21', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('11', '2907345246@qq.com', '1', '123412341234', '1234123412342222222222222', '2016-05-11 17:10:20', '2016-05-11 17:10:20', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('12', '2907345246@qq.com', '1', '12341234', '111111111111111111111', '2016-05-11 17:13:46', '2016-05-11 17:13:46', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('13', '2907345246@qq.com', '1', 'qweronoo;ns', '<img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/15.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/15.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/15.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/15.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/15.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/15.gif\" alt=\"\" border=\"0\" />', '2016-05-11 17:15:33', '2016-05-11 17:15:33', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('14', '2907345246@qq.com', '1', '12341234', '<img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/5.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/5.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/5.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/5.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/5.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/5.gif\" alt=\"\" border=\"0\" />', '2016-05-11 17:18:10', '2016-05-11 17:18:10', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('15', '2907345246@qq.com', '1', '12341234', '<img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/4.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/4.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/4.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/4.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/4.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/4.gif\" alt=\"\" border=\"0\" />', '2016-05-11 17:20:13', '2016-05-11 17:20:13', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('16', '2907345246@qq.com', '1', '12341234', '12341234123', '2016-05-11 17:25:04', '2016-05-11 17:25:04', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('17', '2907345246@qq.com', '1', 'laonwe', '<img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/2.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/2.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/2.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/2.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/2.gif\" alt=\"\" border=\"0\" /><img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/2.gif\" alt=\"\" border=\"0\" />', '2016-05-11 17:26:31', '2016-05-11 17:26:31', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('18', '2907345246@qq.com', '1', 'lq234lok', 'qwerqwerqwer', '2016-05-11 17:33:17', '2016-05-11 17:33:17', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('19', '2907345246@qq.com', '1', '12341234', '1234122222222222222', '2016-05-11 17:34:51', '2016-05-11 17:34:51', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('20', '2907345246@qq.com', '1', '12341234', '123412322222', '2016-05-11 17:36:47', '2016-05-11 17:36:47', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('21', '2907345246@qq.com', '1', 'lqweonoos', 'asdfasdfasdfasdfasdf', '2016-05-11 17:38:32', '2016-05-11 17:38:32', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('22', '2907345246@qq.com', '1', 'hhhh', '<img class=\"vam\" src=\"http://127.0.0.1/kindeditor/plugins/emoticons/images/2.gif\" alt=\"\" border=\"0\" />', '2016-05-11 17:59:09', '2016-05-11 17:59:09', '1', '1');
INSERT INTO `edu_emailsend_history` VALUES ('23', '2907345246@qq.com', '1', '1234', '12341234', '2016-05-11 18:01:18', '2016-05-11 18:01:18', '1', '1');

-- ----------------------------
-- Table structure for edu_help_menu
-- ----------------------------
DROP TABLE IF EXISTS `edu_help_menu`;
CREATE TABLE `edu_help_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT '0' COMMENT '父级分类ID，默认0为一级分类',
  `name` varchar(20) DEFAULT '' COMMENT '菜单名称',
  `create_time` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `content` longtext COMMENT '菜单内容',
  `sort` int(11) DEFAULT '0' COMMENT '排序  倒叙',
  `varchar` varchar(200) DEFAULT NULL,
  `link_building` varchar(255) DEFAULT NULL COMMENT '外链字段',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=202 DEFAULT CHARSET=utf8 COMMENT='帮助菜单';

-- ----------------------------
-- Records of edu_help_menu
-- ----------------------------
INSERT INTO `edu_help_menu` VALUES ('171', '0', '新手指南', '2014-10-19 21:34:19', '', '100', null, null);
INSERT INTO `edu_help_menu` VALUES ('172', '171', '注册登录', '2014-10-19 21:34:39', '<h6 class=\"hLh30\">\r\n	<b class=\"grayCol3 fsize14\">一、注册</b> \r\n</h6>\r\n<p>\r\n	(1)、点击页面右上角的“登录”按钮。字样\r\n</p>\r\n<p>\r\n	(2)、弹出页面，选择注册，输入注册邮箱、手机号、密码、验证码相关信息，点击“注册”即可完成。<br />\r\n<img src=\"http://121.42.48.126:8082/mooc/images/upload/helpcontent/20160219/1455871197039.png\" alt=\"\" /><br />\r\n<br />\r\n</p>', '100', null, '');
INSERT INTO `edu_help_menu` VALUES ('173', '171', '购课流程', '2014-10-19 21:58:21', '<div class=\"mt10\">\r\n	<p>\r\n		(1)、注册，登录；\r\n	</p>\r\n	<p>\r\n		(2)、选择要购买的课程；\r\n	</p>\r\n	<p>\r\n		(3)、点击“立即购买”；\r\n	</p>\r\n	<p class=\"mt10\">\r\n		(4)、提交订单；\r\n	</p>\r\n	<p class=\"mt10\">\r\n		(5)、点击“立即支付”<span id=\"transmark\"></span>，通过网上银行或支付宝支付即可；\r\n	</p>\r\n</div>', '99', null, '');
INSERT INTO `edu_help_menu` VALUES ('177', '0', '课程学习', '2014-10-19 21:59:19', '', '99', null, null);
INSERT INTO `edu_help_menu` VALUES ('178', '177', '学习流程', '2014-10-19 21:59:38', '(1) 登录<br />\r\n(2) 进入个人中心<br />\r\n(3) 我的课程<br />\r\n<br />', '100', null, '');
INSERT INTO `edu_help_menu` VALUES ('180', '0', '用户中心', '2014-10-19 22:00:10', '', '98', null, null);
INSERT INTO `edu_help_menu` VALUES ('181', '180', '账户设置', '2014-10-19 22:00:29', '(1) 登录<br />\r\n<span id=\"transmark\">(2) 进入个人中心<br />\r\n(3) 基本资料<br />\r\n<br />\r\n</span>', '100', null, '');
INSERT INTO `edu_help_menu` VALUES ('193', '0', '关于我们', '2014-10-19 22:03:51', '小豆云课堂专业的直播课程平台', '93', null, '');
INSERT INTO `edu_help_menu` VALUES ('194', '0', '联系我们', '2014-10-19 22:04:37', '联系我们 <span style=\"line-height:1.5;\">&nbsp;</span><span>Email：xiejinlong@gukeer.cc</span><br />', '92', null, '');
INSERT INTO `edu_help_menu` VALUES ('200', '0', '产品介绍', '2016-02-19 13:35:26', '<a target=\"_blank\" href=\"http://www.gukeer.cc\">我们给您提供:网络课堂 \\ MOOC平台 \\ 校园学习平<span id=\"transmark\"></span>台 \\ E-leaning系统 \\ 视频建站</a><br />', '0', null, '');

-- ----------------------------
-- Table structure for edu_live_action
-- ----------------------------
DROP TABLE IF EXISTS `edu_live_action`;
CREATE TABLE `edu_live_action` (
  `id` bigint(64) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` varchar(64) DEFAULT NULL COMMENT '用户id',
  `course_kpoint_id` int(11) DEFAULT NULL COMMENT '课程id',
  `entry_time` datetime DEFAULT NULL COMMENT '进入时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of edu_live_action
-- ----------------------------
INSERT INTO `edu_live_action` VALUES ('1', '1', '133', '2016-10-27 10:02:09');
INSERT INTO `edu_live_action` VALUES ('2', '1', '102', '2016-10-31 10:28:31');
INSERT INTO `edu_live_action` VALUES ('3', '1', '187', '2016-11-11 16:16:17');
INSERT INTO `edu_live_action` VALUES ('4', '1', '180', '2016-11-16 17:25:21');
INSERT INTO `edu_live_action` VALUES ('5', '1', '192', '2016-11-16 17:33:55');
INSERT INTO `edu_live_action` VALUES ('6', '1', '188', '2016-11-16 17:44:23');
INSERT INTO `edu_live_action` VALUES ('7', '1', '193', '2016-11-24 09:14:38');

-- ----------------------------
-- Table structure for edu_mobilesend_history
-- ----------------------------
DROP TABLE IF EXISTS `edu_mobilesend_history`;
CREATE TABLE `edu_mobilesend_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mobile` text,
  `user_id` int(11) DEFAULT NULL,
  `content` text,
  `create_time` datetime DEFAULT NULL,
  `send_time` datetime DEFAULT NULL COMMENT '定时发送时间',
  `status` tinyint(3) DEFAULT '1' COMMENT '1 已发送 2 未发送',
  `type` tinyint(3) DEFAULT '1' COMMENT '1 正常 2 定时',
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='手机短信发送记录';

-- ----------------------------
-- Records of edu_mobilesend_history
-- ----------------------------

-- ----------------------------
-- Table structure for edu_msg_receive
-- ----------------------------
DROP TABLE IF EXISTS `edu_msg_receive`;
CREATE TABLE `edu_msg_receive` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `ADD_TIME` timestamp NULL DEFAULT NULL COMMENT '添加时间',
  `CUS_ID` int(11) DEFAULT '0' COMMENT '发信人用户id',
  `UPDATE_TIME` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `CONTENT` text COMMENT '信内容',
  `TYPE` tinyint(3) DEFAULT '0' COMMENT '类型1系统通知2站内信',
  `STATUS` tinyint(3) DEFAULT '0' COMMENT '0未读1已读2接受3拒绝4黑名单',
  `RECEIVING_CUSID` int(11) DEFAULT '0' COMMENT '收信人id',
  `GROUP_ID` int(11) DEFAULT '0' COMMENT '申请加入群 同意之后所需要的字段',
  `SHOWNAME` varchar(50) NOT NULL DEFAULT '' COMMENT '会员名',
  PRIMARY KEY (`ID`),
  KEY `CUS_ID` (`CUS_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='站内信';

-- ----------------------------
-- Records of edu_msg_receive
-- ----------------------------
INSERT INTO `edu_msg_receive` VALUES ('17', '2016-11-09 14:00:27', '0', '2016-11-16 11:17:11', 'dog cat birds<br />', '1', '1', '1', null, '');
INSERT INTO `edu_msg_receive` VALUES ('18', '2016-11-09 14:00:27', '0', '2016-11-16 11:17:11', 'dog cat birds<br />', '1', '1', '1', null, '');
INSERT INTO `edu_msg_receive` VALUES ('19', '2016-11-09 14:00:29', '0', '2016-11-16 11:17:11', 'dog cat birds<br />', '1', '1', '1', null, '');
INSERT INTO `edu_msg_receive` VALUES ('20', '2016-11-09 14:00:29', '0', '2016-11-16 11:17:11', 'dog cat birds<br />', '1', '1', '1', null, '');
INSERT INTO `edu_msg_receive` VALUES ('21', '2016-11-09 14:00:29', '0', '2016-11-16 11:17:11', 'dog cat birds<br />', '1', '1', '1', null, '');
INSERT INTO `edu_msg_receive` VALUES ('22', '2016-11-16 11:17:11', '0', '2016-11-16 11:17:11', 'dsfaesgf', '1', '1', '1', null, '测试学生');
INSERT INTO `edu_msg_receive` VALUES ('23', '2016-11-16 11:17:11', '0', '2016-11-16 11:17:11', 'hahahahahahahhahahhahahahah<br />', '1', '1', '1', null, '测试学生');
INSERT INTO `edu_msg_receive` VALUES ('24', '2016-11-16 11:17:11', '0', '2016-11-16 11:17:11', '点击全站系统消息<br />', '1', '1', '1', null, '测试学生');

-- ----------------------------
-- Table structure for edu_msg_system
-- ----------------------------
DROP TABLE IF EXISTS `edu_msg_system`;
CREATE TABLE `edu_msg_system` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `ADD_TIME` timestamp NULL DEFAULT NULL COMMENT '添加时间',
  `UPDATE_TIME` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `CONTENT` text COMMENT '信内容',
  `STATUS` tinyint(3) DEFAULT '0' COMMENT '0正常1删除2过期',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='系统消息';

-- ----------------------------
-- Records of edu_msg_system
-- ----------------------------
INSERT INTO `edu_msg_system` VALUES ('1', '2015-08-31 09:31:27', '2016-05-22 00:40:00', '欢迎来到谷壳教育,希望你们能愉快的学习<br />', '2');
INSERT INTO `edu_msg_system` VALUES ('2', '2016-11-09 13:26:00', '2016-11-09 13:26:00', 'dsfaesgf', '0');
INSERT INTO `edu_msg_system` VALUES ('3', '2016-11-09 13:26:19', '2016-11-09 13:26:19', 'hahahahahahahhahahhahahahah<br />', '0');
INSERT INTO `edu_msg_system` VALUES ('4', '2016-11-09 13:35:48', '2016-11-09 13:35:45', '点击全站系统消息<br />', '0');

-- ----------------------------
-- Table structure for edu_orders
-- ----------------------------
DROP TABLE IF EXISTS `edu_orders`;
CREATE TABLE `edu_orders` (
  `ORDER_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `USER_ID` int(11) DEFAULT '0' COMMENT '用户ID',
  `ORDER_NO` varchar(50) DEFAULT NULL COMMENT '订单号',
  `SUM_MONEY` decimal(10,2) DEFAULT '0.00' COMMENT '订单总金额',
  `STATES` varchar(10) DEFAULT NULL COMMENT '订单状态 SUCCESS已支付 INIT未支付  CANCEL已取消',
  `CREATE_TIME` timestamp NULL DEFAULT NULL COMMENT '订单创建时间',
  `PAY_TIME` timestamp NULL DEFAULT NULL COMMENT '订单支付时间',
  `SYS_USER_ID` int(11) DEFAULT '0' COMMENT '审核用户ID',
  `PAY_TYPE` varchar(50) DEFAULT 'ALIPAY' COMMENT '支付类型',
  `req_channel` varchar(20) DEFAULT NULL COMMENT '请求渠道(WEB,APP)',
  `description` varchar(500) DEFAULT NULL COMMENT '备用描述',
  `version` int(11) DEFAULT NULL COMMENT '乐观锁版本号',
  `req_ip` varchar(15) DEFAULT NULL COMMENT '客户端IP',
  `order_amount` decimal(10,2) DEFAULT NULL COMMENT '订单原始金额',
  `coupon_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠券金额',
  `couponCode_id` int(11) DEFAULT NULL COMMENT '优惠券编码id',
  `siyecao_orderid` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ORDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='课程订单表';

-- ----------------------------
-- Records of edu_orders
-- ----------------------------

-- ----------------------------
-- Table structure for edu_parent
-- ----------------------------
DROP TABLE IF EXISTS `edu_parent`;
CREATE TABLE `edu_parent` (
  `parent_uid` varchar(50) DEFAULT NULL,
  `child_uid` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of edu_parent
-- ----------------------------
INSERT INTO `edu_parent` VALUES ('0', '0');

-- ----------------------------
-- Table structure for edu_praise
-- ----------------------------
DROP TABLE IF EXISTS `edu_praise`;
CREATE TABLE `edu_praise` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `USER_ID` int(11) DEFAULT NULL COMMENT '用户id',
  `TARGET_ID` int(11) DEFAULT NULL COMMENT '点赞的对象id',
  `TYPE` int(11) DEFAULT NULL COMMENT '点赞类型 1问答点赞 2问答评论点赞 3 文章点赞数4 评论点赞',
  `ADD_TIME` datetime DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8 COMMENT='所有的点赞表';

-- ----------------------------
-- Records of edu_praise
-- ----------------------------
INSERT INTO `edu_praise` VALUES ('33', '7', '12', '4', '2015-08-28 11:49:37');
INSERT INTO `edu_praise` VALUES ('34', '7', '14', '4', '2015-08-28 15:43:17');
INSERT INTO `edu_praise` VALUES ('35', '7', '20', '4', '2015-08-28 16:28:54');
INSERT INTO `edu_praise` VALUES ('36', '7', '22', '4', '2015-08-28 16:52:31');
INSERT INTO `edu_praise` VALUES ('37', '7', '26', '4', '2015-08-29 10:26:23');
INSERT INTO `edu_praise` VALUES ('38', '7', '27', '4', '2015-08-29 10:26:55');
INSERT INTO `edu_praise` VALUES ('39', '7', '32', '4', '2015-08-29 10:41:30');
INSERT INTO `edu_praise` VALUES ('43', '7', '52', '4', '2015-09-01 18:42:47');
INSERT INTO `edu_praise` VALUES ('44', '7', '35', '4', '2015-09-08 17:36:45');
INSERT INTO `edu_praise` VALUES ('45', '7', '54', '4', '2015-09-09 11:55:38');
INSERT INTO `edu_praise` VALUES ('60', '7', '10', '4', '2015-09-19 16:49:20');
INSERT INTO `edu_praise` VALUES ('65', '7', '67', '4', '2015-09-19 17:34:49');
INSERT INTO `edu_praise` VALUES ('66', '7', '69', '4', '2015-09-19 17:34:54');
INSERT INTO `edu_praise` VALUES ('71', '6', '58', '4', '2015-09-24 10:27:03');
INSERT INTO `edu_praise` VALUES ('72', '6', '35', '4', '2015-09-24 10:27:16');
INSERT INTO `edu_praise` VALUES ('73', '6', '52', '4', '2015-09-24 15:05:21');
INSERT INTO `edu_praise` VALUES ('74', '6', '87', '4', '2015-09-24 15:05:25');
INSERT INTO `edu_praise` VALUES ('76', '6', '90', '4', '2015-09-24 15:11:07');
INSERT INTO `edu_praise` VALUES ('77', '6', '89', '4', '2015-09-24 15:11:12');
INSERT INTO `edu_praise` VALUES ('78', '6', '57', '4', '2015-09-24 15:11:15');
INSERT INTO `edu_praise` VALUES ('79', '6', '88', '4', '2015-09-24 15:11:37');
INSERT INTO `edu_praise` VALUES ('83', '7', '9', '4', '2016-01-13 18:21:04');
INSERT INTO `edu_praise` VALUES ('85', '7', '11', '4', '2016-04-01 11:30:13');

-- ----------------------------
-- Table structure for edu_questions
-- ----------------------------
DROP TABLE IF EXISTS `edu_questions`;
CREATE TABLE `edu_questions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `CUS_ID` int(11) DEFAULT NULL COMMENT '创建人id',
  `TITLE` varchar(100) DEFAULT NULL COMMENT '问答标题',
  `CONTENT` text COMMENT '问答内容',
  `TYPE` int(1) DEFAULT NULL COMMENT '分类 1课程问答 2 学习分享',
  `STATUS` int(1) DEFAULT '0' COMMENT '状态 0可回复1不可回复（采纳最佳答案后改为1 ）',
  `REPLY_COUNT` int(11) DEFAULT '0' COMMENT '问答回复数量',
  `BROWSE_COUNT` int(11) DEFAULT '0' COMMENT '问答浏览次数',
  `PRAISE_COUNT` int(11) DEFAULT '0' COMMENT '问答点赞数量',
  `ADD_TIME` datetime DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='问答';

-- ----------------------------
-- Records of edu_questions
-- ----------------------------

-- ----------------------------
-- Table structure for edu_questions_comment
-- ----------------------------
DROP TABLE IF EXISTS `edu_questions_comment`;
CREATE TABLE `edu_questions_comment` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `CUS_ID` int(11) DEFAULT NULL COMMENT '评论人id',
  `QUESTION_ID` int(11) DEFAULT NULL COMMENT '问答id',
  `CONTENT` varchar(300) DEFAULT NULL COMMENT '评论内容',
  `IS_BEST` int(1) DEFAULT NULL COMMENT '是否最佳答案 0否1是',
  `REPLY_COUNT` int(11) DEFAULT '0' COMMENT '回复数量',
  `PRAISE_COUNT` int(11) DEFAULT '0' COMMENT '点赞数',
  `ADD_TIME` datetime DEFAULT NULL COMMENT '回复时间',
  `COMMENT_ID` int(11) DEFAULT '0' COMMENT '父级评论id',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='问答评论';

-- ----------------------------
-- Records of edu_questions_comment
-- ----------------------------

-- ----------------------------
-- Table structure for edu_questions_tag
-- ----------------------------
DROP TABLE IF EXISTS `edu_questions_tag`;
CREATE TABLE `edu_questions_tag` (
  `QUESTIONS_TAG_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `QUESTIONS_TAG_NAME` varchar(45) DEFAULT NULL COMMENT '标签名',
  `STATUS` int(1) DEFAULT NULL COMMENT '状态0默认1删除',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '创建时间',
  `PARENT_ID` varchar(45) DEFAULT NULL COMMENT '父级id',
  PRIMARY KEY (`QUESTIONS_TAG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='问答标签';

-- ----------------------------
-- Records of edu_questions_tag
-- ----------------------------

-- ----------------------------
-- Table structure for edu_questions_tag_relation
-- ----------------------------
DROP TABLE IF EXISTS `edu_questions_tag_relation`;
CREATE TABLE `edu_questions_tag_relation` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `QUESTIONS_ID` int(11) DEFAULT NULL COMMENT '问答id',
  `QUESTIONS_TAG_ID` int(11) DEFAULT NULL COMMENT '问答标签id',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of edu_questions_tag_relation
-- ----------------------------

-- ----------------------------
-- Table structure for edu_school
-- ----------------------------
DROP TABLE IF EXISTS `edu_school`;
CREATE TABLE `edu_school` (
  `SCHOOL_ID` varchar(50) NOT NULL COMMENT '学校id ',
  `SCHOOL_NAME` varchar(255) DEFAULT NULL COMMENT '学校名称',
  `SCHOOL_TYPE` varchar(255) DEFAULT NULL COMMENT '学校类型：小学，中学，中小学等',
  `IS_AVALIABLE` int(11) DEFAULT NULL COMMENT '是否可用',
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13230 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of edu_school
-- ----------------------------
INSERT INTO `edu_school` VALUES ('12312312312311', 'testa4', 'jfdaadf', null, '13229');

-- ----------------------------
-- Table structure for edu_shopcart
-- ----------------------------
DROP TABLE IF EXISTS `edu_shopcart`;
CREATE TABLE `edu_shopcart` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `goodsid` int(10) unsigned NOT NULL COMMENT '商品id',
  `userid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` int(11) NOT NULL DEFAULT '1' COMMENT '类型1课程2套餐',
  `add_time` datetime DEFAULT NULL COMMENT '加增时间',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COMMENT='购物车';

-- ----------------------------
-- Records of edu_shopcart
-- ----------------------------
INSERT INTO `edu_shopcart` VALUES ('3', '11', '10', '1', '2016-03-18 10:02:17');
INSERT INTO `edu_shopcart` VALUES ('19', '34', '7', '1', '2016-04-09 09:22:53');
INSERT INTO `edu_shopcart` VALUES ('20', '11', '7', '1', '2016-04-09 09:22:53');
INSERT INTO `edu_shopcart` VALUES ('21', '19', '7', '1', '2016-04-14 15:02:10');
INSERT INTO `edu_shopcart` VALUES ('22', '33', '101', '1', '2016-05-26 13:03:22');
INSERT INTO `edu_shopcart` VALUES ('23', '39', '101', '1', '2016-05-27 12:19:19');
INSERT INTO `edu_shopcart` VALUES ('24', '33', '100', '1', '2016-05-27 12:58:32');

-- ----------------------------
-- Table structure for edu_statistics_day
-- ----------------------------
DROP TABLE IF EXISTS `edu_statistics_day`;
CREATE TABLE `edu_statistics_day` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `STATISTICS_TIME` datetime NOT NULL COMMENT '统计日期',
  `LOGIN_NUM` int(11) NOT NULL DEFAULT '0' COMMENT '登录人数（活跃人数 ）',
  `CREATE_TIME` datetime NOT NULL COMMENT '生成时间',
  `REGISTERED_NUM` int(11) NOT NULL COMMENT '注册人数',
  `ORDER_NUM` int(11) NOT NULL COMMENT '所有订单数',
  `ORDER_SUCCESS_NUM` int(11) NOT NULL COMMENT '已支付订单数',
  `ORDER_INIT_NUM` int(11) NOT NULL COMMENT '未支付订单数',
  `ORDER_CLOSED_NUM` int(11) NOT NULL COMMENT '已取消的订单数',
  `INCOME` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '营收额',
  `VIDEO_VIEWING_NUM` int(11) NOT NULL DEFAULT '0' COMMENT '每日播放视频数',
  `DAILY_USER_NUMBER` int(11) DEFAULT '0' COMMENT '每日用户数',
  `DAILY_COURSE_NUMBER` int(11) DEFAULT '0' COMMENT '每日课程数',
  PRIMARY KEY (`ID`),
  KEY `STATISTICS_TIME` (`STATISTICS_TIME`)
) ENGINE=InnoDB AUTO_INCREMENT=1598 DEFAULT CHARSET=utf8 COMMENT='网站统计日数据';

-- ----------------------------
-- Records of edu_statistics_day
-- ----------------------------
INSERT INTO `edu_statistics_day` VALUES ('1165', '2015-01-01 00:00:00', '1164', '2016-01-25 06:38:19', '582', '775', '290', '421', '232', '2331.00', '316', '19', '9339');
INSERT INTO `edu_statistics_day` VALUES ('1166', '2015-01-02 00:00:00', '1164', '2016-01-25 06:38:19', '581', '776', '290', '420', '231', '2332.00', '315', '22', '9344');
INSERT INTO `edu_statistics_day` VALUES ('1167', '2015-01-03 00:00:00', '1164', '2016-01-25 06:38:19', '581', '775', '289', '419', '230', '2333.00', '315', '25', '9349');
INSERT INTO `edu_statistics_day` VALUES ('1168', '2015-01-04 00:00:00', '1164', '2016-01-25 06:38:19', '580', '774', '288', '419', '230', '2334.00', '314', '28', '9354');
INSERT INTO `edu_statistics_day` VALUES ('1169', '2015-01-05 00:00:00', '1164', '2016-01-25 06:38:19', '580', '775', '287', '418', '229', '2335.00', '313', '31', '9359');
INSERT INTO `edu_statistics_day` VALUES ('1170', '2015-01-06 00:00:00', '1164', '2016-01-25 06:38:19', '579', '774', '287', '417', '228', '2336.00', '312', '34', '9364');
INSERT INTO `edu_statistics_day` VALUES ('1171', '2015-01-07 00:00:00', '1164', '2016-01-25 06:38:19', '579', '773', '286', '417', '227', '2337.00', '311', '37', '9369');
INSERT INTO `edu_statistics_day` VALUES ('1172', '2015-01-08 00:00:00', '1164', '2016-01-25 06:38:19', '578', '774', '285', '416', '226', '2338.00', '310', '40', '9374');
INSERT INTO `edu_statistics_day` VALUES ('1173', '2015-01-09 00:00:00', '1164', '2016-01-25 06:38:19', '578', '773', '284', '415', '226', '2339.00', '310', '43', '9379');
INSERT INTO `edu_statistics_day` VALUES ('1174', '2015-01-10 00:00:00', '1164', '2016-01-25 06:38:19', '577', '772', '284', '415', '225', '2340.00', '309', '46', '9384');
INSERT INTO `edu_statistics_day` VALUES ('1175', '2015-01-11 00:00:00', '1164', '2016-01-25 06:38:19', '577', '773', '283', '414', '224', '2341.00', '308', '49', '9389');
INSERT INTO `edu_statistics_day` VALUES ('1176', '2015-01-12 00:00:00', '1164', '2016-01-25 06:38:19', '576', '772', '282', '413', '223', '2342.00', '307', '52', '9394');
INSERT INTO `edu_statistics_day` VALUES ('1177', '2015-01-13 00:00:00', '1164', '2016-01-25 06:38:19', '576', '771', '281', '413', '222', '2343.00', '306', '55', '9399');
INSERT INTO `edu_statistics_day` VALUES ('1178', '2015-01-14 00:00:00', '1164', '2016-01-25 06:38:19', '575', '772', '281', '412', '222', '2344.00', '305', '58', '9404');
INSERT INTO `edu_statistics_day` VALUES ('1179', '2015-01-15 00:00:00', '1164', '2016-01-25 06:38:19', '575', '771', '280', '411', '221', '2345.00', '305', '61', '9409');
INSERT INTO `edu_statistics_day` VALUES ('1180', '2015-01-16 00:00:00', '1164', '2016-01-25 06:38:19', '574', '770', '279', '411', '220', '2346.00', '304', '64', '9414');
INSERT INTO `edu_statistics_day` VALUES ('1181', '2015-01-17 00:00:00', '1164', '2016-01-25 06:38:19', '574', '771', '278', '410', '219', '2347.00', '303', '67', '9419');
INSERT INTO `edu_statistics_day` VALUES ('1182', '2015-01-18 00:00:00', '1164', '2016-01-25 06:38:19', '573', '770', '278', '409', '218', '2348.00', '302', '70', '9424');
INSERT INTO `edu_statistics_day` VALUES ('1183', '2015-01-19 00:00:00', '1164', '2016-01-25 06:38:19', '573', '769', '277', '409', '218', '2349.00', '301', '73', '9429');
INSERT INTO `edu_statistics_day` VALUES ('1184', '2015-01-20 00:00:00', '1164', '2016-01-25 06:38:19', '572', '770', '276', '408', '217', '2350.00', '300', '76', '9434');
INSERT INTO `edu_statistics_day` VALUES ('1185', '2015-01-21 00:00:00', '1164', '2016-01-25 06:38:19', '572', '769', '275', '407', '216', '2351.00', '300', '79', '9439');
INSERT INTO `edu_statistics_day` VALUES ('1186', '2015-01-22 00:00:00', '1164', '2016-01-25 06:38:19', '571', '768', '275', '407', '215', '2352.00', '299', '82', '9444');
INSERT INTO `edu_statistics_day` VALUES ('1187', '2015-01-23 00:00:00', '1164', '2016-01-25 06:38:19', '571', '769', '274', '406', '214', '2353.00', '298', '85', '9449');
INSERT INTO `edu_statistics_day` VALUES ('1188', '2015-01-24 00:00:00', '1164', '2016-01-25 06:38:19', '570', '768', '273', '405', '214', '2354.00', '297', '88', '9454');
INSERT INTO `edu_statistics_day` VALUES ('1189', '2015-01-25 00:00:00', '1164', '2016-01-25 06:38:19', '570', '767', '272', '405', '213', '2355.00', '296', '91', '9459');
INSERT INTO `edu_statistics_day` VALUES ('1190', '2015-01-26 00:00:00', '1164', '2016-01-25 06:38:19', '569', '768', '272', '404', '212', '2356.00', '295', '94', '9464');
INSERT INTO `edu_statistics_day` VALUES ('1191', '2015-01-27 00:00:00', '1164', '2016-01-25 06:38:19', '569', '767', '271', '403', '211', '2357.00', '295', '97', '9469');
INSERT INTO `edu_statistics_day` VALUES ('1192', '2015-01-28 00:00:00', '1164', '2016-01-25 06:38:19', '568', '766', '270', '403', '210', '2358.00', '294', '100', '9474');
INSERT INTO `edu_statistics_day` VALUES ('1193', '2015-01-29 00:00:00', '1164', '2016-01-25 06:38:19', '568', '767', '269', '402', '210', '2359.00', '293', '103', '9479');
INSERT INTO `edu_statistics_day` VALUES ('1194', '2015-01-30 00:00:00', '1164', '2016-01-25 06:38:19', '567', '766', '269', '401', '209', '2360.00', '292', '106', '9484');
INSERT INTO `edu_statistics_day` VALUES ('1195', '2015-01-31 00:00:00', '1164', '2016-01-25 06:38:19', '567', '765', '268', '401', '208', '2361.00', '291', '109', '9489');
INSERT INTO `edu_statistics_day` VALUES ('1196', '2015-02-01 00:00:00', '1194', '2016-01-25 06:38:19', '596', '796', '297', '430', '237', '2392.00', '320', '22', '9584');
INSERT INTO `edu_statistics_day` VALUES ('1197', '2015-02-02 00:00:00', '1193', '2016-01-25 06:38:19', '595', '794', '295', '428', '235', '2392.00', '319', '28', '9586');
INSERT INTO `edu_statistics_day` VALUES ('1198', '2015-02-03 00:00:00', '1192', '2016-01-25 06:38:19', '593', '792', '294', '427', '234', '2392.00', '317', '34', '9588');
INSERT INTO `edu_statistics_day` VALUES ('1199', '2015-02-04 00:00:00', '1191', '2016-01-25 06:38:19', '592', '792', '292', '425', '232', '2392.00', '315', '40', '9590');
INSERT INTO `edu_statistics_day` VALUES ('1200', '2015-02-05 00:00:00', '1190', '2016-01-25 06:38:19', '590', '790', '290', '423', '230', '2392.00', '313', '46', '9592');
INSERT INTO `edu_statistics_day` VALUES ('1201', '2015-02-06 00:00:00', '1189', '2016-01-25 06:38:19', '589', '788', '288', '422', '228', '2392.00', '311', '52', '9594');
INSERT INTO `edu_statistics_day` VALUES ('1202', '2015-02-07 00:00:00', '1188', '2016-01-25 06:38:19', '587', '788', '287', '420', '226', '2392.00', '309', '58', '9596');
INSERT INTO `edu_statistics_day` VALUES ('1203', '2015-02-08 00:00:00', '1187', '2016-01-25 06:38:19', '586', '786', '285', '418', '225', '2392.00', '308', '64', '9598');
INSERT INTO `edu_statistics_day` VALUES ('1204', '2015-02-09 00:00:00', '1186', '2016-01-25 06:38:19', '584', '784', '283', '417', '223', '2392.00', '306', '70', '9600');
INSERT INTO `edu_statistics_day` VALUES ('1205', '2015-02-10 00:00:00', '1185', '2016-01-25 06:38:19', '583', '784', '281', '415', '221', '2392.00', '304', '76', '9602');
INSERT INTO `edu_statistics_day` VALUES ('1206', '2015-02-11 00:00:00', '1184', '2016-01-25 06:38:19', '581', '782', '280', '413', '219', '2392.00', '302', '82', '9604');
INSERT INTO `edu_statistics_day` VALUES ('1207', '2015-02-12 00:00:00', '1183', '2016-01-25 06:38:19', '580', '780', '278', '412', '217', '2392.00', '300', '88', '9606');
INSERT INTO `edu_statistics_day` VALUES ('1208', '2015-02-13 00:00:00', '1182', '2016-01-25 06:38:19', '578', '780', '276', '410', '216', '2392.00', '298', '94', '9608');
INSERT INTO `edu_statistics_day` VALUES ('1209', '2015-02-14 00:00:00', '1181', '2016-01-25 06:38:19', '577', '778', '274', '408', '214', '2392.00', '297', '100', '9610');
INSERT INTO `edu_statistics_day` VALUES ('1210', '2015-02-15 00:00:00', '1180', '2016-01-25 06:38:19', '575', '776', '273', '407', '212', '2392.00', '295', '106', '9612');
INSERT INTO `edu_statistics_day` VALUES ('1211', '2015-02-16 00:00:00', '1179', '2016-01-25 06:38:19', '574', '776', '271', '405', '210', '2392.00', '293', '112', '9614');
INSERT INTO `edu_statistics_day` VALUES ('1212', '2015-02-17 00:00:00', '1178', '2016-01-25 06:38:19', '572', '774', '269', '403', '208', '2392.00', '291', '118', '9616');
INSERT INTO `edu_statistics_day` VALUES ('1213', '2015-02-18 00:00:00', '1177', '2016-01-25 06:38:19', '571', '772', '267', '402', '207', '2392.00', '289', '124', '9618');
INSERT INTO `edu_statistics_day` VALUES ('1214', '2015-02-19 00:00:00', '1176', '2016-01-25 06:38:19', '569', '772', '266', '400', '205', '2392.00', '287', '130', '9620');
INSERT INTO `edu_statistics_day` VALUES ('1215', '2015-02-20 00:00:00', '1175', '2016-01-25 06:38:19', '568', '770', '264', '398', '203', '2392.00', '286', '136', '9622');
INSERT INTO `edu_statistics_day` VALUES ('1216', '2015-02-21 00:00:00', '1174', '2016-01-25 06:38:19', '566', '768', '262', '397', '201', '2392.00', '284', '142', '9624');
INSERT INTO `edu_statistics_day` VALUES ('1217', '2015-02-22 00:00:00', '1173', '2016-01-25 06:38:19', '565', '768', '260', '395', '199', '2392.00', '282', '148', '9626');
INSERT INTO `edu_statistics_day` VALUES ('1218', '2015-02-23 00:00:00', '1172', '2016-01-25 06:38:19', '563', '766', '259', '393', '198', '2392.00', '280', '154', '9628');
INSERT INTO `edu_statistics_day` VALUES ('1219', '2015-02-24 00:00:00', '1171', '2016-01-25 06:38:19', '562', '764', '257', '392', '196', '2392.00', '278', '160', '9630');
INSERT INTO `edu_statistics_day` VALUES ('1220', '2015-02-25 00:00:00', '1170', '2016-01-25 06:38:19', '560', '764', '255', '390', '194', '2392.00', '276', '166', '9632');
INSERT INTO `edu_statistics_day` VALUES ('1221', '2015-02-26 00:00:00', '1169', '2016-01-25 06:38:19', '559', '762', '253', '388', '192', '2392.00', '275', '172', '9634');
INSERT INTO `edu_statistics_day` VALUES ('1222', '2015-02-27 00:00:00', '1168', '2016-01-25 06:38:19', '557', '760', '252', '387', '190', '2392.00', '273', '178', '9636');
INSERT INTO `edu_statistics_day` VALUES ('1223', '2015-02-28 00:00:00', '1167', '2016-01-25 06:38:19', '556', '760', '250', '385', '189', '2392.00', '271', '184', '9638');
INSERT INTO `edu_statistics_day` VALUES ('1224', '2015-03-01 00:00:00', '1221', '2016-01-25 06:38:19', '609', '813', '303', '438', '242', '2447.00', '324', '25', '9805');
INSERT INTO `edu_statistics_day` VALUES ('1225', '2015-03-02 00:00:00', '1219', '2016-01-25 06:38:19', '607', '810', '300', '436', '239', '2446.00', '321', '34', '9804');
INSERT INTO `edu_statistics_day` VALUES ('1226', '2015-03-03 00:00:00', '1217', '2016-01-25 06:38:19', '604', '809', '298', '433', '236', '2445.00', '318', '43', '9803');
INSERT INTO `edu_statistics_day` VALUES ('1227', '2015-03-04 00:00:00', '1215', '2016-01-25 06:38:19', '602', '806', '295', '430', '233', '2444.00', '316', '52', '9802');
INSERT INTO `edu_statistics_day` VALUES ('1228', '2015-03-05 00:00:00', '1213', '2016-01-25 06:38:19', '599', '803', '292', '428', '231', '2443.00', '313', '61', '9801');
INSERT INTO `edu_statistics_day` VALUES ('1229', '2015-03-06 00:00:00', '1211', '2016-01-25 06:38:19', '597', '802', '289', '425', '228', '2442.00', '310', '70', '9800');
INSERT INTO `edu_statistics_day` VALUES ('1230', '2015-03-07 00:00:00', '1209', '2016-01-25 06:38:19', '594', '799', '287', '422', '225', '2441.00', '307', '79', '9799');
INSERT INTO `edu_statistics_day` VALUES ('1231', '2015-03-08 00:00:00', '1207', '2016-01-25 06:38:19', '592', '796', '284', '420', '222', '2440.00', '304', '88', '9798');
INSERT INTO `edu_statistics_day` VALUES ('1232', '2015-03-09 00:00:00', '1205', '2016-01-25 06:38:19', '589', '795', '281', '417', '219', '2439.00', '301', '97', '9797');
INSERT INTO `edu_statistics_day` VALUES ('1233', '2015-03-10 00:00:00', '1203', '2016-01-25 06:38:19', '587', '792', '278', '414', '217', '2438.00', '299', '106', '9796');
INSERT INTO `edu_statistics_day` VALUES ('1234', '2015-03-11 00:00:00', '1201', '2016-01-25 06:38:19', '584', '789', '276', '412', '214', '2437.00', '296', '115', '9795');
INSERT INTO `edu_statistics_day` VALUES ('1235', '2015-03-12 00:00:00', '1199', '2016-01-25 06:38:19', '582', '788', '273', '409', '211', '2436.00', '293', '124', '9794');
INSERT INTO `edu_statistics_day` VALUES ('1236', '2015-03-13 00:00:00', '1197', '2016-01-25 06:38:19', '579', '785', '270', '406', '208', '2435.00', '290', '133', '9793');
INSERT INTO `edu_statistics_day` VALUES ('1237', '2015-03-14 00:00:00', '1195', '2016-01-25 06:38:19', '577', '782', '267', '404', '205', '2434.00', '287', '142', '9792');
INSERT INTO `edu_statistics_day` VALUES ('1238', '2015-03-15 00:00:00', '1193', '2016-01-25 06:38:19', '574', '781', '265', '401', '203', '2433.00', '284', '151', '9791');
INSERT INTO `edu_statistics_day` VALUES ('1239', '2015-03-16 00:00:00', '1191', '2016-01-25 06:38:19', '572', '778', '262', '398', '200', '2432.00', '282', '160', '9790');
INSERT INTO `edu_statistics_day` VALUES ('1240', '2015-03-17 00:00:00', '1189', '2016-01-25 06:38:19', '569', '775', '259', '396', '197', '2431.00', '279', '169', '9789');
INSERT INTO `edu_statistics_day` VALUES ('1241', '2015-03-18 00:00:00', '1187', '2016-01-25 06:38:19', '567', '774', '256', '393', '194', '2430.00', '276', '178', '9788');
INSERT INTO `edu_statistics_day` VALUES ('1242', '2015-03-19 00:00:00', '1185', '2016-01-25 06:38:19', '564', '771', '254', '390', '191', '2429.00', '273', '187', '9787');
INSERT INTO `edu_statistics_day` VALUES ('1243', '2015-03-20 00:00:00', '1183', '2016-01-25 06:38:19', '562', '768', '251', '388', '189', '2428.00', '270', '196', '9786');
INSERT INTO `edu_statistics_day` VALUES ('1244', '2015-03-21 00:00:00', '1181', '2016-01-25 06:38:19', '559', '767', '248', '385', '186', '2427.00', '267', '205', '9785');
INSERT INTO `edu_statistics_day` VALUES ('1245', '2015-03-22 00:00:00', '1179', '2016-01-25 06:38:19', '557', '764', '245', '382', '183', '2426.00', '265', '214', '9784');
INSERT INTO `edu_statistics_day` VALUES ('1246', '2015-03-23 00:00:00', '1177', '2016-01-25 06:38:19', '554', '761', '243', '380', '180', '2425.00', '262', '223', '9783');
INSERT INTO `edu_statistics_day` VALUES ('1247', '2015-03-24 00:00:00', '1175', '2016-01-25 06:38:19', '552', '760', '240', '377', '177', '2424.00', '259', '232', '9782');
INSERT INTO `edu_statistics_day` VALUES ('1248', '2015-03-25 00:00:00', '1173', '2016-01-25 06:38:19', '549', '757', '237', '374', '175', '2423.00', '256', '241', '9781');
INSERT INTO `edu_statistics_day` VALUES ('1249', '2015-03-26 00:00:00', '1171', '2016-01-25 06:38:19', '547', '754', '234', '372', '172', '2422.00', '253', '250', '9780');
INSERT INTO `edu_statistics_day` VALUES ('1250', '2015-03-27 00:00:00', '1169', '2016-01-25 06:38:19', '544', '753', '232', '369', '169', '2421.00', '250', '259', '9779');
INSERT INTO `edu_statistics_day` VALUES ('1251', '2015-03-28 00:00:00', '1167', '2016-01-25 06:38:19', '542', '750', '229', '366', '166', '2420.00', '248', '268', '9778');
INSERT INTO `edu_statistics_day` VALUES ('1252', '2015-03-29 00:00:00', '1165', '2016-01-25 06:38:19', '539', '747', '226', '364', '163', '2419.00', '245', '277', '9777');
INSERT INTO `edu_statistics_day` VALUES ('1253', '2015-03-30 00:00:00', '1163', '2016-01-25 06:38:19', '537', '746', '223', '361', '161', '2418.00', '242', '286', '9776');
INSERT INTO `edu_statistics_day` VALUES ('1254', '2015-03-31 00:00:00', '1161', '2016-01-25 06:38:19', '534', '743', '221', '358', '158', '2417.00', '239', '295', '9775');
INSERT INTO `edu_statistics_day` VALUES ('1255', '2015-04-01 00:00:00', '1251', '2016-01-25 06:38:19', '624', '832', '310', '448', '247', '2508.00', '328', '28', '10050');
INSERT INTO `edu_statistics_day` VALUES ('1256', '2015-04-02 00:00:00', '1248', '2016-01-25 06:38:19', '620', '830', '306', '444', '243', '2506.00', '324', '40', '10046');
INSERT INTO `edu_statistics_day` VALUES ('1257', '2015-04-03 00:00:00', '1245', '2016-01-25 06:38:19', '617', '826', '302', '440', '239', '2504.00', '321', '52', '10042');
INSERT INTO `edu_statistics_day` VALUES ('1258', '2015-04-04 00:00:00', '1242', '2016-01-25 06:38:19', '613', '822', '299', '437', '236', '2502.00', '317', '64', '10038');
INSERT INTO `edu_statistics_day` VALUES ('1259', '2015-04-05 00:00:00', '1239', '2016-01-25 06:38:19', '610', '820', '295', '433', '232', '2500.00', '313', '76', '10034');
INSERT INTO `edu_statistics_day` VALUES ('1260', '2015-04-06 00:00:00', '1236', '2016-01-25 06:38:19', '606', '816', '291', '429', '228', '2498.00', '309', '88', '10030');
INSERT INTO `edu_statistics_day` VALUES ('1261', '2015-04-07 00:00:00', '1233', '2016-01-25 06:38:19', '603', '812', '287', '426', '224', '2496.00', '305', '100', '10026');
INSERT INTO `edu_statistics_day` VALUES ('1262', '2015-04-08 00:00:00', '1230', '2016-01-25 06:38:19', '599', '810', '284', '422', '220', '2494.00', '301', '112', '10022');
INSERT INTO `edu_statistics_day` VALUES ('1263', '2015-04-09 00:00:00', '1227', '2016-01-25 06:38:19', '596', '806', '280', '418', '217', '2492.00', '298', '124', '10018');
INSERT INTO `edu_statistics_day` VALUES ('1264', '2015-04-10 00:00:00', '1224', '2016-01-25 06:38:19', '592', '802', '276', '415', '213', '2490.00', '294', '136', '10014');
INSERT INTO `edu_statistics_day` VALUES ('1265', '2015-04-11 00:00:00', '1221', '2016-01-25 06:38:19', '589', '800', '272', '411', '209', '2488.00', '290', '148', '10010');
INSERT INTO `edu_statistics_day` VALUES ('1266', '2015-04-12 00:00:00', '1218', '2016-01-25 06:38:19', '585', '796', '269', '407', '205', '2486.00', '286', '160', '10006');
INSERT INTO `edu_statistics_day` VALUES ('1267', '2015-04-13 00:00:00', '1215', '2016-01-25 06:38:19', '582', '792', '265', '404', '201', '2484.00', '282', '172', '10002');
INSERT INTO `edu_statistics_day` VALUES ('1268', '2015-04-14 00:00:00', '1212', '2016-01-25 06:38:19', '578', '790', '261', '400', '198', '2482.00', '278', '184', '9998');
INSERT INTO `edu_statistics_day` VALUES ('1269', '2015-04-15 00:00:00', '1209', '2016-01-25 06:38:19', '575', '786', '257', '396', '194', '2480.00', '275', '196', '9994');
INSERT INTO `edu_statistics_day` VALUES ('1270', '2015-04-16 00:00:00', '1206', '2016-01-25 06:38:19', '571', '782', '254', '393', '190', '2478.00', '271', '208', '9990');
INSERT INTO `edu_statistics_day` VALUES ('1271', '2015-04-17 00:00:00', '1203', '2016-01-25 06:38:19', '568', '780', '250', '389', '186', '2476.00', '267', '220', '9986');
INSERT INTO `edu_statistics_day` VALUES ('1272', '2015-04-18 00:00:00', '1200', '2016-01-25 06:38:19', '564', '776', '246', '385', '182', '2474.00', '263', '232', '9982');
INSERT INTO `edu_statistics_day` VALUES ('1273', '2015-04-19 00:00:00', '1197', '2016-01-25 06:38:19', '561', '772', '242', '382', '179', '2472.00', '259', '244', '9978');
INSERT INTO `edu_statistics_day` VALUES ('1274', '2015-04-20 00:00:00', '1194', '2016-01-25 06:38:19', '557', '770', '239', '378', '175', '2470.00', '255', '256', '9974');
INSERT INTO `edu_statistics_day` VALUES ('1275', '2015-04-21 00:00:00', '1191', '2016-01-25 06:38:19', '554', '766', '235', '374', '171', '2468.00', '252', '268', '9970');
INSERT INTO `edu_statistics_day` VALUES ('1276', '2015-04-22 00:00:00', '1188', '2016-01-25 06:38:19', '550', '762', '231', '371', '167', '2466.00', '248', '280', '9966');
INSERT INTO `edu_statistics_day` VALUES ('1277', '2015-04-23 00:00:00', '1185', '2016-01-25 06:38:19', '547', '760', '227', '367', '163', '2464.00', '244', '292', '9962');
INSERT INTO `edu_statistics_day` VALUES ('1278', '2015-04-24 00:00:00', '1182', '2016-01-25 06:38:19', '543', '756', '224', '363', '160', '2462.00', '240', '304', '9958');
INSERT INTO `edu_statistics_day` VALUES ('1279', '2015-04-25 00:00:00', '1179', '2016-01-25 06:38:19', '540', '752', '220', '360', '156', '2460.00', '236', '316', '9954');
INSERT INTO `edu_statistics_day` VALUES ('1280', '2015-04-26 00:00:00', '1176', '2016-01-25 06:38:19', '536', '750', '216', '356', '152', '2458.00', '232', '328', '9950');
INSERT INTO `edu_statistics_day` VALUES ('1281', '2015-04-27 00:00:00', '1173', '2016-01-25 06:38:19', '533', '746', '212', '352', '148', '2456.00', '229', '340', '9946');
INSERT INTO `edu_statistics_day` VALUES ('1282', '2015-04-28 00:00:00', '1170', '2016-01-25 06:38:19', '529', '742', '209', '349', '144', '2454.00', '225', '352', '9942');
INSERT INTO `edu_statistics_day` VALUES ('1283', '2015-04-29 00:00:00', '1167', '2016-01-25 06:38:19', '526', '740', '205', '345', '141', '2452.00', '221', '364', '9938');
INSERT INTO `edu_statistics_day` VALUES ('1284', '2015-04-30 00:00:00', '1164', '2016-01-25 06:38:19', '522', '736', '201', '341', '137', '2450.00', '217', '376', '9934');
INSERT INTO `edu_statistics_day` VALUES ('1285', '2015-05-01 00:00:00', '1280', '2016-01-25 06:38:19', '638', '851', '316', '457', '252', '2567.00', '332', '31', '10287');
INSERT INTO `edu_statistics_day` VALUES ('1286', '2015-05-02 00:00:00', '1276', '2016-01-25 06:38:19', '633', '848', '312', '452', '247', '2564.00', '327', '46', '10280');
INSERT INTO `edu_statistics_day` VALUES ('1287', '2015-05-03 00:00:00', '1272', '2016-01-25 06:38:19', '629', '843', '307', '447', '242', '2561.00', '323', '61', '10273');
INSERT INTO `edu_statistics_day` VALUES ('1288', '2015-05-04 00:00:00', '1268', '2016-01-25 06:38:19', '624', '838', '302', '443', '238', '2558.00', '318', '76', '10266');
INSERT INTO `edu_statistics_day` VALUES ('1289', '2015-05-05 00:00:00', '1264', '2016-01-25 06:38:19', '620', '835', '297', '438', '233', '2555.00', '313', '91', '10259');
INSERT INTO `edu_statistics_day` VALUES ('1290', '2015-05-06 00:00:00', '1260', '2016-01-25 06:38:19', '615', '830', '293', '433', '228', '2552.00', '308', '106', '10252');
INSERT INTO `edu_statistics_day` VALUES ('1291', '2015-05-07 00:00:00', '1256', '2016-01-25 06:38:19', '611', '825', '288', '429', '223', '2549.00', '303', '121', '10245');
INSERT INTO `edu_statistics_day` VALUES ('1292', '2015-05-08 00:00:00', '1252', '2016-01-25 06:38:19', '606', '822', '283', '424', '218', '2546.00', '298', '136', '10238');
INSERT INTO `edu_statistics_day` VALUES ('1293', '2015-05-09 00:00:00', '1248', '2016-01-25 06:38:19', '602', '817', '278', '419', '214', '2543.00', '294', '151', '10231');
INSERT INTO `edu_statistics_day` VALUES ('1294', '2015-05-10 00:00:00', '1244', '2016-01-25 06:38:19', '597', '812', '274', '415', '209', '2540.00', '289', '166', '10224');
INSERT INTO `edu_statistics_day` VALUES ('1295', '2015-05-11 00:00:00', '1240', '2016-01-25 06:38:19', '593', '809', '269', '410', '204', '2537.00', '284', '181', '10217');
INSERT INTO `edu_statistics_day` VALUES ('1296', '2015-05-12 00:00:00', '1236', '2016-01-25 06:38:19', '588', '804', '264', '405', '199', '2534.00', '279', '196', '10210');
INSERT INTO `edu_statistics_day` VALUES ('1297', '2015-05-13 00:00:00', '1232', '2016-01-25 06:38:19', '584', '799', '259', '401', '194', '2531.00', '274', '211', '10203');
INSERT INTO `edu_statistics_day` VALUES ('1298', '2015-05-14 00:00:00', '1228', '2016-01-25 06:38:19', '579', '796', '255', '396', '190', '2528.00', '269', '226', '10196');
INSERT INTO `edu_statistics_day` VALUES ('1299', '2015-05-15 00:00:00', '1224', '2016-01-25 06:38:19', '575', '791', '250', '391', '185', '2525.00', '265', '241', '10189');
INSERT INTO `edu_statistics_day` VALUES ('1300', '2015-05-16 00:00:00', '1220', '2016-01-25 06:38:19', '570', '786', '245', '387', '180', '2522.00', '260', '256', '10182');
INSERT INTO `edu_statistics_day` VALUES ('1301', '2015-05-17 00:00:00', '1216', '2016-01-25 06:38:19', '566', '783', '240', '382', '175', '2519.00', '255', '271', '10175');
INSERT INTO `edu_statistics_day` VALUES ('1302', '2015-05-18 00:00:00', '1212', '2016-01-25 06:38:19', '561', '778', '236', '377', '170', '2516.00', '250', '286', '10168');
INSERT INTO `edu_statistics_day` VALUES ('1303', '2015-05-19 00:00:00', '1208', '2016-01-25 06:38:19', '557', '773', '231', '373', '166', '2513.00', '245', '301', '10161');
INSERT INTO `edu_statistics_day` VALUES ('1304', '2015-05-20 00:00:00', '1204', '2016-01-25 06:38:19', '552', '770', '226', '368', '161', '2510.00', '240', '316', '10154');
INSERT INTO `edu_statistics_day` VALUES ('1305', '2015-05-21 00:00:00', '1200', '2016-01-25 06:38:19', '548', '765', '221', '363', '156', '2507.00', '236', '331', '10147');
INSERT INTO `edu_statistics_day` VALUES ('1306', '2015-05-22 00:00:00', '1196', '2016-01-25 06:38:19', '543', '760', '217', '359', '151', '2504.00', '231', '346', '10140');
INSERT INTO `edu_statistics_day` VALUES ('1307', '2015-05-23 00:00:00', '1192', '2016-01-25 06:38:19', '539', '757', '212', '354', '146', '2501.00', '226', '361', '10133');
INSERT INTO `edu_statistics_day` VALUES ('1308', '2015-05-24 00:00:00', '1188', '2016-01-25 06:38:19', '534', '752', '207', '349', '142', '2498.00', '221', '376', '10126');
INSERT INTO `edu_statistics_day` VALUES ('1309', '2015-05-25 00:00:00', '1184', '2016-01-25 06:38:19', '530', '747', '202', '345', '137', '2495.00', '216', '391', '10119');
INSERT INTO `edu_statistics_day` VALUES ('1310', '2015-05-26 00:00:00', '1180', '2016-01-25 06:38:19', '525', '744', '198', '340', '132', '2492.00', '211', '406', '10112');
INSERT INTO `edu_statistics_day` VALUES ('1311', '2015-05-27 00:00:00', '1176', '2016-01-25 06:38:19', '521', '739', '193', '335', '127', '2489.00', '207', '421', '10105');
INSERT INTO `edu_statistics_day` VALUES ('1312', '2015-05-28 00:00:00', '1172', '2016-01-25 06:38:19', '516', '734', '188', '331', '122', '2486.00', '202', '436', '10098');
INSERT INTO `edu_statistics_day` VALUES ('1313', '2015-05-29 00:00:00', '1168', '2016-01-25 06:38:19', '512', '731', '183', '326', '118', '2483.00', '197', '451', '10091');
INSERT INTO `edu_statistics_day` VALUES ('1314', '2015-05-30 00:00:00', '1164', '2016-01-25 06:38:19', '507', '726', '179', '321', '113', '2480.00', '192', '466', '10084');
INSERT INTO `edu_statistics_day` VALUES ('1315', '2015-05-31 00:00:00', '1160', '2016-01-25 06:38:19', '503', '721', '174', '317', '108', '2477.00', '187', '481', '10077');
INSERT INTO `edu_statistics_day` VALUES ('1316', '2015-06-01 00:00:00', '1310', '2016-01-25 06:38:19', '652', '872', '323', '466', '257', '2628.00', '336', '34', '10532');
INSERT INTO `edu_statistics_day` VALUES ('1317', '2015-06-02 00:00:00', '1305', '2016-01-25 06:38:19', '647', '866', '317', '460', '251', '2624.00', '331', '52', '10522');
INSERT INTO `edu_statistics_day` VALUES ('1318', '2015-06-03 00:00:00', '1300', '2016-01-25 06:38:19', '641', '860', '312', '455', '246', '2620.00', '325', '70', '10512');
INSERT INTO `edu_statistics_day` VALUES ('1319', '2015-06-04 00:00:00', '1295', '2016-01-25 06:38:19', '636', '856', '306', '449', '240', '2616.00', '319', '88', '10502');
INSERT INTO `edu_statistics_day` VALUES ('1320', '2015-06-05 00:00:00', '1290', '2016-01-25 06:38:19', '630', '850', '300', '443', '234', '2612.00', '313', '106', '10492');
INSERT INTO `edu_statistics_day` VALUES ('1321', '2015-06-06 00:00:00', '1285', '2016-01-25 06:38:19', '625', '844', '294', '438', '228', '2608.00', '307', '124', '10482');
INSERT INTO `edu_statistics_day` VALUES ('1322', '2015-06-07 00:00:00', '1280', '2016-01-25 06:38:19', '619', '840', '289', '432', '222', '2604.00', '301', '142', '10472');
INSERT INTO `edu_statistics_day` VALUES ('1323', '2015-06-08 00:00:00', '1275', '2016-01-25 06:38:19', '614', '834', '283', '426', '217', '2600.00', '296', '160', '10462');
INSERT INTO `edu_statistics_day` VALUES ('1324', '2015-06-09 00:00:00', '1270', '2016-01-25 06:38:19', '608', '828', '277', '421', '211', '2596.00', '290', '178', '10452');
INSERT INTO `edu_statistics_day` VALUES ('1325', '2015-06-10 00:00:00', '1265', '2016-01-25 06:38:19', '603', '824', '271', '415', '205', '2592.00', '284', '196', '10442');
INSERT INTO `edu_statistics_day` VALUES ('1326', '2015-06-11 00:00:00', '1260', '2016-01-25 06:38:19', '597', '818', '266', '409', '199', '2588.00', '278', '214', '10432');
INSERT INTO `edu_statistics_day` VALUES ('1327', '2015-06-12 00:00:00', '1255', '2016-01-25 06:38:19', '592', '812', '260', '404', '193', '2584.00', '272', '232', '10422');
INSERT INTO `edu_statistics_day` VALUES ('1328', '2015-06-13 00:00:00', '1250', '2016-01-25 06:38:19', '586', '808', '254', '398', '188', '2580.00', '266', '250', '10412');
INSERT INTO `edu_statistics_day` VALUES ('1329', '2015-06-14 00:00:00', '1245', '2016-01-25 06:38:19', '581', '802', '248', '392', '182', '2576.00', '261', '268', '10402');
INSERT INTO `edu_statistics_day` VALUES ('1330', '2015-06-15 00:00:00', '1240', '2016-01-25 06:38:19', '575', '796', '243', '387', '176', '2572.00', '255', '286', '10392');
INSERT INTO `edu_statistics_day` VALUES ('1331', '2015-06-16 00:00:00', '1235', '2016-01-25 06:38:19', '570', '792', '237', '381', '170', '2568.00', '249', '304', '10382');
INSERT INTO `edu_statistics_day` VALUES ('1332', '2015-06-17 00:00:00', '1230', '2016-01-25 06:38:19', '564', '786', '231', '375', '164', '2564.00', '243', '322', '10372');
INSERT INTO `edu_statistics_day` VALUES ('1333', '2015-06-18 00:00:00', '1225', '2016-01-25 06:38:19', '559', '780', '225', '370', '159', '2560.00', '237', '340', '10362');
INSERT INTO `edu_statistics_day` VALUES ('1334', '2015-06-19 00:00:00', '1220', '2016-01-25 06:38:19', '553', '776', '220', '364', '153', '2556.00', '231', '358', '10352');
INSERT INTO `edu_statistics_day` VALUES ('1335', '2015-06-20 00:00:00', '1215', '2016-01-25 06:38:19', '548', '770', '214', '358', '147', '2552.00', '226', '376', '10342');
INSERT INTO `edu_statistics_day` VALUES ('1336', '2015-06-21 00:00:00', '1210', '2016-01-25 06:38:19', '542', '764', '208', '353', '141', '2548.00', '220', '394', '10332');
INSERT INTO `edu_statistics_day` VALUES ('1337', '2015-06-22 00:00:00', '1205', '2016-01-25 06:38:19', '537', '760', '202', '347', '135', '2544.00', '214', '412', '10322');
INSERT INTO `edu_statistics_day` VALUES ('1338', '2015-06-23 00:00:00', '1200', '2016-01-25 06:38:19', '531', '754', '197', '341', '130', '2540.00', '208', '430', '10312');
INSERT INTO `edu_statistics_day` VALUES ('1339', '2015-06-24 00:00:00', '1195', '2016-01-25 06:38:19', '526', '748', '191', '336', '124', '2536.00', '202', '448', '10302');
INSERT INTO `edu_statistics_day` VALUES ('1340', '2015-06-25 00:00:00', '1190', '2016-01-25 06:38:19', '520', '744', '185', '330', '118', '2532.00', '196', '466', '10292');
INSERT INTO `edu_statistics_day` VALUES ('1341', '2015-06-26 00:00:00', '1185', '2016-01-25 06:38:19', '515', '738', '179', '324', '112', '2528.00', '191', '484', '10282');
INSERT INTO `edu_statistics_day` VALUES ('1342', '2015-06-27 00:00:00', '1180', '2016-01-25 06:38:19', '509', '732', '174', '319', '106', '2524.00', '185', '502', '10272');
INSERT INTO `edu_statistics_day` VALUES ('1343', '2015-06-28 00:00:00', '1175', '2016-01-25 06:38:19', '504', '728', '168', '313', '101', '2520.00', '179', '520', '10262');
INSERT INTO `edu_statistics_day` VALUES ('1344', '2015-06-29 00:00:00', '1170', '2016-01-25 06:38:19', '498', '722', '162', '307', '95', '2516.00', '173', '538', '10252');
INSERT INTO `edu_statistics_day` VALUES ('1345', '2015-06-30 00:00:00', '1165', '2016-01-25 06:38:20', '493', '716', '156', '302', '89', '2512.00', '167', '556', '10242');
INSERT INTO `edu_statistics_day` VALUES ('1346', '2015-07-01 00:00:00', '1339', '2016-01-25 06:38:20', '666', '891', '330', '475', '262', '2687.00', '340', '37', '10769');
INSERT INTO `edu_statistics_day` VALUES ('1347', '2015-07-02 00:00:00', '1333', '2016-01-25 06:38:20', '660', '884', '323', '468', '255', '2682.00', '334', '58', '10756');
INSERT INTO `edu_statistics_day` VALUES ('1348', '2015-07-03 00:00:00', '1327', '2016-01-25 06:38:20', '653', '877', '316', '462', '249', '2677.00', '327', '79', '10743');
INSERT INTO `edu_statistics_day` VALUES ('1349', '2015-07-04 00:00:00', '1321', '2016-01-25 06:38:20', '647', '872', '309', '455', '242', '2672.00', '320', '100', '10730');
INSERT INTO `edu_statistics_day` VALUES ('1350', '2015-07-05 00:00:00', '1315', '2016-01-25 06:38:20', '640', '865', '303', '448', '235', '2667.00', '313', '121', '10717');
INSERT INTO `edu_statistics_day` VALUES ('1351', '2015-07-06 00:00:00', '1309', '2016-01-25 06:38:20', '634', '858', '296', '442', '228', '2662.00', '306', '142', '10704');
INSERT INTO `edu_statistics_day` VALUES ('1352', '2015-07-07 00:00:00', '1303', '2016-01-25 06:38:20', '627', '853', '289', '435', '221', '2657.00', '299', '163', '10691');
INSERT INTO `edu_statistics_day` VALUES ('1353', '2015-07-08 00:00:00', '1297', '2016-01-25 06:38:20', '621', '846', '282', '428', '215', '2652.00', '293', '184', '10678');
INSERT INTO `edu_statistics_day` VALUES ('1354', '2015-07-09 00:00:00', '1291', '2016-01-25 06:38:20', '614', '839', '276', '422', '208', '2647.00', '286', '205', '10665');
INSERT INTO `edu_statistics_day` VALUES ('1355', '2015-07-10 00:00:00', '1285', '2016-01-25 06:38:20', '608', '834', '269', '415', '201', '2642.00', '279', '226', '10652');
INSERT INTO `edu_statistics_day` VALUES ('1356', '2015-07-11 00:00:00', '1279', '2016-01-25 06:38:20', '601', '827', '262', '408', '194', '2637.00', '272', '247', '10639');
INSERT INTO `edu_statistics_day` VALUES ('1357', '2015-07-12 00:00:00', '1273', '2016-01-25 06:38:20', '595', '820', '255', '402', '187', '2632.00', '265', '268', '10626');
INSERT INTO `edu_statistics_day` VALUES ('1358', '2015-07-13 00:00:00', '1267', '2016-01-25 06:38:20', '588', '815', '249', '395', '181', '2627.00', '258', '289', '10613');
INSERT INTO `edu_statistics_day` VALUES ('1359', '2015-07-14 00:00:00', '1261', '2016-01-25 06:38:20', '582', '808', '242', '388', '174', '2622.00', '252', '310', '10600');
INSERT INTO `edu_statistics_day` VALUES ('1360', '2015-07-15 00:00:00', '1255', '2016-01-25 06:38:20', '575', '801', '235', '382', '167', '2617.00', '245', '331', '10587');
INSERT INTO `edu_statistics_day` VALUES ('1361', '2015-07-16 00:00:00', '1249', '2016-01-25 06:38:20', '569', '796', '228', '375', '160', '2612.00', '238', '352', '10574');
INSERT INTO `edu_statistics_day` VALUES ('1362', '2015-07-17 00:00:00', '1243', '2016-01-25 06:38:20', '562', '789', '222', '368', '153', '2607.00', '231', '373', '10561');
INSERT INTO `edu_statistics_day` VALUES ('1363', '2015-07-18 00:00:00', '1237', '2016-01-25 06:38:20', '556', '782', '215', '362', '147', '2602.00', '224', '394', '10548');
INSERT INTO `edu_statistics_day` VALUES ('1364', '2015-07-19 00:00:00', '1231', '2016-01-25 06:38:20', '549', '777', '208', '355', '140', '2597.00', '217', '415', '10535');
INSERT INTO `edu_statistics_day` VALUES ('1365', '2015-07-20 00:00:00', '1225', '2016-01-25 06:38:20', '543', '770', '201', '348', '133', '2592.00', '211', '436', '10522');
INSERT INTO `edu_statistics_day` VALUES ('1366', '2015-07-21 00:00:00', '1219', '2016-01-25 06:38:20', '536', '763', '195', '342', '126', '2587.00', '204', '457', '10509');
INSERT INTO `edu_statistics_day` VALUES ('1367', '2015-07-22 00:00:00', '1213', '2016-01-25 06:38:20', '530', '758', '188', '335', '119', '2582.00', '197', '478', '10496');
INSERT INTO `edu_statistics_day` VALUES ('1368', '2015-07-23 00:00:00', '1207', '2016-01-25 06:38:20', '523', '751', '181', '328', '113', '2577.00', '190', '499', '10483');
INSERT INTO `edu_statistics_day` VALUES ('1369', '2015-07-24 00:00:00', '1201', '2016-01-25 06:38:20', '517', '744', '174', '322', '106', '2572.00', '183', '520', '10470');
INSERT INTO `edu_statistics_day` VALUES ('1370', '2015-07-25 00:00:00', '1195', '2016-01-25 06:38:20', '510', '739', '168', '315', '99', '2567.00', '176', '541', '10457');
INSERT INTO `edu_statistics_day` VALUES ('1371', '2015-07-26 00:00:00', '1189', '2016-01-25 06:38:20', '504', '732', '161', '308', '92', '2562.00', '170', '562', '10444');
INSERT INTO `edu_statistics_day` VALUES ('1372', '2015-07-27 00:00:00', '1183', '2016-01-25 06:38:20', '497', '725', '154', '302', '85', '2557.00', '163', '583', '10431');
INSERT INTO `edu_statistics_day` VALUES ('1373', '2015-07-28 00:00:00', '1177', '2016-01-25 06:38:20', '491', '720', '147', '295', '79', '2552.00', '156', '604', '10418');
INSERT INTO `edu_statistics_day` VALUES ('1374', '2015-07-29 00:00:00', '1171', '2016-01-25 06:38:20', '484', '713', '141', '288', '72', '2547.00', '149', '625', '10405');
INSERT INTO `edu_statistics_day` VALUES ('1375', '2015-07-30 00:00:00', '1165', '2016-01-25 06:38:20', '478', '706', '134', '282', '65', '2542.00', '142', '646', '10392');
INSERT INTO `edu_statistics_day` VALUES ('1376', '2015-07-31 00:00:00', '1159', '2016-01-25 06:38:20', '471', '701', '127', '275', '58', '2537.00', '135', '667', '10379');
INSERT INTO `edu_statistics_day` VALUES ('1377', '2015-08-01 00:00:00', '1369', '2016-01-25 06:38:20', '681', '910', '336', '484', '267', '2748.00', '345', '40', '11014');
INSERT INTO `edu_statistics_day` VALUES ('1378', '2015-08-02 00:00:00', '1362', '2016-01-25 06:38:20', '673', '902', '329', '477', '260', '2742.00', '337', '64', '10998');
INSERT INTO `edu_statistics_day` VALUES ('1379', '2015-08-03 00:00:00', '1355', '2016-01-25 06:38:20', '666', '896', '321', '469', '252', '2736.00', '329', '88', '10982');
INSERT INTO `edu_statistics_day` VALUES ('1380', '2015-08-04 00:00:00', '1348', '2016-01-25 06:38:20', '658', '888', '313', '461', '244', '2730.00', '321', '112', '10966');
INSERT INTO `edu_statistics_day` VALUES ('1381', '2015-08-05 00:00:00', '1341', '2016-01-25 06:38:20', '651', '880', '305', '454', '236', '2724.00', '313', '136', '10950');
INSERT INTO `edu_statistics_day` VALUES ('1382', '2015-08-06 00:00:00', '1334', '2016-01-25 06:38:20', '643', '874', '298', '446', '228', '2718.00', '305', '160', '10934');
INSERT INTO `edu_statistics_day` VALUES ('1383', '2015-08-07 00:00:00', '1327', '2016-01-25 06:38:20', '636', '866', '290', '438', '221', '2712.00', '298', '184', '10918');
INSERT INTO `edu_statistics_day` VALUES ('1384', '2015-08-08 00:00:00', '1320', '2016-01-25 06:38:20', '628', '858', '282', '431', '213', '2706.00', '290', '208', '10902');
INSERT INTO `edu_statistics_day` VALUES ('1385', '2015-08-09 00:00:00', '1313', '2016-01-25 06:38:20', '621', '852', '274', '423', '205', '2700.00', '282', '232', '10886');
INSERT INTO `edu_statistics_day` VALUES ('1386', '2015-08-10 00:00:00', '1306', '2016-01-25 06:38:20', '613', '844', '267', '415', '197', '2694.00', '274', '256', '10870');
INSERT INTO `edu_statistics_day` VALUES ('1387', '2015-08-11 00:00:00', '1299', '2016-01-25 06:38:20', '606', '836', '259', '408', '189', '2688.00', '266', '280', '10854');
INSERT INTO `edu_statistics_day` VALUES ('1388', '2015-08-12 00:00:00', '1292', '2016-01-25 06:38:20', '598', '830', '251', '400', '182', '2682.00', '258', '304', '10838');
INSERT INTO `edu_statistics_day` VALUES ('1389', '2015-08-13 00:00:00', '1285', '2016-01-25 06:38:20', '591', '822', '243', '392', '174', '2676.00', '251', '328', '10822');
INSERT INTO `edu_statistics_day` VALUES ('1390', '2015-08-14 00:00:00', '1278', '2016-01-25 06:38:20', '583', '814', '236', '385', '166', '2670.00', '243', '352', '10806');
INSERT INTO `edu_statistics_day` VALUES ('1391', '2015-08-15 00:00:00', '1271', '2016-01-25 06:38:20', '576', '808', '228', '377', '158', '2664.00', '235', '376', '10790');
INSERT INTO `edu_statistics_day` VALUES ('1392', '2015-08-16 00:00:00', '1264', '2016-01-25 06:38:20', '568', '800', '220', '369', '150', '2658.00', '227', '400', '10774');
INSERT INTO `edu_statistics_day` VALUES ('1393', '2015-08-17 00:00:00', '1257', '2016-01-25 06:38:20', '561', '792', '212', '362', '143', '2652.00', '219', '424', '10758');
INSERT INTO `edu_statistics_day` VALUES ('1394', '2015-08-18 00:00:00', '1250', '2016-01-25 06:38:20', '553', '786', '205', '354', '135', '2646.00', '211', '448', '10742');
INSERT INTO `edu_statistics_day` VALUES ('1395', '2015-08-19 00:00:00', '1243', '2016-01-25 06:38:20', '546', '778', '197', '346', '127', '2640.00', '204', '472', '10726');
INSERT INTO `edu_statistics_day` VALUES ('1396', '2015-08-20 00:00:00', '1236', '2016-01-25 06:38:20', '538', '770', '189', '339', '119', '2634.00', '196', '496', '10710');
INSERT INTO `edu_statistics_day` VALUES ('1397', '2015-08-21 00:00:00', '1229', '2016-01-25 06:38:20', '531', '764', '181', '331', '111', '2628.00', '188', '520', '10694');
INSERT INTO `edu_statistics_day` VALUES ('1398', '2015-08-22 00:00:00', '1222', '2016-01-25 06:38:20', '523', '756', '174', '323', '104', '2622.00', '180', '544', '10678');
INSERT INTO `edu_statistics_day` VALUES ('1399', '2015-08-23 00:00:00', '1215', '2016-01-25 06:38:20', '516', '748', '166', '316', '96', '2616.00', '172', '568', '10662');
INSERT INTO `edu_statistics_day` VALUES ('1400', '2015-08-24 00:00:00', '1208', '2016-01-25 06:38:20', '508', '742', '158', '308', '88', '2610.00', '164', '592', '10646');
INSERT INTO `edu_statistics_day` VALUES ('1401', '2015-08-25 00:00:00', '1201', '2016-01-25 06:38:20', '501', '734', '150', '300', '80', '2604.00', '157', '616', '10630');
INSERT INTO `edu_statistics_day` VALUES ('1402', '2015-08-26 00:00:00', '1194', '2016-01-25 06:38:20', '493', '726', '143', '293', '72', '2598.00', '149', '640', '10614');
INSERT INTO `edu_statistics_day` VALUES ('1403', '2015-08-27 00:00:00', '1187', '2016-01-25 06:38:20', '486', '720', '135', '285', '65', '2592.00', '141', '664', '10598');
INSERT INTO `edu_statistics_day` VALUES ('1404', '2015-08-28 00:00:00', '1180', '2016-01-25 06:38:20', '478', '712', '127', '277', '57', '2586.00', '133', '688', '10582');
INSERT INTO `edu_statistics_day` VALUES ('1405', '2015-08-29 00:00:00', '1173', '2016-01-25 06:38:20', '471', '704', '119', '270', '49', '2580.00', '125', '712', '10566');
INSERT INTO `edu_statistics_day` VALUES ('1406', '2015-08-30 00:00:00', '1166', '2016-01-25 06:38:20', '463', '698', '112', '262', '41', '2574.00', '117', '736', '10550');
INSERT INTO `edu_statistics_day` VALUES ('1407', '2015-08-31 00:00:00', '1159', '2016-01-25 06:38:20', '456', '690', '104', '254', '33', '2568.00', '110', '760', '10534');
INSERT INTO `edu_statistics_day` VALUES ('1408', '2015-09-01 00:00:00', '1399', '2016-01-25 06:38:20', '695', '929', '343', '494', '273', '2809.00', '349', '43', '11259');
INSERT INTO `edu_statistics_day` VALUES ('1409', '2015-09-02 00:00:00', '1391', '2016-01-25 06:38:20', '687', '922', '334', '485', '264', '2802.00', '340', '70', '11240');
INSERT INTO `edu_statistics_day` VALUES ('1410', '2015-09-03 00:00:00', '1383', '2016-01-25 06:38:20', '678', '913', '326', '476', '255', '2795.00', '331', '97', '11221');
INSERT INTO `edu_statistics_day` VALUES ('1411', '2015-09-04 00:00:00', '1375', '2016-01-25 06:38:20', '670', '904', '317', '468', '246', '2788.00', '322', '124', '11202');
INSERT INTO `edu_statistics_day` VALUES ('1412', '2015-09-05 00:00:00', '1367', '2016-01-25 06:38:20', '661', '897', '308', '459', '237', '2781.00', '313', '151', '11183');
INSERT INTO `edu_statistics_day` VALUES ('1413', '2015-09-06 00:00:00', '1359', '2016-01-25 06:38:20', '653', '888', '299', '450', '229', '2774.00', '305', '178', '11164');
INSERT INTO `edu_statistics_day` VALUES ('1414', '2015-09-07 00:00:00', '1351', '2016-01-25 06:38:20', '644', '879', '291', '442', '220', '2767.00', '296', '205', '11145');
INSERT INTO `edu_statistics_day` VALUES ('1415', '2015-09-08 00:00:00', '1343', '2016-01-25 06:38:20', '636', '872', '282', '433', '211', '2760.00', '287', '232', '11126');
INSERT INTO `edu_statistics_day` VALUES ('1416', '2015-09-09 00:00:00', '1335', '2016-01-25 06:38:20', '627', '863', '273', '424', '202', '2753.00', '278', '259', '11107');
INSERT INTO `edu_statistics_day` VALUES ('1417', '2015-09-10 00:00:00', '1327', '2016-01-25 06:38:20', '619', '854', '264', '416', '193', '2746.00', '269', '286', '11088');
INSERT INTO `edu_statistics_day` VALUES ('1418', '2015-09-11 00:00:00', '1319', '2016-01-25 06:38:20', '610', '847', '256', '407', '185', '2739.00', '260', '313', '11069');
INSERT INTO `edu_statistics_day` VALUES ('1419', '2015-09-12 00:00:00', '1311', '2016-01-25 06:38:20', '602', '838', '247', '398', '176', '2732.00', '252', '340', '11050');
INSERT INTO `edu_statistics_day` VALUES ('1420', '2015-09-13 00:00:00', '1303', '2016-01-25 06:38:20', '593', '829', '238', '390', '167', '2725.00', '243', '367', '11031');
INSERT INTO `edu_statistics_day` VALUES ('1421', '2015-09-14 00:00:00', '1295', '2016-01-25 06:38:20', '585', '822', '229', '381', '158', '2718.00', '234', '394', '11012');
INSERT INTO `edu_statistics_day` VALUES ('1422', '2015-09-15 00:00:00', '1287', '2016-01-25 06:38:20', '576', '813', '221', '372', '149', '2711.00', '225', '421', '10993');
INSERT INTO `edu_statistics_day` VALUES ('1423', '2015-09-16 00:00:00', '1279', '2016-01-25 06:38:20', '568', '804', '212', '364', '141', '2704.00', '216', '448', '10974');
INSERT INTO `edu_statistics_day` VALUES ('1424', '2015-09-17 00:00:00', '1271', '2016-01-25 06:38:20', '559', '797', '203', '355', '132', '2697.00', '207', '475', '10955');
INSERT INTO `edu_statistics_day` VALUES ('1425', '2015-09-18 00:00:00', '1263', '2016-01-25 06:38:20', '551', '788', '194', '346', '123', '2690.00', '199', '502', '10936');
INSERT INTO `edu_statistics_day` VALUES ('1426', '2015-09-19 00:00:00', '1255', '2016-01-25 06:38:20', '542', '779', '186', '338', '114', '2683.00', '190', '529', '10917');
INSERT INTO `edu_statistics_day` VALUES ('1427', '2015-09-20 00:00:00', '1247', '2016-01-25 06:38:20', '534', '772', '177', '329', '105', '2676.00', '181', '556', '10898');
INSERT INTO `edu_statistics_day` VALUES ('1428', '2015-09-21 00:00:00', '1239', '2016-01-25 06:38:20', '525', '763', '168', '320', '97', '2669.00', '172', '583', '10879');
INSERT INTO `edu_statistics_day` VALUES ('1429', '2015-09-22 00:00:00', '1231', '2016-01-25 06:38:20', '517', '754', '159', '312', '88', '2662.00', '163', '610', '10860');
INSERT INTO `edu_statistics_day` VALUES ('1430', '2015-09-23 00:00:00', '1223', '2016-01-25 06:38:20', '508', '747', '151', '303', '79', '2655.00', '154', '637', '10841');
INSERT INTO `edu_statistics_day` VALUES ('1431', '2015-09-24 00:00:00', '1215', '2016-01-25 06:38:20', '500', '738', '142', '294', '70', '2648.00', '146', '664', '10822');
INSERT INTO `edu_statistics_day` VALUES ('1432', '2015-09-25 00:00:00', '1207', '2016-01-25 06:38:20', '491', '729', '133', '286', '61', '2641.00', '137', '691', '10803');
INSERT INTO `edu_statistics_day` VALUES ('1433', '2015-09-26 00:00:00', '1199', '2016-01-25 06:38:20', '483', '722', '124', '277', '53', '2634.00', '128', '718', '10784');
INSERT INTO `edu_statistics_day` VALUES ('1434', '2015-09-27 00:00:00', '1191', '2016-01-25 06:38:20', '474', '713', '116', '268', '44', '2627.00', '119', '745', '10765');
INSERT INTO `edu_statistics_day` VALUES ('1435', '2015-09-28 00:00:00', '1183', '2016-01-25 06:38:20', '466', '704', '107', '260', '35', '2620.00', '110', '772', '10746');
INSERT INTO `edu_statistics_day` VALUES ('1436', '2015-09-29 00:00:00', '1175', '2016-01-25 06:38:20', '457', '697', '98', '251', '26', '2613.00', '101', '799', '10727');
INSERT INTO `edu_statistics_day` VALUES ('1437', '2015-09-30 00:00:00', '1167', '2016-01-25 06:38:20', '449', '688', '89', '242', '17', '2606.00', '93', '826', '10708');
INSERT INTO `edu_statistics_day` VALUES ('1438', '2015-10-01 00:00:00', '1428', '2016-01-25 06:38:20', '709', '948', '350', '503', '278', '2868.00', '353', '46', '11496');
INSERT INTO `edu_statistics_day` VALUES ('1439', '2015-10-02 00:00:00', '1419', '2016-01-25 06:38:20', '700', '940', '340', '493', '268', '2860.00', '343', '76', '11474');
INSERT INTO `edu_statistics_day` VALUES ('1440', '2015-10-03 00:00:00', '1410', '2016-01-25 06:38:20', '690', '930', '330', '483', '258', '2852.00', '333', '106', '11452');
INSERT INTO `edu_statistics_day` VALUES ('1441', '2015-10-04 00:00:00', '1401', '2016-01-25 06:38:20', '681', '920', '320', '474', '248', '2844.00', '323', '136', '11430');
INSERT INTO `edu_statistics_day` VALUES ('1442', '2015-10-05 00:00:00', '1392', '2016-01-25 06:38:20', '671', '912', '311', '464', '238', '2836.00', '313', '166', '11408');
INSERT INTO `edu_statistics_day` VALUES ('1443', '2015-10-06 00:00:00', '1383', '2016-01-25 06:38:20', '662', '902', '301', '454', '229', '2828.00', '304', '196', '11386');
INSERT INTO `edu_statistics_day` VALUES ('1444', '2015-10-07 00:00:00', '1374', '2016-01-25 06:38:20', '652', '892', '291', '445', '219', '2820.00', '294', '226', '11364');
INSERT INTO `edu_statistics_day` VALUES ('1445', '2015-10-08 00:00:00', '1365', '2016-01-25 06:38:20', '643', '884', '281', '435', '209', '2812.00', '284', '256', '11342');
INSERT INTO `edu_statistics_day` VALUES ('1446', '2015-10-09 00:00:00', '1356', '2016-01-25 06:38:20', '633', '874', '272', '425', '199', '2804.00', '274', '286', '11320');
INSERT INTO `edu_statistics_day` VALUES ('1447', '2015-10-10 00:00:00', '1347', '2016-01-25 06:38:20', '624', '864', '262', '416', '189', '2796.00', '264', '316', '11298');
INSERT INTO `edu_statistics_day` VALUES ('1448', '2015-10-11 00:00:00', '1338', '2016-01-25 06:38:20', '614', '856', '252', '406', '180', '2788.00', '254', '346', '11276');
INSERT INTO `edu_statistics_day` VALUES ('1449', '2015-10-12 00:00:00', '1329', '2016-01-25 06:38:20', '605', '846', '242', '396', '170', '2780.00', '245', '376', '11254');
INSERT INTO `edu_statistics_day` VALUES ('1450', '2015-10-13 00:00:00', '1320', '2016-01-25 06:38:20', '595', '836', '233', '387', '160', '2772.00', '235', '406', '11232');
INSERT INTO `edu_statistics_day` VALUES ('1451', '2015-10-14 00:00:00', '1311', '2016-01-25 06:38:20', '586', '828', '223', '377', '150', '2764.00', '225', '436', '11210');
INSERT INTO `edu_statistics_day` VALUES ('1452', '2015-10-15 00:00:00', '1302', '2016-01-25 06:38:20', '576', '818', '213', '367', '140', '2756.00', '215', '466', '11188');
INSERT INTO `edu_statistics_day` VALUES ('1453', '2015-10-16 00:00:00', '1293', '2016-01-25 06:38:20', '567', '808', '203', '358', '131', '2748.00', '205', '496', '11166');
INSERT INTO `edu_statistics_day` VALUES ('1454', '2015-10-17 00:00:00', '1284', '2016-01-25 06:38:20', '557', '800', '194', '348', '121', '2740.00', '195', '526', '11144');
INSERT INTO `edu_statistics_day` VALUES ('1455', '2015-10-18 00:00:00', '1275', '2016-01-25 06:38:20', '548', '790', '184', '338', '111', '2732.00', '186', '556', '11122');
INSERT INTO `edu_statistics_day` VALUES ('1456', '2015-10-19 00:00:00', '1266', '2016-01-25 06:38:20', '538', '780', '174', '329', '101', '2724.00', '176', '586', '11100');
INSERT INTO `edu_statistics_day` VALUES ('1457', '2015-10-20 00:00:00', '1257', '2016-01-25 06:38:20', '529', '772', '164', '319', '91', '2716.00', '166', '616', '11078');
INSERT INTO `edu_statistics_day` VALUES ('1458', '2015-10-21 00:00:00', '1248', '2016-01-25 06:38:20', '519', '762', '155', '309', '82', '2708.00', '156', '646', '11056');
INSERT INTO `edu_statistics_day` VALUES ('1459', '2015-10-22 00:00:00', '1239', '2016-01-25 06:38:20', '510', '752', '145', '300', '72', '2700.00', '146', '676', '11034');
INSERT INTO `edu_statistics_day` VALUES ('1460', '2015-10-23 00:00:00', '1230', '2016-01-25 06:38:20', '500', '744', '135', '290', '62', '2692.00', '136', '706', '11012');
INSERT INTO `edu_statistics_day` VALUES ('1461', '2015-10-24 00:00:00', '1221', '2016-01-25 06:38:20', '491', '734', '125', '280', '52', '2684.00', '127', '736', '10990');
INSERT INTO `edu_statistics_day` VALUES ('1462', '2015-10-25 00:00:00', '1212', '2016-01-25 06:38:20', '481', '724', '116', '271', '42', '2676.00', '117', '766', '10968');
INSERT INTO `edu_statistics_day` VALUES ('1463', '2015-10-26 00:00:00', '1203', '2016-01-25 06:38:20', '472', '716', '106', '261', '33', '2668.00', '107', '796', '10946');
INSERT INTO `edu_statistics_day` VALUES ('1464', '2015-10-27 00:00:00', '1194', '2016-01-25 06:38:20', '462', '706', '96', '251', '23', '2660.00', '97', '826', '10924');
INSERT INTO `edu_statistics_day` VALUES ('1465', '2015-10-28 00:00:00', '1185', '2016-01-25 06:38:20', '453', '696', '86', '242', '13', '2652.00', '87', '856', '10902');
INSERT INTO `edu_statistics_day` VALUES ('1466', '2015-10-29 00:00:00', '1176', '2016-01-25 06:38:20', '443', '688', '77', '232', '3', '2644.00', '77', '886', '10880');
INSERT INTO `edu_statistics_day` VALUES ('1467', '2015-10-30 00:00:00', '1167', '2016-01-25 06:38:20', '434', '678', '67', '222', '-7', '2636.00', '68', '916', '10858');
INSERT INTO `edu_statistics_day` VALUES ('1468', '2015-10-31 00:00:00', '1158', '2016-01-25 06:38:20', '424', '668', '57', '213', '-16', '2628.00', '58', '946', '10836');
INSERT INTO `edu_statistics_day` VALUES ('1469', '2015-11-01 00:00:00', '1458', '2016-01-25 06:38:20', '724', '969', '356', '512', '283', '2929.00', '357', '49', '11741');
INSERT INTO `edu_statistics_day` VALUES ('1470', '2015-11-02 00:00:00', '1448', '2016-01-25 06:38:20', '713', '958', '346', '501', '272', '2920.00', '346', '82', '11716');
INSERT INTO `edu_statistics_day` VALUES ('1471', '2015-11-03 00:00:00', '1438', '2016-01-25 06:38:20', '703', '947', '335', '491', '261', '2911.00', '335', '115', '11691');
INSERT INTO `edu_statistics_day` VALUES ('1472', '2015-11-04 00:00:00', '1428', '2016-01-25 06:38:20', '692', '938', '324', '480', '250', '2902.00', '324', '148', '11666');
INSERT INTO `edu_statistics_day` VALUES ('1473', '2015-11-05 00:00:00', '1418', '2016-01-25 06:38:20', '682', '927', '313', '469', '240', '2893.00', '314', '181', '11641');
INSERT INTO `edu_statistics_day` VALUES ('1474', '2015-11-06 00:00:00', '1408', '2016-01-25 06:38:20', '671', '916', '303', '459', '229', '2884.00', '303', '214', '11616');
INSERT INTO `edu_statistics_day` VALUES ('1475', '2015-11-07 00:00:00', '1398', '2016-01-25 06:38:20', '661', '907', '292', '448', '218', '2875.00', '292', '247', '11591');
INSERT INTO `edu_statistics_day` VALUES ('1476', '2015-11-08 00:00:00', '1388', '2016-01-25 06:38:20', '650', '896', '281', '437', '207', '2866.00', '281', '280', '11566');
INSERT INTO `edu_statistics_day` VALUES ('1477', '2015-11-09 00:00:00', '1378', '2016-01-25 06:38:20', '640', '885', '270', '427', '196', '2857.00', '270', '313', '11541');
INSERT INTO `edu_statistics_day` VALUES ('1478', '2015-11-10 00:00:00', '1368', '2016-01-25 06:38:20', '629', '876', '260', '416', '186', '2848.00', '259', '346', '11516');
INSERT INTO `edu_statistics_day` VALUES ('1479', '2015-11-11 00:00:00', '1358', '2016-01-25 06:38:20', '619', '865', '249', '405', '175', '2839.00', '249', '379', '11491');
INSERT INTO `edu_statistics_day` VALUES ('1480', '2015-11-12 00:00:00', '1348', '2016-01-25 06:38:20', '608', '854', '238', '395', '164', '2830.00', '238', '412', '11466');
INSERT INTO `edu_statistics_day` VALUES ('1481', '2015-11-13 00:00:00', '1338', '2016-01-25 06:38:20', '598', '845', '227', '384', '153', '2821.00', '227', '445', '11441');
INSERT INTO `edu_statistics_day` VALUES ('1482', '2015-11-14 00:00:00', '1328', '2016-01-25 06:38:20', '587', '834', '217', '373', '142', '2812.00', '216', '478', '11416');
INSERT INTO `edu_statistics_day` VALUES ('1483', '2015-11-15 00:00:00', '1318', '2016-01-25 06:38:20', '577', '823', '206', '363', '132', '2803.00', '205', '511', '11391');
INSERT INTO `edu_statistics_day` VALUES ('1484', '2015-11-16 00:00:00', '1308', '2016-01-25 06:38:20', '566', '814', '195', '352', '121', '2794.00', '194', '544', '11366');
INSERT INTO `edu_statistics_day` VALUES ('1485', '2015-11-17 00:00:00', '1298', '2016-01-25 06:38:20', '556', '803', '184', '341', '110', '2785.00', '184', '577', '11341');
INSERT INTO `edu_statistics_day` VALUES ('1486', '2015-11-18 00:00:00', '1288', '2016-01-25 06:38:20', '545', '792', '174', '331', '99', '2776.00', '173', '610', '11316');
INSERT INTO `edu_statistics_day` VALUES ('1487', '2015-11-19 00:00:00', '1278', '2016-01-25 06:38:20', '535', '783', '163', '320', '88', '2767.00', '162', '643', '11291');
INSERT INTO `edu_statistics_day` VALUES ('1488', '2015-11-20 00:00:00', '1268', '2016-01-25 06:38:20', '524', '772', '152', '309', '78', '2758.00', '151', '676', '11266');
INSERT INTO `edu_statistics_day` VALUES ('1489', '2015-11-21 00:00:00', '1258', '2016-01-25 06:38:20', '514', '761', '141', '299', '67', '2749.00', '140', '709', '11241');
INSERT INTO `edu_statistics_day` VALUES ('1490', '2015-11-22 00:00:00', '1248', '2016-01-25 06:38:20', '503', '752', '131', '288', '56', '2740.00', '129', '742', '11216');
INSERT INTO `edu_statistics_day` VALUES ('1491', '2015-11-23 00:00:00', '1238', '2016-01-25 06:38:20', '493', '741', '120', '277', '45', '2731.00', '119', '775', '11191');
INSERT INTO `edu_statistics_day` VALUES ('1492', '2015-11-24 00:00:00', '1228', '2016-01-25 06:38:20', '482', '730', '109', '267', '34', '2722.00', '108', '808', '11166');
INSERT INTO `edu_statistics_day` VALUES ('1493', '2015-11-25 00:00:00', '1218', '2016-01-25 06:38:20', '472', '721', '98', '256', '24', '2713.00', '97', '841', '11141');
INSERT INTO `edu_statistics_day` VALUES ('1494', '2015-11-26 00:00:00', '1208', '2016-01-25 06:38:20', '461', '710', '88', '245', '13', '2704.00', '86', '874', '11116');
INSERT INTO `edu_statistics_day` VALUES ('1495', '2015-11-27 00:00:00', '1198', '2016-01-25 06:38:20', '451', '699', '77', '235', '2', '2695.00', '75', '907', '11091');
INSERT INTO `edu_statistics_day` VALUES ('1496', '2015-11-28 00:00:00', '1188', '2016-01-25 06:38:20', '440', '690', '66', '224', '-9', '2686.00', '64', '940', '11066');
INSERT INTO `edu_statistics_day` VALUES ('1497', '2015-11-29 00:00:00', '1178', '2016-01-25 06:38:20', '430', '679', '55', '213', '-20', '2677.00', '54', '973', '11041');
INSERT INTO `edu_statistics_day` VALUES ('1498', '2015-11-30 00:00:00', '1168', '2016-01-25 06:38:20', '419', '668', '45', '203', '-30', '2668.00', '43', '1006', '11016');
INSERT INTO `edu_statistics_day` VALUES ('1499', '2015-12-01 00:00:00', '1487', '2016-01-25 06:38:20', '738', '988', '363', '521', '288', '2988.00', '361', '52', '11978');
INSERT INTO `edu_statistics_day` VALUES ('1500', '2015-12-02 00:00:00', '1476', '2016-01-25 06:38:20', '726', '976', '351', '509', '276', '2978.00', '349', '88', '11950');
INSERT INTO `edu_statistics_day` VALUES ('1501', '2015-12-03 00:00:00', '1465', '2016-01-25 06:38:20', '715', '964', '339', '498', '264', '2968.00', '337', '124', '11922');
INSERT INTO `edu_statistics_day` VALUES ('1502', '2015-12-04 00:00:00', '1454', '2016-01-25 06:38:20', '703', '954', '328', '486', '252', '2958.00', '325', '160', '11894');
INSERT INTO `edu_statistics_day` VALUES ('1503', '2015-12-05 00:00:00', '1443', '2016-01-25 06:38:20', '692', '942', '316', '474', '241', '2948.00', '314', '196', '11866');
INSERT INTO `edu_statistics_day` VALUES ('1504', '2015-12-06 00:00:00', '1432', '2016-01-25 06:38:20', '680', '930', '304', '463', '229', '2938.00', '302', '232', '11838');
INSERT INTO `edu_statistics_day` VALUES ('1505', '2015-12-07 00:00:00', '1421', '2016-01-25 06:38:20', '669', '920', '292', '451', '217', '2928.00', '290', '268', '11810');
INSERT INTO `edu_statistics_day` VALUES ('1506', '2015-12-08 00:00:00', '1410', '2016-01-25 06:38:20', '657', '908', '281', '439', '205', '2918.00', '278', '304', '11782');
INSERT INTO `edu_statistics_day` VALUES ('1507', '2015-12-09 00:00:00', '1399', '2016-01-25 06:38:20', '646', '896', '269', '428', '193', '2908.00', '266', '340', '11754');
INSERT INTO `edu_statistics_day` VALUES ('1508', '2015-12-10 00:00:00', '1388', '2016-01-25 06:38:20', '634', '886', '257', '416', '182', '2898.00', '254', '376', '11726');
INSERT INTO `edu_statistics_day` VALUES ('1509', '2015-12-11 00:00:00', '1377', '2016-01-25 06:38:20', '623', '874', '245', '404', '170', '2888.00', '243', '412', '11698');
INSERT INTO `edu_statistics_day` VALUES ('1510', '2015-12-12 00:00:00', '1366', '2016-01-25 06:38:20', '611', '862', '234', '393', '158', '2878.00', '231', '448', '11670');
INSERT INTO `edu_statistics_day` VALUES ('1511', '2015-12-13 00:00:00', '1355', '2016-01-25 06:38:20', '600', '852', '222', '381', '146', '2868.00', '219', '484', '11642');
INSERT INTO `edu_statistics_day` VALUES ('1512', '2015-12-14 00:00:00', '1344', '2016-01-25 06:38:20', '588', '840', '210', '369', '134', '2858.00', '207', '520', '11614');
INSERT INTO `edu_statistics_day` VALUES ('1513', '2015-12-15 00:00:00', '1333', '2016-01-25 06:38:20', '577', '828', '198', '358', '123', '2848.00', '195', '556', '11586');
INSERT INTO `edu_statistics_day` VALUES ('1514', '2015-12-16 00:00:00', '1322', '2016-01-25 06:38:20', '565', '818', '187', '346', '111', '2838.00', '183', '592', '11558');
INSERT INTO `edu_statistics_day` VALUES ('1515', '2015-12-17 00:00:00', '1311', '2016-01-25 06:38:20', '554', '806', '175', '334', '99', '2828.00', '172', '628', '11530');
INSERT INTO `edu_statistics_day` VALUES ('1516', '2015-12-18 00:00:00', '1300', '2016-01-25 06:38:20', '542', '794', '163', '323', '87', '2818.00', '160', '664', '11502');
INSERT INTO `edu_statistics_day` VALUES ('1517', '2015-12-19 00:00:00', '1289', '2016-01-25 06:38:20', '531', '784', '151', '311', '75', '2808.00', '148', '700', '11474');
INSERT INTO `edu_statistics_day` VALUES ('1518', '2015-12-20 00:00:00', '1278', '2016-01-25 06:38:20', '519', '772', '140', '299', '64', '2798.00', '136', '736', '11446');
INSERT INTO `edu_statistics_day` VALUES ('1519', '2015-12-21 00:00:00', '1267', '2016-01-25 06:38:20', '508', '760', '128', '288', '52', '2788.00', '124', '772', '11418');
INSERT INTO `edu_statistics_day` VALUES ('1520', '2015-12-22 00:00:00', '1256', '2016-01-25 06:38:20', '496', '750', '116', '276', '40', '2778.00', '112', '808', '11390');
INSERT INTO `edu_statistics_day` VALUES ('1521', '2015-12-23 00:00:00', '1245', '2016-01-25 06:38:20', '485', '738', '104', '264', '28', '2768.00', '101', '844', '11362');
INSERT INTO `edu_statistics_day` VALUES ('1522', '2015-12-24 00:00:00', '1234', '2016-01-25 06:38:20', '473', '726', '93', '253', '16', '2758.00', '89', '880', '11334');
INSERT INTO `edu_statistics_day` VALUES ('1523', '2015-12-25 00:00:00', '1223', '2016-01-25 06:38:20', '462', '716', '81', '241', '5', '2748.00', '77', '916', '11306');
INSERT INTO `edu_statistics_day` VALUES ('1524', '2015-12-26 00:00:00', '1212', '2016-01-25 06:38:20', '450', '704', '69', '229', '-7', '2738.00', '65', '952', '11278');
INSERT INTO `edu_statistics_day` VALUES ('1525', '2015-12-27 00:00:00', '1201', '2016-01-25 06:38:20', '439', '692', '57', '218', '-19', '2728.00', '53', '988', '11250');
INSERT INTO `edu_statistics_day` VALUES ('1526', '2015-12-28 00:00:00', '1190', '2016-01-25 06:38:20', '427', '682', '46', '206', '-31', '2718.00', '41', '1024', '11222');
INSERT INTO `edu_statistics_day` VALUES ('1527', '2015-12-29 00:00:00', '1179', '2016-01-25 06:38:20', '416', '670', '34', '194', '-43', '2708.00', '30', '1060', '11194');
INSERT INTO `edu_statistics_day` VALUES ('1528', '2015-12-30 00:00:00', '1168', '2016-01-25 06:38:20', '404', '658', '22', '183', '-54', '2698.00', '18', '1096', '11166');
INSERT INTO `edu_statistics_day` VALUES ('1529', '2015-12-31 00:00:00', '1157', '2016-01-25 06:38:20', '393', '648', '10', '171', '-66', '2688.00', '6', '1132', '11138');
INSERT INTO `edu_statistics_day` VALUES ('1530', '2016-01-01 00:00:00', '1529', '2016-01-25 06:38:20', '764', '1019', '382', '542', '305', '3061.00', '377', '19', '12259');
INSERT INTO `edu_statistics_day` VALUES ('1531', '2016-01-02 00:00:00', '1529', '2016-01-25 06:38:20', '764', '1018', '381', '542', '304', '3062.00', '376', '22', '12264');
INSERT INTO `edu_statistics_day` VALUES ('1532', '2016-01-03 00:00:00', '1529', '2016-01-25 06:38:20', '763', '1019', '380', '541', '303', '3063.00', '375', '25', '12269');
INSERT INTO `edu_statistics_day` VALUES ('1533', '2016-01-04 00:00:00', '1529', '2016-01-25 06:38:20', '763', '1018', '379', '540', '303', '3064.00', '375', '28', '12274');
INSERT INTO `edu_statistics_day` VALUES ('1534', '2016-01-05 00:00:00', '1529', '2016-01-25 06:38:20', '762', '1017', '379', '540', '302', '3065.00', '374', '31', '12279');
INSERT INTO `edu_statistics_day` VALUES ('1535', '2016-01-06 00:00:00', '1529', '2016-01-25 06:38:20', '762', '1018', '378', '539', '301', '3066.00', '373', '34', '12284');
INSERT INTO `edu_statistics_day` VALUES ('1536', '2016-01-07 00:00:00', '1529', '2016-01-25 06:38:20', '761', '1017', '377', '538', '300', '3067.00', '372', '37', '12289');
INSERT INTO `edu_statistics_day` VALUES ('1537', '2016-01-08 00:00:00', '1529', '2016-01-25 06:38:20', '761', '1016', '376', '538', '299', '3068.00', '371', '40', '12294');
INSERT INTO `edu_statistics_day` VALUES ('1538', '2016-01-09 00:00:00', '1529', '2016-01-25 06:38:20', '760', '1017', '376', '537', '299', '3069.00', '370', '43', '12299');
INSERT INTO `edu_statistics_day` VALUES ('1539', '2016-01-10 00:00:00', '1529', '2016-01-25 06:38:20', '760', '1016', '375', '536', '298', '3070.00', '370', '46', '12304');
INSERT INTO `edu_statistics_day` VALUES ('1540', '2016-01-11 00:00:00', '1529', '2016-01-25 06:38:20', '759', '1015', '374', '536', '297', '3071.00', '369', '49', '12309');
INSERT INTO `edu_statistics_day` VALUES ('1541', '2016-01-12 00:00:00', '1529', '2016-01-25 06:38:20', '759', '1016', '373', '535', '296', '3072.00', '368', '52', '12314');
INSERT INTO `edu_statistics_day` VALUES ('1542', '2016-01-13 00:00:00', '1529', '2016-01-25 06:38:20', '758', '1015', '373', '534', '295', '3073.00', '367', '55', '12319');
INSERT INTO `edu_statistics_day` VALUES ('1543', '2016-01-14 00:00:00', '1529', '2016-01-25 06:38:20', '758', '1014', '372', '534', '295', '3074.00', '366', '58', '12324');
INSERT INTO `edu_statistics_day` VALUES ('1544', '2016-01-15 00:00:00', '1529', '2016-01-25 06:38:20', '757', '1015', '371', '533', '294', '3075.00', '365', '61', '12329');
INSERT INTO `edu_statistics_day` VALUES ('1545', '2016-01-16 00:00:00', '1529', '2016-01-25 06:38:20', '757', '1014', '370', '532', '293', '3076.00', '365', '64', '12334');
INSERT INTO `edu_statistics_day` VALUES ('1546', '2016-01-17 00:00:00', '1529', '2016-01-25 06:38:20', '756', '1013', '370', '532', '292', '3077.00', '364', '67', '12339');
INSERT INTO `edu_statistics_day` VALUES ('1547', '2016-01-18 00:00:00', '1529', '2016-01-25 06:38:20', '756', '1014', '369', '531', '291', '3078.00', '363', '70', '12344');
INSERT INTO `edu_statistics_day` VALUES ('1548', '2016-01-19 00:00:00', '1529', '2016-01-25 06:38:20', '755', '1013', '368', '530', '291', '3079.00', '362', '73', '12349');
INSERT INTO `edu_statistics_day` VALUES ('1549', '2016-01-20 00:00:00', '1529', '2016-01-25 06:38:20', '755', '1012', '367', '530', '290', '3080.00', '361', '76', '12354');
INSERT INTO `edu_statistics_day` VALUES ('1550', '2016-01-21 00:00:00', '1529', '2016-01-25 06:38:20', '754', '1013', '367', '529', '289', '3081.00', '360', '79', '12359');
INSERT INTO `edu_statistics_day` VALUES ('1551', '2016-01-22 00:00:00', '1529', '2016-01-25 06:38:20', '754', '1012', '366', '528', '288', '3082.00', '360', '82', '12364');
INSERT INTO `edu_statistics_day` VALUES ('1552', '2016-01-23 00:00:00', '1529', '2016-01-25 06:38:20', '753', '1011', '365', '528', '287', '3083.00', '359', '85', '12369');
INSERT INTO `edu_statistics_day` VALUES ('1553', '2016-01-24 00:00:00', '1529', '2016-01-25 06:38:20', '753', '1012', '364', '527', '287', '3084.00', '358', '88', '12374');
INSERT INTO `edu_statistics_day` VALUES ('1554', '2016-01-25 00:00:00', '1529', '2016-02-27 04:33:40', '752', '1011', '364', '526', '286', '3085.00', '357', '91', '12379');
INSERT INTO `edu_statistics_day` VALUES ('1555', '2016-01-26 00:00:00', '1529', '2016-02-27 04:33:40', '752', '1010', '363', '526', '285', '3086.00', '356', '94', '12384');
INSERT INTO `edu_statistics_day` VALUES ('1556', '2016-01-27 00:00:00', '1529', '2016-02-27 04:33:40', '751', '1011', '362', '525', '284', '3087.00', '355', '97', '12389');
INSERT INTO `edu_statistics_day` VALUES ('1557', '2016-01-28 00:00:00', '1529', '2016-02-27 04:33:40', '751', '1010', '361', '524', '283', '3088.00', '355', '100', '12394');
INSERT INTO `edu_statistics_day` VALUES ('1558', '2016-01-29 00:00:00', '1529', '2016-02-27 04:33:40', '750', '1009', '361', '524', '283', '3089.00', '354', '103', '12399');
INSERT INTO `edu_statistics_day` VALUES ('1559', '2016-01-30 00:00:00', '1529', '2016-02-27 04:33:40', '750', '1010', '360', '523', '282', '3090.00', '353', '106', '12404');
INSERT INTO `edu_statistics_day` VALUES ('1560', '2016-01-31 00:00:00', '1529', '2016-02-27 04:33:40', '749', '1009', '359', '522', '281', '3091.00', '352', '109', '12409');
INSERT INTO `edu_statistics_day` VALUES ('1561', '2016-02-01 00:00:00', '1559', '2016-02-27 04:33:40', '779', '1038', '388', '552', '310', '3122.00', '381', '22', '12504');
INSERT INTO `edu_statistics_day` VALUES ('1562', '2016-02-02 00:00:00', '1558', '2016-02-27 04:33:40', '777', '1038', '387', '550', '308', '3122.00', '379', '28', '12506');
INSERT INTO `edu_statistics_day` VALUES ('1563', '2016-02-03 00:00:00', '1557', '2016-02-27 04:33:40', '776', '1036', '385', '548', '307', '3122.00', '378', '34', '12508');
INSERT INTO `edu_statistics_day` VALUES ('1564', '2016-02-04 00:00:00', '1556', '2016-02-27 04:33:40', '774', '1034', '383', '547', '305', '3122.00', '376', '40', '12510');
INSERT INTO `edu_statistics_day` VALUES ('1565', '2016-02-05 00:00:00', '1555', '2016-02-27 04:33:40', '773', '1034', '381', '545', '303', '3122.00', '374', '46', '12512');
INSERT INTO `edu_statistics_day` VALUES ('1566', '2016-02-06 00:00:00', '1554', '2016-02-27 04:33:40', '771', '1032', '380', '543', '301', '3122.00', '372', '52', '12514');
INSERT INTO `edu_statistics_day` VALUES ('1567', '2016-02-07 00:00:00', '1553', '2016-02-27 04:33:40', '770', '1030', '378', '542', '299', '3122.00', '370', '58', '12516');
INSERT INTO `edu_statistics_day` VALUES ('1568', '2016-02-08 00:00:00', '1552', '2016-02-27 04:33:40', '768', '1030', '376', '540', '298', '3122.00', '368', '64', '12518');
INSERT INTO `edu_statistics_day` VALUES ('1569', '2016-02-09 00:00:00', '1551', '2016-02-27 04:33:40', '767', '1028', '374', '538', '296', '3122.00', '367', '70', '12520');
INSERT INTO `edu_statistics_day` VALUES ('1570', '2016-02-10 00:00:00', '1550', '2016-02-27 04:33:40', '765', '1026', '373', '537', '294', '3122.00', '365', '76', '12522');
INSERT INTO `edu_statistics_day` VALUES ('1571', '2016-02-11 00:00:00', '1549', '2016-02-27 04:33:40', '764', '1026', '371', '535', '292', '3122.00', '363', '82', '12524');
INSERT INTO `edu_statistics_day` VALUES ('1572', '2016-02-12 00:00:00', '1548', '2016-02-27 04:33:40', '762', '1024', '369', '533', '290', '3122.00', '361', '88', '12526');
INSERT INTO `edu_statistics_day` VALUES ('1573', '2016-02-13 00:00:00', '1547', '2016-02-27 04:33:40', '761', '1022', '367', '532', '289', '3122.00', '359', '94', '12528');
INSERT INTO `edu_statistics_day` VALUES ('1574', '2016-02-14 00:00:00', '1546', '2016-02-27 04:33:40', '759', '1022', '366', '530', '287', '3122.00', '357', '100', '12530');
INSERT INTO `edu_statistics_day` VALUES ('1575', '2016-02-15 00:00:00', '1545', '2016-02-27 04:33:40', '758', '1020', '364', '528', '285', '3122.00', '356', '106', '12532');
INSERT INTO `edu_statistics_day` VALUES ('1576', '2016-02-16 00:00:00', '1544', '2016-02-27 04:33:40', '756', '1018', '362', '527', '283', '3122.00', '354', '112', '12534');
INSERT INTO `edu_statistics_day` VALUES ('1577', '2016-02-17 00:00:00', '1543', '2016-02-27 04:33:40', '755', '1018', '360', '525', '281', '3122.00', '352', '118', '12536');
INSERT INTO `edu_statistics_day` VALUES ('1578', '2016-02-18 00:00:00', '1542', '2016-02-27 04:33:40', '753', '1016', '359', '523', '280', '3122.00', '350', '124', '12538');
INSERT INTO `edu_statistics_day` VALUES ('1579', '2016-02-19 00:00:00', '1541', '2016-02-27 04:33:40', '752', '1014', '357', '522', '278', '3122.00', '348', '130', '12540');
INSERT INTO `edu_statistics_day` VALUES ('1580', '2016-02-20 00:00:00', '1540', '2016-02-27 04:33:40', '750', '1014', '355', '520', '276', '3122.00', '346', '136', '12542');
INSERT INTO `edu_statistics_day` VALUES ('1581', '2016-02-21 00:00:00', '1539', '2016-02-27 04:33:40', '749', '1012', '353', '518', '274', '3122.00', '345', '142', '12544');
INSERT INTO `edu_statistics_day` VALUES ('1582', '2016-02-22 00:00:00', '1538', '2016-02-27 04:33:40', '747', '1010', '352', '517', '272', '3122.00', '343', '148', '12546');
INSERT INTO `edu_statistics_day` VALUES ('1583', '2016-02-23 00:00:00', '1537', '2016-02-27 04:33:40', '746', '1010', '350', '515', '271', '3122.00', '341', '154', '12548');
INSERT INTO `edu_statistics_day` VALUES ('1584', '2016-02-24 00:00:00', '1536', '2016-02-27 04:33:40', '744', '1008', '348', '513', '269', '3122.00', '339', '160', '12550');
INSERT INTO `edu_statistics_day` VALUES ('1585', '2016-02-25 00:00:00', '1535', '2016-02-27 04:33:40', '743', '1006', '346', '512', '267', '3122.00', '337', '166', '12552');
INSERT INTO `edu_statistics_day` VALUES ('1586', '2016-02-26 00:00:00', '1534', '2016-02-27 04:33:40', '741', '1006', '345', '510', '265', '3122.00', '335', '172', '12554');
INSERT INTO `edu_statistics_day` VALUES ('1587', '2016-03-10 00:00:00', '1', '2016-03-10 18:56:46', '0', '1', '1', '0', '0', '10.00', '7', '16', '14');
INSERT INTO `edu_statistics_day` VALUES ('1588', '2016-03-14 00:00:00', '1', '2016-03-15 04:23:30', '0', '0', '0', '0', '0', '0.00', '1', '16', '14');
INSERT INTO `edu_statistics_day` VALUES ('1589', '2016-03-15 00:00:00', '1', '2016-03-16 04:37:48', '0', '0', '0', '0', '0', '0.00', '6', '16', '14');
INSERT INTO `edu_statistics_day` VALUES ('1590', '2016-05-21 00:00:00', '1', '2016-05-22 00:10:00', '0', '0', '0', '0', '0', '0.00', '0', '13', '9');
INSERT INTO `edu_statistics_day` VALUES ('1591', '2016-11-11 00:00:00', '2', '2016-11-12 00:10:00', '0', '0', '0', '0', '0', '0.00', '0', '4', '14');
INSERT INTO `edu_statistics_day` VALUES ('1592', '2016-11-12 00:00:00', '0', '2016-11-13 00:10:00', '0', '0', '0', '0', '0', '0.00', '0', '4', '14');
INSERT INTO `edu_statistics_day` VALUES ('1593', '2016-11-13 00:00:00', '0', '2016-11-14 00:10:00', '0', '0', '0', '0', '0', '0.00', '0', '4', '14');
INSERT INTO `edu_statistics_day` VALUES ('1594', '2016-11-14 00:00:00', '7', '2016-11-15 00:10:00', '6', '1', '0', '1', '0', '0.00', '0', '10', '14');
INSERT INTO `edu_statistics_day` VALUES ('1595', '2016-11-16 00:00:00', '7', '2016-11-17 00:10:00', '6', '0', '0', '0', '0', '0.00', '0', '6', '8');
INSERT INTO `edu_statistics_day` VALUES ('1596', '2016-11-17 00:00:00', '7', '2016-11-18 00:10:00', '5', '0', '0', '0', '0', '0.00', '0', '11', '8');
INSERT INTO `edu_statistics_day` VALUES ('1597', '2016-11-23 00:00:00', '0', '2016-11-25 00:10:00', '0', '0', '0', '0', '0', '0.00', '0', '12', '9');

-- ----------------------------
-- Table structure for edu_teacher
-- ----------------------------
DROP TABLE IF EXISTS `edu_teacher`;
CREATE TABLE `edu_teacher` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '教师ID',
  `NAME` varchar(12) NOT NULL DEFAULT '' COMMENT '教师名称',
  `EDUCATION` varchar(200) NOT NULL DEFAULT '' COMMENT '教师资历,一句话说明老师',
  `CAREER` text NOT NULL COMMENT '教师简介',
  `IS_STAR` tinyint(1) NOT NULL DEFAULT '0' COMMENT '头衔 1高级讲师2首席讲师',
  `PIC_PATH` varchar(200) NOT NULL DEFAULT '' COMMENT '图片路径',
  `STATUS` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态:0正常1删除',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT '更新时间',
  `SUBJECT_ID` int(11) DEFAULT '0' COMMENT '专业ID',
  `SORT` int(11) DEFAULT '0' COMMENT '排序',
  `USER_ID` int(11) DEFAULT NULL COMMENT 'edu_user的外键',
  `LOGIN_ACCOUNT` varchar(255) DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `NAME` (`NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='讲师';

-- ----------------------------
-- Records of edu_teacher
-- ----------------------------
INSERT INTO `edu_teacher` VALUES ('73', '李诚', '毕业于师范大学数学系，热爱教育事业，执教数学思维6年有余', '具备深厚的数学思维功底、丰富的小学教育经验，授课风格生动活泼，擅长用形象生动的比喻帮助理解、简单易懂的语言讲解难题，深受学生喜欢', '1', '/images/upload/teacher/20150915/1442298121626.jpg', '0', '2015-03-30 17:15:57', '2015-09-15 14:22:03', '218', '0', null, '');
INSERT INTO `edu_teacher` VALUES ('74', '马妮妮', '中国人民大学附属中学数学一级教师', '  中国科学院数学与系统科学研究院应用数学专业博士，研究方向为数字图像处理，中国工业与应用数学学会会员。参与全国教育科学“十五”规划重点课题“信息化进程中的教育技术发展研究”的子课题“基与课程改革的资源开发与应用”，以及全国“十五”科研规划全国重点项目“掌上型信息技术产品在教学中的运用和开发研究”的子课题“用技术学数学”。', '2', '/images/upload/teacher/20150915/1442297957332.jpg', '0', '2015-03-30 18:28:26', '2016-04-19 11:02:17', '210', '0', null, '');
INSERT INTO `edu_teacher` VALUES ('75', '张云唻', '毕业于北京大学数学系', '中教一级职称。讲课极具亲和力。', '1', '/images/upload/teacher/20150915/1442297969808.jpg', '0', '2015-03-31 09:20:46', '2015-09-15 14:19:30', '202', '0', null, '');
INSERT INTO `edu_teacher` VALUES ('76', '王健化', '长期从事考研政治课讲授和考研命题趋势与应试对策研究。考研辅导新锐派的代表。', '政治学博士、管理学博士后，北京师范大学马克思主义学院副教授。多年来总结出了一套行之有效的应试技巧与答题方法，针对性和实用性极强，能帮助考生在轻松中应考，在激励的竞争中取得高分，脱颖而出。', '1', '/images/upload/teacher/20150915/1442297977255.jpg', '0', '2015-04-03 14:13:51', '2015-09-15 14:19:38', '202', '0', null, '');
INSERT INTO `edu_teacher` VALUES ('77', '林奇', '人大附中2009届毕业生', '北京大学数学科学学院2008级本科生，2012年第八届学生五四奖章获得者，在数学领域取得多项国际国内奖项，学术研究成绩突出。曾被两次评为北京大学三好学生、一次评为北京大学三好标兵，获得过北京大学国家奖学金、北京大学廖凯原奖学金、北京大学星光国际一等奖学金、北京大学明德新生奖学金等。', '1', '/images/upload/teacher/20150915/1442297987091.jpg', '0', '2015-04-03 14:15:36', '2015-09-15 14:19:50', '224', '0', null, '');
INSERT INTO `edu_teacher` VALUES ('78', '陈红', '华东师范大学数学系硕士生导师，中国数学奥林匹克高级教练', '曾参与北京市及全国多项数学活动的命题和组织工作，多次带领北京队参加高中、初中、小学的各项数学竞赛，均取得优异成绩。教学活而新，能够调动学生的学习兴趣并擅长对学生进行思维点拨，对学生学习习惯的养成和非智力因素培养有独到之处，是一位深受学生喜爱的老师。', '1', '/images/upload/teacher/20150915/1442297999141.jpg', '0', '2015-04-03 14:19:28', '2015-09-15 14:20:00', '224', '0', null, '');
INSERT INTO `edu_teacher` VALUES ('80', '潘新强', '考研政治辅导实战派专家，全国考研政治命题研究组核心成员。', '法学博士，北京师范大学马克思主义学院副教授，专攻毛泽东思想概论、邓小平理论，长期从事考研辅导。出版著作两部，发表学术论文30余篇，主持国家社会科学基金项目和教育部重大课题子课题各一项，参与中央实施马克思主义理论研究和建设工程项目。', '2', '/images/upload/teacher/20150915/1442297935589.jpg', '0', '2015-04-03 14:21:03', '2015-09-15 14:18:56', '221', '8', null, '');
INSERT INTO `edu_teacher` VALUES ('81', '李立', '上海师范大学法学院副教授', '上海师范大学法学院副教授、清华大学法学博士。自2004年至今已有9年的司法考试培训经验。长期从事司法考试辅导，深知命题规律，了解解题技巧。内容把握准确，授课重点明确，层次分明，调理清晰，将法条法理与案例有机融合，强调综合，深入浅出。', '1', '/images/upload/teacher/20150915/1442297927029.jpg', '0', '2015-04-03 14:23:06', '2015-09-15 14:18:48', '209', '9', null, '');
INSERT INTO `edu_teacher` VALUES ('82', '李小梅', '资深课程设计专家，专注10年AACTP美国培训协会认证导师', '十年课程研发和培训咨询经验，曾任国企人力资源经理、大型外企培训经理，负责企业大学和培训体系搭建；曾任专业培训机构高级顾问、研发部总监，为包括广东移动、东莞移动、深圳移动、南方电网、工商银行、农业银行、民生银行、邮储银行、TCL集团、清华大学继续教育学院、中天路桥、广西扬翔股份等超过200家企业提供过培训与咨询服务，并担任近50个大型项目的总负责人。', '1', '/images/upload/teacher/20150915/1442297919077.jpg', '0', '2015-04-03 14:23:33', '2015-09-15 14:18:40', '204', '10', null, '');
INSERT INTO `edu_teacher` VALUES ('83', '陈晓薇', '北京师范大学法学院副教授', '北京师范大学法学院副教授、清华大学法学博士。自2004年至今已有9年的司法考试培训经验。长期从事司法考试辅导，深知命题规律，了解解题技巧。内容把握准确，授课重点明确，层次分明，调理清晰，将法条法理与案例有机融合，强调综合，深入浅出。', '1', '/images/upload/teacher/20150915/1442297885942.jpg', '0', '2015-04-03 14:32:19', '2015-09-15 14:18:11', '224', '20', null, '');

-- ----------------------------
-- Table structure for edu_trxorder_detail
-- ----------------------------
DROP TABLE IF EXISTS `edu_trxorder_detail`;
CREATE TABLE `edu_trxorder_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `course_id` int(11) unsigned NOT NULL COMMENT '相关联的课程id/套餐id（前台快照）',
  `trxorder_id` int(11) NOT NULL DEFAULT '0' COMMENT '交易订单ID',
  `membertype` tinyint(3) DEFAULT '0' COMMENT '会员观看类型（前台快照）',
  `losetype` int(3) NOT NULL DEFAULT '0' COMMENT '有效期类型（前台快照）',
  `lose_abs_time` datetime DEFAULT NULL COMMENT '订单过期时间段（前台快照）',
  `lose_time` varchar(255) DEFAULT NULL COMMENT '订单过期时间点（前台快照）',
  `auth_time` datetime DEFAULT NULL COMMENT '课程过期时间',
  `create_time` datetime DEFAULT NULL COMMENT '下单时间',
  `pay_time` datetime DEFAULT NULL COMMENT '支付成功时间',
  `source_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '原价格（前台快照）',
  `coupon_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '优惠价格',
  `current_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '销售价格（前台快照）',
  `course_name` varchar(255) NOT NULL DEFAULT '' COMMENT '课程名称（前台goods快照）',
  `trx_status` char(15) NOT NULL DEFAULT '' COMMENT '订单状态（前台goods快照）',
  `auth_status` char(10) NOT NULL DEFAULT '' COMMENT '课程状态（INIT，SUCCESS，REFUND，CLOSED，LOSED）',
  `request_id` varchar(50) NOT NULL DEFAULT '' COMMENT '订单请求号',
  `description` varchar(50) NOT NULL DEFAULT '' COMMENT '描述',
  `version` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '乐观锁版本号',
  `last_update_time` datetime DEFAULT NULL COMMENT '最后更新时间',
  `remind_status` varchar(255) DEFAULT 'INIT' COMMENT '过期是否提醒 INIT 未提醒 ALREADY 已提醒',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `trxorder_id` (`trxorder_id`),
  KEY `IDX_REQUEST_ID` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='流水表';

-- ----------------------------
-- Records of edu_trxorder_detail
-- ----------------------------

-- ----------------------------
-- Table structure for edu_user
-- ----------------------------
DROP TABLE IF EXISTS `edu_user`;
CREATE TABLE `edu_user` (
  `USER_ID` bigint(50) NOT NULL AUTO_INCREMENT COMMENT '学员ID',
  `MOBILE` varchar(11) DEFAULT NULL COMMENT '手机号',
  `EMAIL` varchar(50) DEFAULT NULL COMMENT '邮箱号',
  `PASSWORD` varchar(64) DEFAULT NULL COMMENT '密码',
  `USER_NAME` varchar(50) DEFAULT NULL COMMENT '用户名',
  `SHOW_NAME` varchar(50) DEFAULT NULL COMMENT '显示名 （昵称）',
  `SEX` tinyint(1) DEFAULT '0' COMMENT '性别  1男  2女',
  `AGE` tinyint(3) DEFAULT '0' COMMENT '年龄',
  `CREATE_TIME` timestamp NULL DEFAULT NULL COMMENT '注册时间',
  `IS_AVALIBLE` tinyint(1) DEFAULT '1' COMMENT '是否可用 1正常  2冻结',
  `PIC_IMG` varchar(255) DEFAULT NULL COMMENT '用户头像',
  `BANNER_URL` varchar(200) DEFAULT NULL COMMENT '个人中心用户背景图片',
  `MSG_NUM` int(11) DEFAULT '0' COMMENT '站内信未读消息数',
  `SYS_MSG_NUM` int(11) DEFAULT '0',
  `LAST_SYSTEM_TIME` datetime DEFAULT NULL COMMENT '上传统计系统消息时间',
  `LOGIN_ACCOUNT` varchar(255) DEFAULT NULL COMMENT '登录账号',
  `REGISTER_FROM` varchar(20) DEFAULT 'register' COMMENT '注册来源',
  `TEACHER_ID` int(11) DEFAULT NULL COMMENT '如果用户为教师，该项不为空',
  `SCHOOL_ID` bigint(50) DEFAULT NULL,
  `ROLE` varchar(255) DEFAULT NULL,
  `ROLE_FLAG` int(11) DEFAULT NULL,
  `EXPIRY_DATE` datetime DEFAULT NULL,
  `OUT_ID` varchar(50) DEFAULT NULL,
  `SOURCE` int(255) DEFAULT NULL,
  `REF_ID` int(11) DEFAULT NULL COMMENT '同步云平台特有字段',
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 COMMENT='学员表';

-- ----------------------------
-- Records of edu_user
-- ----------------------------
INSERT INTO `edu_user` VALUES ('1', '1', '752628096@qq.com', '96e79218965eb72c92a549dd5a330112', 'liffi111', '测试学生', '0', '23', '2016-11-16 11:10:47', '1', null, null, '0', '0', '2016-11-16 17:27:29', null, 'register', null, '132132', 'student', '7', null, '123', '0', null);
INSERT INTO `edu_user` VALUES ('50', '2', '12345611@qq.com', '96e79218965eb72c92a549dd5a330112', 'liffi111', '测试老师', '0', '42', '2016-11-16 11:09:06', '1', null, null, '0', '0', null, '', 'register', null, '0', 'teacher', '5', null, '123', '0', null);
INSERT INTO `edu_user` VALUES ('52', null, null, null, null, '104', '0', '0', '2016-11-16 14:17:22', '1', null, null, '0', '0', null, '104', '3', null, '0', null, null, null, '0', '0', null);
INSERT INTO `edu_user` VALUES ('53', null, null, null, null, '106', '0', '0', '2016-11-16 21:33:25', '1', null, null, '0', '0', null, '106', '3', null, '0', 'student', '7', null, '0', '0', null);
INSERT INTO `edu_user` VALUES ('54', null, null, null, null, '106', '0', '0', '2016-11-16 21:35:30', '1', null, null, '0', '0', null, '106', '3', null, '0', 'student', '7', null, '0', '0', null);
INSERT INTO `edu_user` VALUES ('55', null, null, null, null, '106', '0', '0', '2016-11-16 21:37:24', '1', null, null, '0', '0', null, '106', '3', null, '0', 'student', '7', null, '0', '0', null);
INSERT INTO `edu_user` VALUES ('56', null, null, null, null, '104', '0', '0', '2016-11-17 08:55:28', '1', null, null, '0', '0', null, '104', '3', null, '0', 'student', '7', null, '0', '0', null);
INSERT INTO `edu_user` VALUES ('57', null, null, null, null, '', '0', '0', '2016-11-17 20:55:26', '1', null, null, '0', '0', null, '', '3', null, '0', 'student', '7', null, '0', '0', null);
INSERT INTO `edu_user` VALUES ('58', null, null, null, null, '', '0', '0', '2016-11-17 20:59:19', '1', null, null, '0', '0', null, '', '3', null, '0', 'student', '7', null, '0', '0', null);
INSERT INTO `edu_user` VALUES ('59', null, null, null, null, '', '0', '0', '2016-11-17 21:21:48', '1', null, null, '0', '0', null, '', '3', null, '0', 'student', '7', null, '0', '0', null);
INSERT INTO `edu_user` VALUES ('60', null, null, null, null, '', '0', '0', '2016-11-17 21:22:54', '1', null, null, '0', '0', null, '', '3', null, '0', 'student', '7', null, '0', '0', null);
INSERT INTO `edu_user` VALUES ('61', null, null, null, null, '', '0', '0', '2016-11-18 08:49:21', '1', null, null, '0', '0', null, '', '3', null, '0', 'student', '7', null, '0', '0', null);

-- ----------------------------
-- Table structure for edu_user_login_log
-- ----------------------------
DROP TABLE IF EXISTS `edu_user_login_log`;
CREATE TABLE `edu_user_login_log` (
  `LOG_ID` int(11) NOT NULL AUTO_INCREMENT,
  `LOGIN_TIME` timestamp NULL DEFAULT NULL COMMENT '登录时间',
  `IP` varchar(20) DEFAULT NULL COMMENT '登录IP',
  `USER_ID` int(11) DEFAULT '0' COMMENT '用户ID',
  `OS_NAME` varchar(50) DEFAULT NULL COMMENT '操作系统',
  `USER_AGENT` varchar(50) DEFAULT NULL COMMENT '浏览器',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of edu_user_login_log
-- ----------------------------
INSERT INTO `edu_user_login_log` VALUES ('1', '2016-11-16 11:09:06', '221.221.148.222', '50', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('2', '2016-11-16 11:12:15', '221.221.148.222', '51', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('3', '2016-11-16 11:17:02', '221.221.148.222', '1', 'mac os x', 'safari');
INSERT INTO `edu_user_login_log` VALUES ('4', '2016-11-16 11:19:12', '221.221.148.222', '1', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('5', '2016-11-16 11:34:31', '221.221.148.222', '50', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('6', '2016-11-16 11:40:27', '221.221.148.222', '1', 'mac os x', 'safari');
INSERT INTO `edu_user_login_log` VALUES ('7', '2016-11-16 11:54:55', '61.148.243.159', '50', 'windows', 'firefox');
INSERT INTO `edu_user_login_log` VALUES ('8', '2016-11-16 14:17:22', '221.196.111.155', '52', 'mac os x', 'safari');
INSERT INTO `edu_user_login_log` VALUES ('9', '2016-11-16 17:25:02', '221.221.148.222', '1', 'mac os x', 'safari');
INSERT INTO `edu_user_login_log` VALUES ('10', '2016-11-16 17:26:16', '221.221.148.222', '1', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('11', '2016-11-16 17:29:52', '114.242.250.174', '1', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('12', '2016-11-16 21:33:25', '60.25.35.48', '53', 'windows 7', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('13', '2016-11-16 21:35:30', '60.25.35.48', '54', 'windows 7', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('14', '2016-11-16 21:37:24', '60.25.35.48', '55', 'windows 7', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('15', '2016-11-17 08:55:28', '111.164.203.235', '56', 'mac os x', 'safari');
INSERT INTO `edu_user_login_log` VALUES ('16', '2016-11-17 10:23:30', '222.128.182.51', '1', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('17', '2016-11-17 10:24:02', '222.128.182.51', '50', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('18', '2016-11-17 10:34:00', '222.128.182.51', '1', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('19', '2016-11-17 16:49:35', '221.221.163.35', '1', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('20', '2016-11-17 16:54:52', '221.221.163.35', '1', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('21', '2016-11-17 16:55:27', '221.221.163.35', '50', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('22', '2016-11-17 19:51:10', '114.249.211.32', '1', 'windows', 'internet explorer 7');
INSERT INTO `edu_user_login_log` VALUES ('23', '2016-11-17 20:55:26', '114.249.211.32', '57', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('24', '2016-11-17 20:59:19', '114.249.211.32', '58', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('25', '2016-11-17 21:21:48', '114.249.211.32', '59', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('26', '2016-11-17 21:22:54', '114.249.211.32', '60', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('27', '2016-11-18 08:49:21', '114.249.235.232', '61', 'mac os x', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('28', '2016-11-24 16:48:25', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('29', '2016-11-24 16:50:23', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('30', '2016-11-24 16:52:33', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('31', '2016-11-24 09:14:22', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `edu_user_login_log` VALUES ('32', '2016-12-01 06:38:36', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');

-- ----------------------------
-- Table structure for edu_user_profile
-- ----------------------------
DROP TABLE IF EXISTS `edu_user_profile`;
CREATE TABLE `edu_user_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '属性名称如token,昵称',
  `value` varchar(255) NOT NULL DEFAULT '' COMMENT '第三方key',
  `profiletype` varchar(255) NOT NULL DEFAULT '' COMMENT '第三方类型QQ,SINA,RENREN',
  `userid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `profiledate` datetime DEFAULT NULL COMMENT '添加时间',
  `avatar` varchar(500) DEFAULT NULL COMMENT '第三方用户头像',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `value_type` (`value`(5),`profiletype`(2))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户第三方绑定';

-- ----------------------------
-- Records of edu_user_profile
-- ----------------------------

-- ----------------------------
-- Table structure for edu_video
-- ----------------------------
DROP TABLE IF EXISTS `edu_video`;
CREATE TABLE `edu_video` (
  `VIDEO_ID` int(11) NOT NULL AUTO_INCREMENT,
  `VIDEO_NAME` varchar(255) DEFAULT NULL COMMENT '视频显示名称',
  `FILE_NAME` varchar(255) DEFAULT NULL COMMENT '上传文件名称',
  `FILE_SIZE` double DEFAULT NULL COMMENT '文件大小(B)',
  `FILE_LOCATION` varchar(255) DEFAULT NULL COMMENT '文件存储位置',
  `VIDEO_URL` varchar(255) DEFAULT NULL COMMENT '视频播放URL',
  `ADD_DATE` datetime DEFAULT NULL COMMENT '添加日期',
  `VIDEO_STATUS` int(11) DEFAULT NULL COMMENT '视频状态(1可用2不可用)',
  PRIMARY KEY (`VIDEO_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of edu_video
-- ----------------------------
INSERT INTO `edu_video` VALUES ('24', 'iphone6s.mp4', 'iphone6s-feature-cn-20150909_1920x1080l.mp4', '274665765', 'C:/gukeer/vfsroot/video/iphone6s-feature-cn-20150909_1920x1080l.mp4', 'onlineVideo/iphone6s-feature-cn-20150909_1920x1080l.mp4', '2016-08-12 12:48:06', '1');

-- ----------------------------
-- Table structure for edu_website_course
-- ----------------------------
DROP TABLE IF EXISTS `edu_website_course`;
CREATE TABLE `edu_website_course` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) DEFAULT '' COMMENT '推荐模块名称',
  `LINK` varchar(255) DEFAULT '' COMMENT '点击更多链接',
  `DESCRIPTION` varchar(255) DEFAULT '' COMMENT '说明',
  `COURSENUM` int(11) DEFAULT '0' COMMENT '推荐课程限制数量',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='网站课程推荐分类';

-- ----------------------------
-- Records of edu_website_course
-- ----------------------------
INSERT INTO `edu_website_course` VALUES ('33', '直播列表-推荐', '/', '直播列表页面-推荐', '6');
INSERT INTO `edu_website_course` VALUES ('34', '首页直播推荐', '/front/showLivelist', '', '3');

-- ----------------------------
-- Table structure for edu_website_course_detail
-- ----------------------------
DROP TABLE IF EXISTS `edu_website_course_detail`;
CREATE TABLE `edu_website_course_detail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `RECOMMEND_ID` int(11) DEFAULT '0' COMMENT '推荐分类的id',
  `COURSE_ID` int(11) DEFAULT '0' COMMENT '课程id',
  `ORDER_NUM` int(11) DEFAULT '0' COMMENT '课程显示排序',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='推荐课程表';

-- ----------------------------
-- Records of edu_website_course_detail
-- ----------------------------
INSERT INTO `edu_website_course_detail` VALUES ('73', '33', '27', '0');
INSERT INTO `edu_website_course_detail` VALUES ('74', '33', '29', '0');
INSERT INTO `edu_website_course_detail` VALUES ('75', '33', '31', '0');
INSERT INTO `edu_website_course_detail` VALUES ('78', '34', '27', '0');
INSERT INTO `edu_website_course_detail` VALUES ('91', '34', '35', '0');
INSERT INTO `edu_website_course_detail` VALUES ('80', '34', '31', '0');

-- ----------------------------
-- Table structure for edu_website_ehcache
-- ----------------------------
DROP TABLE IF EXISTS `edu_website_ehcache`;
CREATE TABLE `edu_website_ehcache` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `ehcache_key` varchar(200) NOT NULL DEFAULT '' COMMENT 'ehcache key',
  `ehcache_desc` varchar(200) NOT NULL DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of edu_website_ehcache
-- ----------------------------
INSERT INTO `edu_website_ehcache` VALUES ('38', 'INDEX_TEACHER_RECOMMEND', '前台首页 网校名师 缓存 ');
INSERT INTO `edu_website_ehcache` VALUES ('39', 'ARTICLE_GOOD_RECOMMEND', '文章  好文推荐 缓存 ');
INSERT INTO `edu_website_ehcache` VALUES ('40', 'QUESTIONS_HOT_RECOMMEND', '问答  热门问答推荐 缓存');
INSERT INTO `edu_website_ehcache` VALUES ('41', 'WEB_STATISTICS', '网站统计');
INSERT INTO `edu_website_ehcache` VALUES ('42', 'WEB_STATISTICS_THIRTY', '网站最近30条活跃统计');
INSERT INTO `edu_website_ehcache` VALUES ('43', 'WEB_COUNT', '后台统计');
INSERT INTO `edu_website_ehcache` VALUES ('44', 'HELP_CENTER', '帮助页面左侧菜单1');

-- ----------------------------
-- Table structure for edu_website_images
-- ----------------------------
DROP TABLE IF EXISTS `edu_website_images`;
CREATE TABLE `edu_website_images` (
  `IMAGE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `IMAGE_URL` varchar(200) NOT NULL DEFAULT '' COMMENT '图片地址',
  `LINK_ADDRESS` varchar(255) DEFAULT NULL COMMENT '图链接地址',
  `TITLE` varchar(255) DEFAULT NULL COMMENT '图标题',
  `TYPE_ID` int(11) DEFAULT '0' COMMENT '图片类型',
  `SERIES_NUMBER` int(11) DEFAULT '0' COMMENT '序列号',
  `PREVIEW_URL` varchar(255) DEFAULT NULL COMMENT '略缩图片地址',
  `COLOR` varchar(255) DEFAULT '' COMMENT '背景色',
  `describe` varchar(600) DEFAULT '' COMMENT '图片描述',
  PRIMARY KEY (`IMAGE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=325 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='banner图管理';

-- ----------------------------
-- Records of edu_website_images
-- ----------------------------
INSERT INTO `edu_website_images` VALUES ('274', '/images/upload/image/20161115/1479190730951.png', '/front/showcoulist', '首页banner图片orange', '1', '1', '/images/upload/image/20161115/1479190741482.png', '#D0D0D0', '');
INSERT INTO `edu_website_images` VALUES ('323', '/images/upload/image/20161115/1479194402180.png', '/', '首页banner图片blue', '16', '0', '/images/upload/image/20161115/1479194412377.png', '', '');
INSERT INTO `edu_website_images` VALUES ('324', '/images/upload/image/20161115/1479194456814.png', '/', '首页banner图片green', '17', '0', '/images/upload/image/20161115/1479194463119.png', '', '');

-- ----------------------------
-- Table structure for edu_website_images_type
-- ----------------------------
DROP TABLE IF EXISTS `edu_website_images_type`;
CREATE TABLE `edu_website_images_type` (
  `TYPE_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '类型ID',
  `TYPE_NAME` varchar(50) DEFAULT NULL COMMENT '类型名',
  PRIMARY KEY (`TYPE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='图片类型表';

-- ----------------------------
-- Records of edu_website_images_type
-- ----------------------------
INSERT INTO `edu_website_images_type` VALUES ('1', '首页Banner图片_orange');
INSERT INTO `edu_website_images_type` VALUES ('11', '底部二维码');
INSERT INTO `edu_website_images_type` VALUES ('12', '文章列表');
INSERT INTO `edu_website_images_type` VALUES ('16', '首页Banner图片_blue');
INSERT INTO `edu_website_images_type` VALUES ('17', '首页Banner图片_green');
INSERT INTO `edu_website_images_type` VALUES ('18', '直播首页');
INSERT INTO `edu_website_images_type` VALUES ('19', '直播详情');

-- ----------------------------
-- Table structure for edu_website_navigate
-- ----------------------------
DROP TABLE IF EXISTS `edu_website_navigate`;
CREATE TABLE `edu_website_navigate` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `NAME` varchar(100) NOT NULL DEFAULT '' COMMENT '导航显示名称',
  `URL` varchar(100) NOT NULL DEFAULT '' COMMENT '导航显示位置',
  `NEWPAGE` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否在新页面打开0是1否',
  `TYPE` varchar(50) NOT NULL DEFAULT '' COMMENT '类型：INDEX首页、USER个人中心、FRIENDLINK尾部友链、TAB尾部标签',
  `ORDERNUM` int(11) NOT NULL DEFAULT '0' COMMENT '显示排序',
  `STATUS` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0正常1冻结',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='导航表';

-- ----------------------------
-- Records of edu_website_navigate
-- ----------------------------
INSERT INTO `edu_website_navigate` VALUES ('1', '首页', '/', '1', 'INDEX', '100', '0');
INSERT INTO `edu_website_navigate` VALUES ('5', '名师', '/front/teacherlist', '1', 'INDEX', '96', '0');
INSERT INTO `edu_website_navigate` VALUES ('14', '关于我们', '/front/helpCenter?id=193', '0', 'TAB', '100', '0');
INSERT INTO `edu_website_navigate` VALUES ('17', '产品介绍', '/front/helpCenter?id=200', '0', 'TAB', '98', '1');
INSERT INTO `edu_website_navigate` VALUES ('18', '联系我们', '/front/helpCenter?id=194', '0', 'TAB', '99', '0');
INSERT INTO `edu_website_navigate` VALUES ('31', '谷壳时代', 'http://www.gukeer.cc', '0', 'FRIENDLINK', '0', '0');
INSERT INTO `edu_website_navigate` VALUES ('38', '帮助中心', '/front/helpCenter', '0', 'TAB', '0', '0');
INSERT INTO `edu_website_navigate` VALUES ('40', '直播', '/front/liveIndex', '1', 'INDEX', '98', '0');
INSERT INTO `edu_website_navigate` VALUES ('43', '文章', '/front/articlelist', '1', 'INDEX', '0', '0');
INSERT INTO `edu_website_navigate` VALUES ('44', '问答', '/questions/list', '1', 'INDEX', '0', '0');

-- ----------------------------
-- Table structure for edu_website_profile
-- ----------------------------
DROP TABLE IF EXISTS `edu_website_profile`;
CREATE TABLE `edu_website_profile` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TYPE` varchar(20) NOT NULL DEFAULT '' COMMENT '类型',
  `DESCIPTION` text COMMENT '内容JSON格式',
  `EXPLAIN` varchar(50) DEFAULT '' COMMENT '说明',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of edu_website_profile
-- ----------------------------
INSERT INTO `edu_website_profile` VALUES ('1', 'web', '{\"copyright\":\"©2010-2015 谷壳儿有限公司 版权所有 \",\"keywords\":\"GUKEER,在线教育,网校搭建,网校,网络教育,远程教育,云网校,在线学习,在线考试\",\"phone\":\"010-82825069\",\"author\":\"gukeer(http://www.gukeer.cc)\",\"description\":\"小豆云课堂专业的直播课程平台\",\"company\":\"谷壳在线教育软件\",\"title\":\"中国在线教育平台第一品牌\",\"workTime\":\"9:00-18:00\",\"email\":\"xiejinlong@gukeer.cc\"}', '基本信息的维护');
INSERT INTO `edu_website_profile` VALUES ('2', 'alipay', '{\"alipaypartnerID\":\"\",\"alipaykey\":\"\",\"sellerEmail\":\"\",\"status\":\"0\"}', '支付宝配置');
INSERT INTO `edu_website_profile` VALUES ('3', 'logo', '{\"url\":\"/images/upload/websiteLogo/20150820/1440035056371.png\"}', 'logo');
INSERT INTO `edu_website_profile` VALUES ('4', 'censusCode', '{\"censusCodeString\":\"\"}', '统计代码');
INSERT INTO `edu_website_profile` VALUES ('11', 'yee', '{\"keyValue\":\"\",\"p1_MerId\":\"\"}', '易宝配置');
INSERT INTO `edu_website_profile` VALUES ('5', 'online', '{\"onlineUrl\":\"http://www.gukeer.cc\",\"onlineImageUrl\":\"/images/upload/online/20161116/1479263463207.png\"}', '在线咨询');
INSERT INTO `edu_website_profile` VALUES ('8', 'cc', '{\"ccappID\":\"\",\"ccappKEY\":\"\"}', 'CC视频配置');
INSERT INTO `edu_website_profile` VALUES ('12', 'weixin', '{\"wxPayKey\":\"\",\"mobileAppId\":\"1\",\"wxToken\":\"inxedu\",\"mobileMchId\":\"1\",\"wxAppID\":\"\",\"wxMchId\":\"\",\"wxAppSecret\":\"\",\"mobilePayKey\":\"1\",\"encodingAESKey\":\"GLybO3moaatyWTyeNIFTkhhkP2XsO9ZdYADFVSQh1ao\"}', '微信帐号');
INSERT INTO `edu_website_profile` VALUES ('16', 'weixinLogin', '{\"appid\":\"\",\"scope\":\"snsapi_login\",\"response_type\":\"code\",\"redirect_uri\":\"http://demo1.gukeer.cc/app/weixinlogin\",\"secret\":\"\",\"href\":\"\"}', '微信第三方登录配置');
INSERT INTO `edu_website_profile` VALUES ('15', 'serviceSwitch', '{\"exam\":\"OFF\",\"cardServer\":\"OFF\",\"alipay\":\"ON\",\"weixinpay\":\"ON\",\"coupon\":\"OFF\",\"verifyWeiXin\":\"OFF\",\"verifyQQ\":\"OFF\",\"yibaopay\":\"ON\",\"verifySINA\":\"OFF\",\"live\":\"ON\"}', '购买服务开关');
INSERT INTO `edu_website_profile` VALUES ('17', 'sinaLogin', '{\"client_SERCRET\":\"\",\"baseURL\":\"https://api.weibo.com/2/\",\"authorizeURL\":\"https://api.weibo.com/oauth2/authorize\",\"accessTokenURL\":\"https://api.weibo.com/oauth2/access_token\",\"redirect_URI\":\"http://demo1.gukeer.cc/app/sinalogin\",\"rmURL\":\"https://rm.api.weibo.com/2/\",\"client_ID\":\"\"}', '新浪微博第三方登录配置');
INSERT INTO `edu_website_profile` VALUES ('18', 'qqLogin', '{\"app_KEY\":\"\",\"authorizeURL\":\"https://graph.qq.com/oauth2.0/authorize\",\"scope\":\"get_user_info\",\"accessTokenURL\":\"https://graph.qq.com/oauth2.0/token\",\"getOpenIDURL\":\"https://graph.qq.com/oauth2.0/me\",\"redirect_URI\":\"http://demo1.gukeer.cc/app/loginReturn\",\"getUserInfoURL\":\"https://graph.qq.com/user/get_user_info\",\"app_ID\":\"\"}', 'qq第三方登录配置');
INSERT INTO `edu_website_profile` VALUES ('19', 'emailConfigure', '{\"SMTP\":\"smtp.exmail.qq.com\",\"password\":\"\",\"username\":\"\"}', '邮箱配置');
INSERT INTO `edu_website_profile` VALUES ('9', 'WebSwitch', '{\"imPath\":\"\",\"limitLogin\":\"OFF\"}', '网站开关配置');
INSERT INTO `edu_website_profile` VALUES ('20', 'inxeduVideo', '{\"SecretKey\":\"\",\"UserId\":\"\",\"AccessKey\":\"\"}', 'inxedu云视频');

-- ----------------------------
-- Table structure for sys_function
-- ----------------------------
DROP TABLE IF EXISTS `sys_function`;
CREATE TABLE `sys_function` (
  `FUNCTION_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '权限ID',
  `PARENT_ID` int(11) DEFAULT '0' COMMENT '权限父ID',
  `FUNCTION_NAME` varchar(100) DEFAULT NULL COMMENT '权限名',
  `FUNCTION_URL` varchar(255) DEFAULT NULL COMMENT '权限URL',
  `FUNCTION_TYPE` tinyint(1) DEFAULT '0' COMMENT '权限类型 1菜单 2功能',
  `CREATE_TIME` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `SORT` int(11) DEFAULT '0' COMMENT '排序',
  `url_type` int(3) DEFAULT '1' COMMENT '路径类型（1网校 2 社区 3 考试）',
  `image_url` varchar(300) DEFAULT NULL COMMENT '图标路径',
  PRIMARY KEY (`FUNCTION_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=245 DEFAULT CHARSET=utf8 COMMENT='权限表';

-- ----------------------------
-- Records of sys_function
-- ----------------------------
INSERT INTO `sys_function` VALUES ('18', '45', '权限树', '/admin/sysfunctioin/showfunctionztree', '1', '2015-03-17 21:46:16', '0', '1', null);
INSERT INTO `sys_function` VALUES ('19', '45', '角色管理', '/admin/sysrole/showroleList', '1', '2015-03-17 21:46:17', '0', '1', null);
INSERT INTO `sys_function` VALUES ('20', '18', '修改权限', '/admin/sysfunctioin/updatefunction', '2', '2015-03-17 21:47:21', '0', '1', null);
INSERT INTO `sys_function` VALUES ('21', '18', '添加权限', '/admin/sysfunctioin/addfunction', '2', '2015-03-17 21:47:23', '0', '1', null);
INSERT INTO `sys_function` VALUES ('22', '18', '拖拽权限', '/admin/sysfunctioin/updateparentid', '2', '2015-03-17 21:48:44', '0', '1', null);
INSERT INTO `sys_function` VALUES ('23', '18', '删除权限', '/admin/sysfunctioin/deletefunction', '2', '2015-03-17 21:50:30', '0', '1', null);
INSERT INTO `sys_function` VALUES ('24', '201', '用户管理', '', '1', '2015-03-17 21:50:30', '9', '1', null);
INSERT INTO `sys_function` VALUES ('25', '24', '用户列表', '/admin/sysuser/userlist', '1', '2015-03-17 21:50:30', '0', '1', null);
INSERT INTO `sys_function` VALUES ('26', '19', '保存角色权限', '/admin/sysrole/saveroelfunction/', '2', '2015-03-19 18:56:09', '0', '1', null);
INSERT INTO `sys_function` VALUES ('30', '201', '媒体广告图片', '', '1', '2015-03-23 01:40:44', '0', '1', null);
INSERT INTO `sys_function` VALUES ('31', '24', '添加用户', '/admin/sysuser/createuser', '2', '2015-03-23 01:46:17', '0', '1', null);
INSERT INTO `sys_function` VALUES ('32', '30', '广告图', '/admin/website/imagesPage', '1', '2015-03-23 01:41:47', '0', '1', null);
INSERT INTO `sys_function` VALUES ('33', '24', '修改用户密码', '/admin/sysuser/updatepwd/', '2', '2015-03-23 01:48:55', '0', '1', null);
INSERT INTO `sys_function` VALUES ('34', '24', '修改用户', '/admin/sysuser/updateuser', '2', '2015-03-23 01:48:55', '0', '1', null);
INSERT INTO `sys_function` VALUES ('35', '24', '禁用或启用用户', '/admin/sysuser/disableOrstart/', '2', '2015-03-23 01:50:14', '0', '1', null);
INSERT INTO `sys_function` VALUES ('36', '209', '专业管理', '', '1', '2015-03-23 17:58:20', '8', '1', '');
INSERT INTO `sys_function` VALUES ('37', '36', '专业管理', '/admin/subj/toSubjectList', '1', '2015-03-23 17:58:34', '0', '1', null);
INSERT INTO `sys_function` VALUES ('39', '36', '推荐直播', '/admin/detail/list', '1', '2015-03-23 18:03:00', '0', '1', '');
INSERT INTO `sys_function` VALUES ('40', '36', '推荐直播分类', '/admin/website/websiteCoursePage', '1', '2015-03-23 18:03:34', '0', '1', '');
INSERT INTO `sys_function` VALUES ('42', '202', '教师管理', '', '1', '2015-03-23 18:04:17', '0', '1', null);
INSERT INTO `sys_function` VALUES ('43', '42', '教师列表', '/admin/teacher/list', '1', '2015-03-23 18:04:37', '0', '1', null);
INSERT INTO `sys_function` VALUES ('44', '42', '添加讲师', '/admin/teacher/toadd', '1', '2015-03-23 18:05:18', '0', '1', null);
INSERT INTO `sys_function` VALUES ('45', '201', '系统管理', '', '1', '2015-03-23 19:47:53', '10', '1', null);
INSERT INTO `sys_function` VALUES ('49', '82', '基本配置', '/admin/websiteProfile/find/web', '1', '2015-03-24 00:08:44', '0', '1', null);
INSERT INTO `sys_function` VALUES ('51', '82', '导航管理', '/admin/website/navigates', '1', '2015-03-24 00:36:45', '0', '1', null);
INSERT INTO `sys_function` VALUES ('61', '206', '学员管理', '', '1', '2015-03-26 01:31:10', '5', '1', null);
INSERT INTO `sys_function` VALUES ('62', '61', '学员列表', '/admin/user/getuserList', '1', '2015-03-26 01:31:28', '0', '1', null);
INSERT INTO `sys_function` VALUES ('63', '206', '订单管理', '', '1', '2015-03-27 01:43:58', '6', '1', null);
INSERT INTO `sys_function` VALUES ('64', '63', '订单列表', '/admin/order/showorderlist', '1', '2015-03-27 01:44:14', '0', '1', null);
INSERT INTO `sys_function` VALUES ('65', '64', '取消或恢复订单', '/admin/order/cancelOrRegain', '2', '2015-03-27 02:57:28', '0', '1', null);
INSERT INTO `sys_function` VALUES ('66', '64', '审核订单', '/admin/order/auditing/', '2', '2015-03-27 02:58:02', '0', '1', null);
INSERT INTO `sys_function` VALUES ('68', '82', '在线咨询', '/admin/websiteProfile/online', '1', '2015-03-27 21:33:56', '0', '1', null);
INSERT INTO `sys_function` VALUES ('69', '37', '创建专业', '/admin/subj/createSubject', '2', '2015-03-29 19:47:32', '0', '1', null);
INSERT INTO `sys_function` VALUES ('70', '37', '修改专业父ID', '/admin/subj/updateparentid/', '2', '2015-03-29 19:47:32', '0', '1', null);
INSERT INTO `sys_function` VALUES ('71', '37', '修改专业名', '/admin/subj/updatesubjectName', '2', '2015-03-29 19:47:34', '0', '1', null);
INSERT INTO `sys_function` VALUES ('72', '37', '删除专业', '/admin/subj/deleteSubject/', '2', '2015-03-29 19:49:09', '0', '1', null);
INSERT INTO `sys_function` VALUES ('79', '30', '图片类型', '/admin/imagetype/getlist', '1', '2015-04-01 02:25:06', '0', '1', null);
INSERT INTO `sys_function` VALUES ('80', '62', '修改学员密码', '/admin/user/updateUserPwd', '2', '2015-04-02 02:00:46', '0', '1', null);
INSERT INTO `sys_function` VALUES ('81', '62', '禁用或启用学员', '/admin/user/updateuserstate', '2', '2015-04-02 02:00:47', '0', '1', null);
INSERT INTO `sys_function` VALUES ('82', '201', '网站信息', '', '1', '2015-04-09 21:39:37', '0', '1', null);
INSERT INTO `sys_function` VALUES ('83', '43', '修改讲师', '/admin/teacher/update', '2', '2015-05-15 02:33:19', '0', '1', null);
INSERT INTO `sys_function` VALUES ('84', '43', '删除讲师', '/admin/teacher/delete/', '2', '2015-05-15 02:34:07', '0', '1', null);
INSERT INTO `sys_function` VALUES ('95', '201', '系统消息', '', '1', '2015-08-29 18:33:06', '0', '1', null);
INSERT INTO `sys_function` VALUES ('96', '95', '全站系统消息', '/admin/user/letter/toSendSystemMessages', '1', '2015-08-29 18:33:20', '0', '1', null);
INSERT INTO `sys_function` VALUES ('97', '209', '评论管理', '', '1', '2015-08-31 09:11:44', '0', '1', null);
INSERT INTO `sys_function` VALUES ('98', '97', '评论列表', '/admin/comment/query', '1', '2015-08-31 09:12:18', '0', '1', null);
INSERT INTO `sys_function` VALUES ('99', '95', '批量发送', '/admin/user/letter/toSendSystemMessagesBatch', '1', '2015-08-31 18:18:18', '0', '1', null);
INSERT INTO `sys_function` VALUES ('100', '82', '前台主题色', '/admin/theme/toupdate', '1', '2015-09-22 14:25:32', '0', '1', null);
INSERT INTO `sys_function` VALUES ('107', '61', '批量开通学员', '/admin/user/toBatchOpen', '1', '2015-12-01 18:18:44', '0', '1', null);
INSERT INTO `sys_function` VALUES ('108', '201', '邮件管理', '', '1', '2016-01-14 16:35:19', '0', '1', null);
INSERT INTO `sys_function` VALUES ('109', '108', '发送邮件', '/admin/email/toEmailMsg', '1', '2016-01-14 16:35:43', '0', '1', null);
INSERT INTO `sys_function` VALUES ('110', '108', '邮件管理', '/admin/email/sendEmaillist', '1', '2016-01-14 16:39:24', '0', '1', null);
INSERT INTO `sys_function` VALUES ('111', '207', '帮助中心', '', '1', '2016-01-15 14:37:38', '0', '1', null);
INSERT INTO `sys_function` VALUES ('112', '111', '新建帮助页面', '/admin/helpMenu/doadd', '1', '2016-01-15 14:37:55', '0', '1', null);
INSERT INTO `sys_function` VALUES ('113', '111', '帮助菜单', '/admin/helpMenu/list', '1', '2016-01-15 14:38:58', '0', '1', null);
INSERT INTO `sys_function` VALUES ('114', '201', '短信管理', '', '1', '2016-01-16 14:35:16', '0', '1', null);
INSERT INTO `sys_function` VALUES ('115', '114', '发送短信', '/admin/mobile/toMsg', '1', '2016-01-16 14:36:39', '0', '1', null);
INSERT INTO `sys_function` VALUES ('116', '114', '短信管理', '/admin/mobile/sendMsglist', '1', '2016-01-16 14:38:52', '0', '1', null);
INSERT INTO `sys_function` VALUES ('117', '201', '缓存管理', '', '1', '2016-01-18 16:07:36', '0', '1', null);
INSERT INTO `sys_function` VALUES ('118', '117', '缓存管理', '/admin/ehcache/queryWebsiteEhcacheList', '1', '2016-01-18 16:08:33', '0', '1', null);
INSERT INTO `sys_function` VALUES ('126', '210', '统计', '', '1', '2016-01-22 16:10:59', '0', '1', null);
INSERT INTO `sys_function` VALUES ('129', '126', '学员登录数统计', '/admin/statisticsPage/login', '1', '2016-01-22 16:11:42', '0', '1', null);
INSERT INTO `sys_function` VALUES ('130', '126', '学员注册数统计', '/admin/statisticsPage/registered', '1', '2016-01-22 16:11:44', '0', '1', null);
INSERT INTO `sys_function` VALUES ('131', '126', '学员订单数统计', '/admin/statisticsPage/order', '1', '2016-01-22 16:11:45', '0', '1', null);
INSERT INTO `sys_function` VALUES ('132', '126', '每日营收额统计', '/admin/statisticsPage/income', '1', '2016-01-22 16:11:46', '0', '1', null);
INSERT INTO `sys_function` VALUES ('133', '126', '视频观看数统计', '/admin/statisticsPage/videoViewingNum', '1', '2016-01-22 16:13:26', '0', '1', null);
INSERT INTO `sys_function` VALUES ('134', '126', '生成统计', '/admin/jumpGenerationStatisticsPage', '1', '2016-01-22 16:13:27', '0', '1', null);
INSERT INTO `sys_function` VALUES ('135', '126', '每日学员数统计', '/admin/statisticsPage/dailyUserNumber', '1', '2016-01-25 11:42:09', '0', '1', null);
INSERT INTO `sys_function` VALUES ('136', '126', '每日直播数统计', '/admin/statisticsPage/dailyCourseNumber', '1', '2016-01-25 11:42:10', '0', '1', '');
INSERT INTO `sys_function` VALUES ('137', '201', '个人管理', '', '1', '2016-02-27 16:13:35', '2', '1', null);
INSERT INTO `sys_function` VALUES ('138', '137', '修改密码', '/admin/sysuser/user/toupdatepwd', '1', '2016-02-27 16:13:47', '0', '1', null);
INSERT INTO `sys_function` VALUES ('139', '95', '系统消息列表', '/admin/letter/systemmsglist', '1', '2016-02-27 18:19:01', '0', '1', null);
INSERT INTO `sys_function` VALUES ('150', '201', '网站数据整理', '', '1', '2016-03-22 09:17:29', '0', '1', null);
INSERT INTO `sys_function` VALUES ('151', '150', '数据清理', '/admin/dataclean/list', '1', '2016-03-22 09:18:20', '0', '1', null);
INSERT INTO `sys_function` VALUES ('152', '150', '清理', '/admin/dataclean/dosql', '2', '2016-03-22 10:23:20', '0', '1', null);
INSERT INTO `sys_function` VALUES ('153', '150', '批量清理', '/admin/dataclean/multiDosql', '2', '2016-03-22 15:28:12', '0', '1', null);
INSERT INTO `sys_function` VALUES ('154', '209', '直播管理', '', '1', '2016-03-28 11:13:21', '0', '1', null);
INSERT INTO `sys_function` VALUES ('155', '154', '添加直播', '/admin/cou/toAddCourse?sellType=LIVE', '1', '2016-03-28 11:13:37', '0', '1', null);
INSERT INTO `sys_function` VALUES ('156', '154', '直播列表', '/admin/cou/list?queryCourse.sellType=LIVE', '1', '2016-03-28 11:14:39', '0', '1', null);
INSERT INTO `sys_function` VALUES ('201', '0', '系统', '', '1', '2016-05-09 11:22:30', '10', '1', null);
INSERT INTO `sys_function` VALUES ('202', '0', '讲师', '', '1', '2016-05-09 11:25:35', '0', '1', '');
INSERT INTO `sys_function` VALUES ('206', '0', '学员', '', '1', '2016-05-09 11:30:36', '9', '1', null);
INSERT INTO `sys_function` VALUES ('207', '0', '资讯', '', '1', '2016-05-09 11:30:46', '0', '1', '');
INSERT INTO `sys_function` VALUES ('209', '0', '直播', '', '1', '2016-05-09 11:31:42', '9', '1', '');
INSERT INTO `sys_function` VALUES ('210', '0', '统计', '', '1', '2016-05-09 11:32:17', '0', '1', null);
INSERT INTO `sys_function` VALUES ('214', '0', '课程', '', '1', '2016-05-11 00:00:00', '8', '1', null);
INSERT INTO `sys_function` VALUES ('215', '219', '专业管理', '/admin/subj/toSubjectList', '1', '2016-05-05 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('216', '219', '课程管理', '/admin/cou/list?queryCourse.sellType=PACKAGE', '1', '2016-05-12 00:00:00', '0', '1', '');
INSERT INTO `sys_function` VALUES ('217', '219', '推荐课程', '/admin/detail/list', '1', '2016-05-12 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('218', '1', '推荐', '/admin/website/websiteCoursePage', '1', '2016-05-13 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('219', '214', '课程管理', '', '1', '2016-05-11 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('220', '0', '问答', '', '1', '2016-05-04 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('221', '220', '问答', '', '1', '2016-05-06 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('222', '221', '问答标签', '/admin/questions/toQuestionsTagList', '1', '2016-05-19 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('223', '221', '问答列表', '/admin/questions/list', '1', '2016-05-19 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('224', '221', '问答回复列表', '/admin/questionscomment/list', '1', '2016-05-26 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('225', '207', '文章', '', '1', '2016-05-12 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('226', '225', '添加文章', '/admin/article/initcreate', '1', '2016-05-05 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('227', '225', '文章列表', '/admin/article/showlist', '1', '2016-05-05 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('228', '226', '保存文章', '/admin/article/addarticle/1', '2', '2016-05-26 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('229', '226', '保存并发布文章', '/admin/article/addarticle/2', '2', '2016-05-03 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('230', '227', '删除资讯', '/admin/article/addarticle/2', '2', '2016-05-04 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('231', '227', '发布文章', '/admin/article/publishOrDelete/1', '2', '2016-05-05 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('232', '227', '修改并发布文章', '/admin/article/updatearticle/2', '2', '2016-05-11 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('233', '227', '修改文章', '/admin/article/updatearticle/1', '2', '2016-05-18 00:00:00', '0', '1', null);
INSERT INTO `sys_function` VALUES ('241', '239', '修改', '/admin/teacher/ModifyAccount', '2', '2016-05-27 09:32:11', '0', '1', '');
INSERT INTO `sys_function` VALUES ('242', '239', '删除', '/admin/teacher/DeleteAccount', '2', '2016-05-27 09:32:52', '0', '1', '');
INSERT INTO `sys_function` VALUES ('244', '219', '添加课程', '/admin/cou/toAddCourse?sellType=PACKAGE', '1', '2016-11-11 17:32:19', '0', '1', '');

-- ----------------------------
-- Table structure for sys_login_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_login_log`;
CREATE TABLE `sys_login_log` (
  `LOG_ID` int(11) NOT NULL AUTO_INCREMENT,
  `LOGIN_TIME` timestamp NULL DEFAULT NULL COMMENT '登录时间',
  `IP` varchar(20) DEFAULT NULL COMMENT '登录IP',
  `USER_ID` int(11) DEFAULT '0' COMMENT '用户ID',
  `OS_NAME` varchar(50) DEFAULT NULL COMMENT '操作系统',
  `USER_AGENT` varchar(50) DEFAULT NULL COMMENT '浏览器',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=707 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_login_log
-- ----------------------------
INSERT INTO `sys_login_log` VALUES ('1', '2016-02-19 16:24:55', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('2', '2016-02-19 16:28:19', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('3', '2016-02-19 16:38:02', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('4', '2016-02-19 16:45:56', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('5', '2016-02-19 17:08:53', '192.168.1.39', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('6', '2016-02-19 17:46:40', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('7', '2016-02-19 18:05:42', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('8', '2016-02-19 18:13:35', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('9', '2016-02-19 18:13:46', '192.168.1.39', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('10', '2016-02-19 18:17:20', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('11', '2016-02-19 18:32:49', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('12', '2016-02-19 18:34:35', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('13', '2016-02-19 18:35:52', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('14', '2016-02-19 18:42:25', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('15', '2016-02-19 18:46:40', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('16', '2016-02-19 18:47:07', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('17', '2016-02-19 18:50:42', '192.168.1.39', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('18', '2016-02-22 09:01:35', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('19', '2016-02-22 09:09:50', '192.168.1.30', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('20', '2016-02-22 09:34:57', '192.168.1.39', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('21', '2016-02-22 10:06:36', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('22', '2016-02-22 10:19:02', '192.168.1.39', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('23', '2016-02-22 10:32:06', '192.168.1.39', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('24', '2016-02-22 10:42:42', '192.168.1.39', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('25', '2016-02-22 10:56:04', '192.168.1.39', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('26', '2016-02-22 11:07:27', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('27', '2016-02-22 11:12:23', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('28', '2016-02-22 11:16:23', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('29', '2016-02-22 13:50:18', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('30', '2016-02-22 14:16:23', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('31', '2016-02-22 14:32:12', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('32', '2016-02-22 14:37:30', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('33', '2016-02-22 14:40:25', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('34', '2016-02-22 14:45:01', '192.168.1.50', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('35', '2016-02-22 14:58:28', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('36', '2016-02-23 09:33:04', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('37', '2016-02-23 16:34:08', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('38', '2016-02-23 17:23:57', '192.168.1.78', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('39', '2016-02-23 17:30:42', '192.168.1.78', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('40', '2016-02-24 10:22:45', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('41', '2016-02-24 10:43:11', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('42', '2016-02-24 10:48:45', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('43', '2016-02-24 15:22:10', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('44', '2016-02-26 11:08:35', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('45', '2016-02-26 14:13:33', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('46', '2016-02-26 15:41:44', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('47', '2016-02-26 16:43:10', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('48', '2016-02-26 16:56:47', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('49', '2016-02-26 17:38:09', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('50', '2016-02-26 18:01:29', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('51', '2016-02-26 18:04:52', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('52', '2016-02-26 18:06:52', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('53', '2016-02-26 18:08:45', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('54', '2016-02-26 18:29:28', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('55', '2016-02-27 09:34:04', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('56', '2016-02-27 09:39:00', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('57', '2016-02-27 09:39:47', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('58', '2016-02-27 09:45:14', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('59', '2016-02-27 10:02:04', '192.168.1.30', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('60', '2016-02-27 10:07:55', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('61', '2016-02-27 14:08:12', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('62', '2016-02-27 16:05:39', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('63', '2016-02-27 16:16:11', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('64', '2016-02-27 16:39:35', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('65', '2016-02-27 16:41:29', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('66', '2016-02-27 16:43:38', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('67', '2016-02-27 16:49:59', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('68', '2016-02-27 16:52:06', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('69', '2016-02-27 17:32:17', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('70', '2016-02-27 17:34:09', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('71', '2016-02-27 17:35:02', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('72', '2016-02-27 17:38:45', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('73', '2016-02-27 18:18:18', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('74', '2016-02-27 18:19:38', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('75', '2016-02-29 13:35:52', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('76', '2016-02-29 15:26:13', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('77', '2016-02-29 15:45:56', '192.168.1.30', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('78', '2016-02-29 17:25:04', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('79', '2016-03-01 09:11:28', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('80', '2016-03-01 09:48:48', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('81', '2016-03-01 10:16:30', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('82', '2016-03-01 10:21:13', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('83', '2016-03-01 10:23:43', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('84', '2016-03-01 10:28:49', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('85', '2016-03-01 13:37:59', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('86', '2016-03-01 14:48:29', '192.168.1.55', '1', 'windows', 'mozilla');
INSERT INTO `sys_login_log` VALUES ('87', '2016-03-01 15:51:45', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('88', '2016-03-01 16:20:50', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('89', '2016-03-01 16:26:06', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('90', '2016-03-01 17:30:59', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('91', '2016-03-01 17:49:57', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('92', '2016-03-02 09:09:10', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('93', '2016-03-02 09:19:41', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('94', '2016-03-02 09:27:45', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('95', '2016-03-02 09:30:27', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('96', '2016-03-02 10:00:40', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('97', '2016-03-02 10:06:01', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('98', '2016-03-02 10:59:43', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('99', '2016-03-02 11:03:06', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('100', '2016-03-02 11:10:41', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('101', '2016-03-02 11:17:09', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('102', '2016-03-02 11:19:52', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('103', '2016-03-02 11:25:18', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('104', '2016-03-02 11:43:27', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('105', '2016-03-02 11:49:43', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('106', '2016-03-02 11:52:14', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('107', '2016-03-02 11:54:44', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('108', '2016-03-02 12:46:26', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('109', '2016-03-02 12:56:02', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('110', '2016-03-02 14:21:33', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('111', '2016-03-02 14:32:37', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('112', '2016-03-02 17:31:37', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('113', '2016-03-03 10:10:24', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('114', '2016-03-03 10:57:13', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('115', '2016-03-03 11:03:16', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('116', '2016-03-03 11:11:07', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('117', '2016-03-03 11:34:42', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('118', '2016-03-03 11:44:18', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('119', '2016-03-03 11:51:44', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('120', '2016-03-03 13:01:20', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('121', '2016-03-03 13:07:00', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('122', '2016-03-03 13:10:05', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('123', '2016-03-03 13:50:38', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('124', '2016-03-03 14:00:56', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('125', '2016-03-03 14:14:05', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('126', '2016-03-03 14:20:39', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('127', '2016-03-03 15:01:58', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('128', '2016-03-03 18:46:23', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('129', '2016-03-04 09:27:08', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('130', '2016-03-04 09:34:15', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('131', '2016-03-04 09:44:41', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('132', '2016-03-04 09:51:13', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('133', '2016-03-04 09:59:47', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('134', '2016-03-04 11:58:00', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('135', '2016-03-04 12:51:44', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('136', '2016-03-04 14:32:30', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('137', '2016-03-07 11:35:31', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('138', '2016-03-07 14:28:54', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('139', '2016-03-07 14:49:55', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('140', '2016-03-07 15:03:51', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('141', '2016-03-07 15:15:02', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('142', '2016-03-07 16:16:12', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('143', '2016-03-07 16:21:35', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('144', '2016-03-08 14:08:26', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('145', '2016-03-09 09:26:56', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('146', '2016-03-09 09:49:47', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('147', '2016-03-09 10:19:12', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('148', '2016-03-09 13:58:24', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('149', '2016-03-09 16:52:53', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('150', '2016-03-09 18:34:16', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('151', '2016-03-09 18:40:24', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('152', '2016-03-09 18:44:42', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('153', '2016-03-10 14:30:32', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('154', '2016-03-10 14:35:06', '192.168.1.56', '1', 'windows 7', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('155', '2016-03-10 15:52:34', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('156', '2016-03-10 20:31:56', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('157', '2016-03-11 09:02:48', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('158', '2016-03-11 09:06:09', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('159', '2016-03-11 10:27:24', '192.168.1.30', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('160', '2016-03-12 11:27:32', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('161', '2016-03-12 11:47:24', '192.168.1.55', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('162', '2016-03-12 13:45:29', '192.168.1.55', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('163', '2016-03-12 15:45:24', '192.168.1.52', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('164', '2016-03-14 18:36:29', '192.168.1.107', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('165', '2016-03-14 18:49:37', '192.168.1.107', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('166', '2016-03-14 19:07:26', '192.168.1.107', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('167', '2016-03-15 08:52:36', '192.168.1.107', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('168', '2016-03-15 10:17:11', '192.168.130.103', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('169', '2016-03-15 10:28:15', '192.168.130.103', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('170', '2016-03-15 10:38:38', '192.168.130.103', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('171', '2016-03-15 10:44:43', '192.168.130.103', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('172', '2016-03-15 10:54:19', '192.168.130.103', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('173', '2016-03-15 11:18:48', '192.168.130.103', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('174', '2016-03-15 11:44:09', '192.168.130.103', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('175', '2016-03-15 11:48:20', '192.168.130.103', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('176', '2016-03-15 11:57:28', '192.168.130.103', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('177', '2016-03-15 13:37:06', '192.168.130.103', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('178', '2016-03-15 13:47:00', '192.168.130.103', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('179', '2016-03-16 09:49:15', '192.168.130.103', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('180', '2016-03-16 11:33:20', '192.168.130.103', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('181', '2016-03-16 11:37:31', '192.168.130.103', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('182', '2016-03-16 16:27:50', '192.168.1.111', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('183', '2016-03-16 17:46:42', '192.168.1.59', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('184', '2016-03-16 18:20:58', '192.168.1.59', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('185', '2016-03-17 09:05:56', '192.168.1.59', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('186', '2016-03-17 09:36:26', '192.168.1.33', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('187', '2016-03-17 10:13:08', '192.168.1.33', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('188', '2016-03-17 10:23:35', '192.168.1.33', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('189', '2016-03-17 10:26:16', '192.168.1.33', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('190', '2016-03-17 11:03:30', '192.168.1.113', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('191', '2016-03-17 15:49:47', '192.168.1.113', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('192', '2016-03-17 16:15:59', '192.168.1.113', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('193', '2016-03-18 16:05:13', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('194', '2016-03-21 09:26:18', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('195', '2016-03-21 11:15:50', '192.168.1.116', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('196', '2016-03-21 11:33:37', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('197', '2016-03-21 16:48:44', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('198', '2016-03-21 17:08:32', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('199', '2016-03-21 17:28:08', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('200', '2016-03-21 17:30:33', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('201', '2016-03-21 17:32:26', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('202', '2016-03-21 17:57:50', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('203', '2016-03-21 18:59:29', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('204', '2016-03-22 08:58:17', '192.168.1.116', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('205', '2016-03-22 09:14:15', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('206', '2016-03-22 09:20:08', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('207', '2016-03-22 09:38:05', '192.168.1.116', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('208', '2016-03-22 09:44:29', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('209', '2016-03-22 10:01:09', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('210', '2016-03-22 10:15:11', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('211', '2016-03-22 10:24:48', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('212', '2016-03-22 10:25:38', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('213', '2016-03-22 10:34:17', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('214', '2016-03-22 11:04:29', '192.168.1.116', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('215', '2016-03-22 15:27:59', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('216', '2016-03-22 15:29:04', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('217', '2016-03-22 15:35:54', '192.168.1.116', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('218', '2016-03-22 16:03:12', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('219', '2016-03-22 16:22:05', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('220', '2016-03-22 16:52:47', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('221', '2016-03-23 09:27:15', '192.168.1.116', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('222', '2016-03-23 09:50:52', '192.168.1.116', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('223', '2016-03-23 09:54:33', '192.168.1.116', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('224', '2016-03-23 10:34:48', '192.168.1.116', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('225', '2016-03-23 11:58:43', '192.168.1.116', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('226', '2016-03-23 16:08:53', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('227', '2016-03-23 16:31:31', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('228', '2016-03-24 09:11:34', '192.168.1.116', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('229', '2016-03-24 09:49:49', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('230', '2016-03-24 10:00:11', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('231', '2016-03-24 14:14:59', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('232', '2016-03-25 13:47:15', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('233', '2016-03-25 14:12:21', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('234', '2016-03-25 14:53:56', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('235', '2016-03-25 15:03:48', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('236', '2016-03-25 15:16:36', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('237', '2016-03-25 15:20:36', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('238', '2016-03-25 15:44:29', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('239', '2016-03-25 15:50:14', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('240', '2016-03-26 09:20:02', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('241', '2016-03-26 10:06:39', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('242', '2016-03-26 11:00:51', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('243', '2016-03-26 11:10:25', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('244', '2016-03-26 13:39:23', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('245', '2016-03-26 14:17:53', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('246', '2016-03-26 14:35:50', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('247', '2016-03-26 14:43:24', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('248', '2016-03-26 14:59:03', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('249', '2016-03-26 15:05:50', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('250', '2016-03-26 16:15:20', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('251', '2016-03-26 17:59:13', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('252', '2016-03-28 09:43:23', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('253', '2016-03-28 10:27:42', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('254', '2016-03-28 10:38:22', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('255', '2016-03-28 10:40:54', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('256', '2016-03-28 10:55:01', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('257', '2016-03-28 11:11:36', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('258', '2016-03-28 11:27:21', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('259', '2016-03-28 11:34:29', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('260', '2016-03-28 11:34:43', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('261', '2016-03-28 11:54:07', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('262', '2016-03-28 11:56:20', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('263', '2016-03-28 14:54:39', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('264', '2016-03-29 13:43:16', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('265', '2016-03-29 13:59:03', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('266', '2016-03-29 14:24:20', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('267', '2016-03-29 14:54:38', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('268', '2016-03-29 15:42:58', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('269', '2016-03-29 15:48:17', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('270', '2016-03-29 15:57:39', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('271', '2016-03-29 16:13:09', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('272', '2016-03-29 16:17:24', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('273', '2016-03-29 16:19:36', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('274', '2016-03-29 16:29:17', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('275', '2016-03-29 16:33:51', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('276', '2016-03-30 09:26:07', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('277', '2016-03-30 13:35:59', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('278', '2016-03-30 13:42:22', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('279', '2016-03-30 14:07:16', '192.168.1.114', '3', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('280', '2016-03-30 14:15:37', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('281', '2016-03-30 14:15:57', '192.168.1.114', '3', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('282', '2016-03-30 14:18:40', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('283', '2016-03-30 14:21:00', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('284', '2016-03-30 14:22:07', '192.168.1.114', '3', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('285', '2016-03-30 14:24:45', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('286', '2016-03-31 14:29:46', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('287', '2016-03-31 15:03:06', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('288', '2016-03-31 15:10:40', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('289', '2016-04-01 10:10:56', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('290', '2016-04-01 14:05:36', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('291', '2016-04-05 11:14:44', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('292', '2016-04-05 16:02:26', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('293', '2016-04-05 18:46:33', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('294', '2016-04-06 09:09:16', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('295', '2016-04-06 10:14:02', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('296', '2016-04-06 13:56:59', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('297', '2016-04-06 15:23:58', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('298', '2016-04-06 15:32:34', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('299', '2016-04-06 15:41:09', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('300', '2016-04-06 15:51:14', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('301', '2016-04-06 18:38:24', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('302', '2016-04-07 09:03:51', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('303', '2016-04-07 13:49:45', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('304', '2016-04-07 17:09:29', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('305', '2016-04-07 17:13:53', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('306', '2016-04-07 17:31:09', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('307', '2016-04-07 17:33:00', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('308', '2016-04-08 13:49:33', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('309', '2016-04-08 16:32:04', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('310', '2016-04-08 18:28:23', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('311', '2016-04-09 09:33:20', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('312', '2016-04-09 11:23:21', '192.168.1.114', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('313', '2016-04-09 15:19:51', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('314', '2016-04-09 15:22:30', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('315', '2016-04-09 15:34:28', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('316', '2016-04-09 15:36:23', '192.168.1.114', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('317', '2016-04-09 16:14:54', '192.168.1.114', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('318', '2016-04-09 17:40:20', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('319', '2016-04-11 17:59:09', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('320', '2016-04-12 09:28:02', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('321', '2016-04-12 09:50:50', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('322', '2016-04-12 10:28:26', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('323', '2016-04-12 10:31:26', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('324', '2016-04-12 10:56:06', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('325', '2016-04-12 14:35:36', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('326', '2016-04-12 14:38:48', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('327', '2016-04-12 14:58:26', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('328', '2016-04-13 09:08:01', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('329', '2016-04-13 13:45:05', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('330', '2016-04-13 15:56:42', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('331', '2016-04-13 16:15:34', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('332', '2016-04-13 16:54:36', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('333', '2016-04-13 17:21:06', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('334', '2016-04-13 17:21:11', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('335', '2016-04-13 17:29:06', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('336', '2016-04-13 17:33:29', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('337', '2016-04-13 17:43:43', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('338', '2016-04-13 17:44:24', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('339', '2016-04-13 17:46:06', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('340', '2016-04-14 09:04:03', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('341', '2016-04-14 14:20:29', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('342', '2016-04-14 18:38:50', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('343', '2016-04-15 09:08:09', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('344', '2016-04-15 11:33:42', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('345', '2016-04-15 11:55:07', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('346', '2016-04-15 14:50:19', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('347', '2016-04-15 16:31:13', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('348', '2016-04-15 17:30:08', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('349', '2016-04-18 15:53:50', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('350', '2016-04-18 15:56:03', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('351', '2016-04-18 16:06:46', '192.168.1.114', '2', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('352', '2016-04-18 16:07:32', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('353', '2016-04-18 16:08:08', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('354', '2016-04-18 16:08:23', '192.168.1.114', '2', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('355', '2016-04-18 16:27:59', '192.168.1.114', '2', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('356', '2016-04-18 16:55:20', '192.168.1.114', '2', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('357', '2016-04-18 16:59:28', '192.168.1.114', '2', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('358', '2016-04-18 17:36:26', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('359', '2016-04-18 18:09:35', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('360', '2016-04-18 18:25:56', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('361', '2016-04-18 18:33:43', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('362', '2016-04-18 19:22:31', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('363', '2016-04-18 19:27:55', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('364', '2016-04-19 09:07:06', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('365', '2016-04-19 09:36:47', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('366', '2016-04-19 09:46:35', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('367', '2016-04-19 09:48:20', '192.168.1.114', '2', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('368', '2016-04-19 09:51:31', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('369', '2016-04-19 10:22:37', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('370', '2016-04-19 10:53:51', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('371', '2016-04-19 10:55:27', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('372', '2016-04-22 18:21:58', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('373', '2016-04-22 18:35:17', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('374', '2016-04-22 18:52:10', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('375', '2016-04-22 19:10:30', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('376', '2016-04-22 19:12:05', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('377', '2016-04-23 09:24:14', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('378', '2016-04-23 09:30:15', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('379', '2016-04-23 09:48:57', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('380', '2016-04-23 10:02:43', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('381', '2016-04-23 10:06:08', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('382', '2016-04-23 10:08:58', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('383', '2016-04-23 10:19:02', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('384', '2016-04-23 10:44:11', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('385', '2016-04-23 15:18:18', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('386', '2016-04-25 10:19:28', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('387', '2016-04-25 18:50:17', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('388', '2016-04-27 14:36:46', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('389', '2016-04-27 15:21:59', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('390', '2016-04-27 17:21:48', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('391', '2016-04-27 17:27:51', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('392', '2016-04-27 17:29:39', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('393', '2016-04-27 17:54:58', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('394', '2016-04-27 17:59:38', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('395', '2016-04-27 18:26:24', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('396', '2016-04-27 18:57:21', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('397', '2016-04-28 09:35:57', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('398', '2016-04-28 10:35:46', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('399', '2016-04-28 11:07:17', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('400', '2016-04-28 15:17:34', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('401', '2016-04-28 17:34:33', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('402', '2016-04-28 19:19:42', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('403', '2016-04-29 09:54:58', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('404', '2016-04-29 10:21:22', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('405', '2016-04-29 11:57:07', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('406', '2016-05-03 14:40:45', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('407', '2016-05-03 19:04:57', '192.168.1.114', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('408', '2016-05-03 19:17:35', '192.168.1.114', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('409', '2016-05-04 09:14:34', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('410', '2016-05-04 10:19:02', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('411', '2016-05-04 10:35:24', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('412', '2016-05-04 11:07:06', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('413', '2016-05-04 11:12:08', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('414', '2016-05-04 11:41:30', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('415', '2016-05-05 09:13:06', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('416', '2016-05-05 09:49:17', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('417', '2016-05-05 15:30:29', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('418', '2016-05-06 09:04:12', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('419', '2016-05-06 09:12:22', '192.168.1.123', '2', 'windows 7', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('420', '2016-05-06 10:02:03', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('421', '2016-05-06 10:10:23', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('422', '2016-05-06 11:44:42', '192.168.1.123', '2', 'windows 7', 'chrome');
INSERT INTO `sys_login_log` VALUES ('423', '2016-05-06 13:36:43', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('424', '2016-05-06 13:52:03', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('425', '2016-05-06 14:23:49', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('426', '2016-05-06 18:08:11', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('427', '2016-05-07 16:20:55', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('428', '2016-05-09 08:53:52', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('429', '2016-05-09 10:29:25', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('430', '2016-05-09 10:42:24', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('431', '2016-05-09 11:08:05', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('432', '2016-05-09 11:23:12', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('433', '2016-05-09 11:23:42', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('434', '2016-05-09 11:44:07', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('435', '2016-05-09 11:45:21', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('436', '2016-05-09 14:01:28', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('437', '2016-05-09 14:21:19', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('438', '2016-05-09 14:28:51', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('439', '2016-05-09 14:52:31', '192.168.1.114', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('440', '2016-05-09 15:04:10', '192.168.1.114', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('441', '2016-05-09 15:06:52', '192.168.1.114', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('442', '2016-05-09 15:07:22', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('443', '2016-05-09 15:07:26', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('444', '2016-05-09 15:07:34', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('445', '2016-05-09 15:07:46', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('446', '2016-05-09 15:07:51', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('447', '2016-05-09 15:08:07', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('448', '2016-05-09 15:09:36', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('449', '2016-05-09 15:09:44', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('450', '2016-05-09 15:10:04', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('451', '2016-05-09 15:15:36', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('452', '2016-05-09 15:15:41', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('453', '2016-05-09 15:16:01', '192.168.1.114', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('454', '2016-05-09 15:18:18', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('455', '2016-05-09 15:19:20', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('456', '2016-05-09 15:20:16', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('457', '2016-05-09 15:20:43', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('458', '2016-05-09 17:42:47', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('459', '2016-05-09 17:55:35', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('460', '2016-05-09 18:00:30', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('461', '2016-05-09 18:16:01', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('462', '2016-05-09 18:18:12', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('463', '2016-05-10 08:57:52', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('464', '2016-05-10 09:26:34', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('465', '2016-05-10 09:26:38', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('466', '2016-05-10 09:26:45', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('467', '2016-05-10 09:26:59', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('468', '2016-05-10 09:27:13', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('469', '2016-05-10 09:28:01', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('470', '2016-05-10 09:28:19', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('471', '2016-05-10 09:28:45', '192.168.1.114', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('472', '2016-05-10 09:28:55', '192.168.1.114', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('473', '2016-05-10 09:30:30', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('474', '2016-05-10 09:47:01', '192.168.1.114', '2', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('475', '2016-05-10 09:47:56', '192.168.1.114', '2', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('476', '2016-05-10 10:10:07', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('477', '2016-05-10 10:16:19', '192.168.1.114', '2', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('478', '2016-05-10 10:22:24', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('479', '2016-05-10 10:44:05', '192.168.1.114', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('480', '2016-05-10 11:13:35', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('481', '2016-05-10 11:18:01', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('482', '2016-05-10 11:22:55', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('483', '2016-05-10 14:39:49', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('484', '2016-05-10 14:56:32', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('485', '2016-05-10 17:39:18', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('486', '2016-05-10 18:53:33', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('487', '2016-05-11 09:55:11', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('488', '2016-05-11 15:27:44', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('489', '2016-05-11 16:46:02', '192.168.110.16', '1', 'windows 7', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('490', '2016-05-11 17:07:44', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('491', '2016-05-11 17:13:10', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('492', '2016-05-11 17:17:44', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('493', '2016-05-11 17:24:35', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('494', '2016-05-11 17:33:02', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('495', '2016-05-11 17:36:32', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('496', '2016-05-11 17:58:02', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('497', '2016-05-12 09:20:07', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('498', '2016-05-12 09:46:54', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('499', '2016-05-12 11:18:54', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('500', '2016-05-12 14:21:52', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('501', '2016-05-12 15:49:01', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('502', '2016-05-13 16:33:55', '192.168.1.116', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('503', '2016-05-21 17:47:53', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('504', '2016-05-21 18:03:41', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('505', '2016-05-21 18:40:26', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('506', '2016-05-21 18:48:21', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('507', '2016-05-21 18:58:07', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('508', '2016-05-21 19:00:24', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('509', '2016-05-21 19:05:07', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('510', '2016-05-21 19:07:09', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('511', '2016-05-21 19:09:03', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('512', '2016-05-21 19:13:22', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('513', '2016-05-21 19:16:33', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('514', '2016-05-21 19:18:58', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('515', '2016-05-21 19:20:02', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('516', '2016-05-21 19:28:10', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('517', '2016-05-21 19:30:03', '192.168.1.114', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('518', '2016-05-21 21:12:34', '192.168.31.240', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('519', '2016-05-21 21:46:00', '192.168.31.240', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('520', '2016-05-21 22:27:49', '192.168.31.240', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('521', '2016-05-21 22:51:25', '192.168.31.240', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('522', '2016-05-21 22:51:54', '192.168.31.240', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('523', '2016-05-21 23:29:25', '192.168.31.240', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('524', '2016-05-21 23:33:42', '192.168.31.240', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('525', '2016-05-21 23:34:28', '192.168.31.240', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('526', '2016-05-21 23:37:57', '192.168.31.240', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('527', '2016-05-21 23:59:41', '192.168.31.240', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('528', '2016-05-22 00:00:01', '192.168.31.240', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('529', '2016-05-26 13:15:45', '192.168.199.241', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('530', '2016-05-26 13:46:27', '192.168.199.241', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('531', '2016-05-26 13:47:45', '192.168.199.241', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('532', '2016-05-26 15:03:51', '192.168.199.213', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('533', '2016-05-26 15:24:15', '192.168.199.241', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('534', '2016-05-26 16:28:25', '192.168.199.213', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('535', '2016-05-26 17:04:53', '192.168.245.1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('536', '2016-05-26 17:22:50', '192.168.245.1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('537', '2016-05-26 17:23:45', '192.168.245.1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('538', '2016-05-26 17:29:34', '192.168.245.1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('539', '2016-05-26 17:38:18', '192.168.245.1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('540', '2016-05-26 17:58:41', '192.168.199.213', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('541', '2016-05-26 18:01:09', '192.168.199.213', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('542', '2016-05-26 18:05:35', '192.168.199.213', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('543', '2016-05-26 18:06:42', '192.168.199.213', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('544', '2016-05-26 18:08:13', '192.168.199.213', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('545', '2016-05-26 18:10:02', '192.168.199.213', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('546', '2016-05-26 18:12:23', '192.168.199.213', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('547', '2016-05-26 18:15:23', '192.168.199.213', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('548', '2016-05-26 18:16:25', '192.168.245.1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('549', '2016-05-26 18:17:50', '192.168.199.213', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('550', '2016-05-27 09:15:20', '192.168.245.1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('551', '2016-05-27 09:19:53', '192.168.245.1', '2', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('552', '2016-05-27 09:20:06', '192.168.245.1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('553', '2016-05-27 09:56:01', '192.168.245.1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('554', '2016-05-27 09:56:25', '192.168.245.1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('555', '2016-05-27 09:59:55', '192.168.245.1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('556', '2016-05-27 10:15:18', '192.168.245.1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('557', '2016-05-27 10:19:23', '192.168.245.1', '2', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('558', '2016-05-27 10:25:16', '192.168.245.1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('559', '2016-05-27 10:30:58', '192.168.245.1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('560', '2016-05-27 10:34:51', '192.168.245.1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('561', '2016-05-27 10:37:28', '192.168.245.1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('562', '2016-05-27 10:41:59', '192.168.245.1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('563', '2016-05-27 11:07:07', '192.168.245.1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('564', '2016-05-27 11:11:56', '192.168.245.1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('565', '2016-05-27 11:20:15', '192.168.245.1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('566', '2016-05-27 11:23:09', '192.168.245.1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('567', '2016-05-27 11:34:33', '192.168.199.241', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('568', '2016-10-13 15:28:38', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('569', '2016-10-13 15:29:41', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('570', '2016-10-13 15:33:39', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('571', '2016-10-27 09:14:31', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('572', '2016-10-27 10:47:05', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('573', '2016-10-27 17:33:03', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('574', '2016-10-27 19:01:36', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('575', '2016-10-27 19:09:38', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('576', '2016-10-27 19:12:50', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('577', '2016-10-27 19:16:53', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('578', '2016-10-27 19:22:19', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('579', '2016-10-27 19:23:16', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('580', '2016-10-27 19:25:45', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('581', '2016-10-27 19:33:32', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('582', '2016-10-27 19:34:29', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('583', '2016-10-27 19:37:35', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('584', '2016-10-27 19:38:24', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('585', '2016-10-27 19:43:37', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('586', '2016-10-27 20:10:01', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('587', '2016-10-27 20:16:35', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('588', '2016-10-27 20:31:25', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('589', '2016-10-28 09:52:00', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('590', '2016-10-28 10:11:58', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('591', '2016-10-28 10:40:21', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('592', '2016-10-28 11:18:31', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('593', '2016-10-28 11:20:43', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('594', '2016-10-28 11:46:10', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('595', '2016-10-31 11:24:22', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('596', '2016-10-31 11:32:08', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('597', '2016-11-02 11:43:39', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('598', '2016-11-03 08:51:02', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('599', '2016-11-03 19:15:26', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('600', '2016-11-03 19:18:46', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('601', '2016-11-03 20:14:41', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('602', '2016-11-04 09:29:42', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('603', '2016-11-04 09:30:39', '192.168.199.191', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('604', '2016-11-04 10:12:51', '192.168.199.191', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('605', '2016-11-04 10:18:23', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('606', '2016-11-04 11:20:52', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('607', '2016-11-04 11:53:42', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('608', '2016-11-09 13:16:02', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('609', '2016-11-09 13:34:31', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('610', '2016-11-09 14:21:30', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('611', '2016-11-09 16:04:08', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('612', '2016-11-09 17:29:13', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('613', '2016-11-09 17:33:52', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('614', '2016-11-09 17:38:54', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('615', '2016-11-09 18:26:14', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('616', '2016-11-09 18:37:59', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('617', '2016-11-09 18:39:59', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('618', '2016-11-09 18:41:43', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('619', '2016-11-10 10:25:21', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('620', '2016-11-10 10:41:47', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('621', '2016-11-10 10:44:07', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('622', '2016-11-10 10:56:17', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('623', '2016-11-10 10:59:57', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('624', '2016-11-10 13:22:35', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('625', '2016-11-10 13:26:24', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('626', '2016-11-10 13:37:13', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('627', '2016-11-10 13:38:45', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('628', '2016-11-10 13:42:07', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('629', '2016-11-10 13:45:17', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('630', '2016-11-10 14:00:15', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('631', '2016-11-10 14:07:43', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('632', '2016-11-10 14:19:17', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('633', '2016-11-10 14:22:50', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('634', '2016-11-10 14:25:34', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('635', '2016-11-10 14:30:17', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('636', '2016-11-10 14:37:16', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('637', '2016-11-10 14:39:29', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('638', '2016-11-10 14:42:56', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('639', '2016-11-10 14:47:10', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('640', '2016-11-10 14:49:47', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('641', '2016-11-10 16:35:54', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('642', '2016-11-10 17:02:47', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('643', '2016-11-10 17:25:52', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('644', '2016-11-10 18:02:49', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('645', '2016-11-10 18:11:53', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('646', '2016-11-10 18:16:47', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('647', '2016-11-10 18:52:16', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('648', '2016-11-10 18:54:12', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('649', '2016-11-10 19:26:51', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('650', '2016-11-10 19:36:56', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('651', '2016-11-10 19:39:22', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('652', '2016-11-10 19:44:21', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('653', '2016-11-10 20:09:21', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('654', '2016-11-11 13:56:21', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('655', '2016-11-11 14:33:03', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('656', '2016-11-11 17:23:36', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('657', '2016-11-11 17:32:06', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('658', '2016-11-11 19:57:34', '114.249.227.154', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('659', '2016-11-11 20:03:50', '114.249.227.154', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('660', '2016-11-11 20:08:50', '114.249.227.154', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('661', '2016-11-11 20:19:39', '114.249.227.154', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('662', '2016-11-15 13:56:06', '114.249.208.216', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('663', '2016-11-15 13:57:24', '114.249.208.216', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('664', '2016-11-15 13:57:53', '114.249.208.216', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('665', '2016-11-15 14:03:00', '114.249.208.216', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('666', '2016-11-15 14:05:09', '114.249.208.216', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('667', '2016-11-15 14:15:11', '114.249.208.216', '1', 'mac os x', 'safari');
INSERT INTO `sys_login_log` VALUES ('668', '2016-11-15 14:35:56', '114.249.208.216', '1', 'mac os x', 'safari');
INSERT INTO `sys_login_log` VALUES ('669', '2016-11-15 14:42:05', '114.249.208.216', '1', 'mac os x', 'safari');
INSERT INTO `sys_login_log` VALUES ('670', '2016-11-15 15:46:35', '114.249.208.216', '1', 'mac os x', 'safari');
INSERT INTO `sys_login_log` VALUES ('671', '2016-11-15 15:47:42', '114.249.208.216', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('672', '2016-11-15 15:48:38', '114.249.208.216', '1', 'mac os x', 'safari');
INSERT INTO `sys_login_log` VALUES ('673', '2016-11-15 15:49:51', '114.249.208.216', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('674', '2016-11-15 15:50:46', '114.249.208.216', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('675', '2016-11-15 16:18:37', '114.249.208.216', '1', 'mac os x', 'safari');
INSERT INTO `sys_login_log` VALUES ('676', '2016-11-15 16:19:35', '114.249.208.216', '1', 'mac os x', 'safari');
INSERT INTO `sys_login_log` VALUES ('677', '2016-11-15 16:20:11', '114.249.208.216', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('678', '2016-11-15 16:22:35', '114.249.208.216', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('679', '2016-11-15 16:22:44', '114.249.208.216', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('680', '2016-11-15 16:41:11', '114.249.208.216', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('681', '2016-11-15 16:42:14', '114.249.208.216', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('682', '2016-11-15 16:46:12', '114.249.208.216', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('683', '2016-11-15 16:48:50', '114.249.208.216', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('684', '2016-11-15 17:42:04', '114.249.208.216', '1', 'mac os x', 'safari');
INSERT INTO `sys_login_log` VALUES ('685', '2016-11-15 18:22:26', '114.249.208.216', '1', 'mac os x', 'safari');
INSERT INTO `sys_login_log` VALUES ('686', '2016-11-16 10:10:34', '221.221.157.95', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('687', '2016-11-16 10:10:49', '221.221.157.95', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('688', '2016-11-16 10:12:24', '221.221.157.95', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('689', '2016-11-16 10:26:31', '221.221.157.95', '1', 'mac os x', 'safari');
INSERT INTO `sys_login_log` VALUES ('690', '2016-11-16 10:29:27', '221.221.157.95', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('691', '2016-11-16 11:31:22', '221.221.148.222', '1', 'mac os x', 'safari');
INSERT INTO `sys_login_log` VALUES ('692', '2016-11-16 17:20:22', '114.242.250.174', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('693', '2016-11-16 17:22:51', '114.242.250.174', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('694', '2016-11-16 17:23:01', '114.242.250.174', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('695', '2016-11-16 17:24:17', '114.242.250.174', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('696', '2016-11-16 17:24:29', '114.242.250.174', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('697', '2016-11-18 11:50:25', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('698', '2016-11-18 11:52:32', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('699', '2016-11-18 14:13:58', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('700', '2016-11-18 14:24:04', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('701', '2016-11-18 14:28:25', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('702', '2016-11-18 14:38:01', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('703', '2016-11-18 14:39:57', '0:0:0:0:0:0:0:1', '1', 'windows', 'firefox 4');
INSERT INTO `sys_login_log` VALUES ('704', '2016-11-18 15:30:27', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('705', '2016-11-18 17:07:20', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');
INSERT INTO `sys_login_log` VALUES ('706', '2016-11-18 17:09:26', '0:0:0:0:0:0:0:1', '1', 'windows', 'chrome');

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role` (
  `ROLE_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `ROLE_NAME` varchar(100) DEFAULT NULL COMMENT '角色名',
  `CREATE_TIME` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`ROLE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='角色表';

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES ('1', '系统管理员', '2015-03-18 08:00:00');
INSERT INTO `sys_role` VALUES ('2', '老师', '2015-03-18 17:53:32');
INSERT INTO `sys_role` VALUES ('3', '普通管理员', '2015-03-18 18:13:16');
INSERT INTO `sys_role` VALUES ('4', '销售', '2016-01-14 11:09:05');

-- ----------------------------
-- Table structure for sys_role_function
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_function`;
CREATE TABLE `sys_role_function` (
  `ROLE_ID` int(11) DEFAULT '0' COMMENT '角色ID',
  `FUNCTION_ID` int(11) DEFAULT '0' COMMENT '权限ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色权限关联表';

-- ----------------------------
-- Records of sys_role_function
-- ----------------------------
INSERT INTO `sys_role_function` VALUES ('8', '17');
INSERT INTO `sys_role_function` VALUES ('8', '18');
INSERT INTO `sys_role_function` VALUES ('8', '20');
INSERT INTO `sys_role_function` VALUES ('8', '21');
INSERT INTO `sys_role_function` VALUES ('2', '63');
INSERT INTO `sys_role_function` VALUES ('2', '64');
INSERT INTO `sys_role_function` VALUES ('2', '65');
INSERT INTO `sys_role_function` VALUES ('2', '66');
INSERT INTO `sys_role_function` VALUES ('2', '61');
INSERT INTO `sys_role_function` VALUES ('2', '62');
INSERT INTO `sys_role_function` VALUES ('2', '80');
INSERT INTO `sys_role_function` VALUES ('2', '81');
INSERT INTO `sys_role_function` VALUES ('3', '45');
INSERT INTO `sys_role_function` VALUES ('3', '18');
INSERT INTO `sys_role_function` VALUES ('3', '21');
INSERT INTO `sys_role_function` VALUES ('3', '36');
INSERT INTO `sys_role_function` VALUES ('3', '38');
INSERT INTO `sys_role_function` VALUES ('3', '73');
INSERT INTO `sys_role_function` VALUES ('3', '76');
INSERT INTO `sys_role_function` VALUES ('3', '77');
INSERT INTO `sys_role_function` VALUES ('3', '74');
INSERT INTO `sys_role_function` VALUES ('3', '75');
INSERT INTO `sys_role_function` VALUES ('3', '39');
INSERT INTO `sys_role_function` VALUES ('3', '40');
INSERT INTO `sys_role_function` VALUES ('3', '46');
INSERT INTO `sys_role_function` VALUES ('3', '47');
INSERT INTO `sys_role_function` VALUES ('3', '59');
INSERT INTO `sys_role_function` VALUES ('3', '60');
INSERT INTO `sys_role_function` VALUES ('3', '50');
INSERT INTO `sys_role_function` VALUES ('3', '56');
INSERT INTO `sys_role_function` VALUES ('3', '57');
INSERT INTO `sys_role_function` VALUES ('3', '58');
INSERT INTO `sys_role_function` VALUES ('4', '30');
INSERT INTO `sys_role_function` VALUES ('4', '32');
INSERT INTO `sys_role_function` VALUES ('4', '79');
INSERT INTO `sys_role_function` VALUES ('4', '82');
INSERT INTO `sys_role_function` VALUES ('4', '49');
INSERT INTO `sys_role_function` VALUES ('4', '51');
INSERT INTO `sys_role_function` VALUES ('4', '68');
INSERT INTO `sys_role_function` VALUES ('4', '100');
INSERT INTO `sys_role_function` VALUES ('4', '95');
INSERT INTO `sys_role_function` VALUES ('4', '96');
INSERT INTO `sys_role_function` VALUES ('4', '99');
INSERT INTO `sys_role_function` VALUES ('4', '63');
INSERT INTO `sys_role_function` VALUES ('4', '64');
INSERT INTO `sys_role_function` VALUES ('4', '65');
INSERT INTO `sys_role_function` VALUES ('4', '66');
INSERT INTO `sys_role_function` VALUES ('4', '61');
INSERT INTO `sys_role_function` VALUES ('4', '62');
INSERT INTO `sys_role_function` VALUES ('4', '80');
INSERT INTO `sys_role_function` VALUES ('4', '81');
INSERT INTO `sys_role_function` VALUES ('4', '107');
INSERT INTO `sys_role_function` VALUES ('4', '36');
INSERT INTO `sys_role_function` VALUES ('4', '37');
INSERT INTO `sys_role_function` VALUES ('4', '69');
INSERT INTO `sys_role_function` VALUES ('4', '70');
INSERT INTO `sys_role_function` VALUES ('4', '71');
INSERT INTO `sys_role_function` VALUES ('4', '72');
INSERT INTO `sys_role_function` VALUES ('4', '202');
INSERT INTO `sys_role_function` VALUES ('4', '42');
INSERT INTO `sys_role_function` VALUES ('4', '43');
INSERT INTO `sys_role_function` VALUES ('4', '83');
INSERT INTO `sys_role_function` VALUES ('4', '84');
INSERT INTO `sys_role_function` VALUES ('4', '44');
INSERT INTO `sys_role_function` VALUES ('4', '239');
INSERT INTO `sys_role_function` VALUES ('4', '241');
INSERT INTO `sys_role_function` VALUES ('4', '242');
INSERT INTO `sys_role_function` VALUES ('4', '240');
INSERT INTO `sys_role_function` VALUES ('1', '201');
INSERT INTO `sys_role_function` VALUES ('1', '45');
INSERT INTO `sys_role_function` VALUES ('1', '18');
INSERT INTO `sys_role_function` VALUES ('1', '20');
INSERT INTO `sys_role_function` VALUES ('1', '21');
INSERT INTO `sys_role_function` VALUES ('1', '22');
INSERT INTO `sys_role_function` VALUES ('1', '23');
INSERT INTO `sys_role_function` VALUES ('1', '19');
INSERT INTO `sys_role_function` VALUES ('1', '26');
INSERT INTO `sys_role_function` VALUES ('1', '24');
INSERT INTO `sys_role_function` VALUES ('1', '25');
INSERT INTO `sys_role_function` VALUES ('1', '31');
INSERT INTO `sys_role_function` VALUES ('1', '33');
INSERT INTO `sys_role_function` VALUES ('1', '34');
INSERT INTO `sys_role_function` VALUES ('1', '35');
INSERT INTO `sys_role_function` VALUES ('1', '137');
INSERT INTO `sys_role_function` VALUES ('1', '138');
INSERT INTO `sys_role_function` VALUES ('1', '30');
INSERT INTO `sys_role_function` VALUES ('1', '32');
INSERT INTO `sys_role_function` VALUES ('1', '79');
INSERT INTO `sys_role_function` VALUES ('1', '82');
INSERT INTO `sys_role_function` VALUES ('1', '49');
INSERT INTO `sys_role_function` VALUES ('1', '51');
INSERT INTO `sys_role_function` VALUES ('1', '68');
INSERT INTO `sys_role_function` VALUES ('1', '100');
INSERT INTO `sys_role_function` VALUES ('1', '95');
INSERT INTO `sys_role_function` VALUES ('1', '96');
INSERT INTO `sys_role_function` VALUES ('1', '99');
INSERT INTO `sys_role_function` VALUES ('1', '139');
INSERT INTO `sys_role_function` VALUES ('1', '108');
INSERT INTO `sys_role_function` VALUES ('1', '109');
INSERT INTO `sys_role_function` VALUES ('1', '110');
INSERT INTO `sys_role_function` VALUES ('1', '114');
INSERT INTO `sys_role_function` VALUES ('1', '115');
INSERT INTO `sys_role_function` VALUES ('1', '116');
INSERT INTO `sys_role_function` VALUES ('1', '117');
INSERT INTO `sys_role_function` VALUES ('1', '118');
INSERT INTO `sys_role_function` VALUES ('1', '150');
INSERT INTO `sys_role_function` VALUES ('1', '151');
INSERT INTO `sys_role_function` VALUES ('1', '152');
INSERT INTO `sys_role_function` VALUES ('1', '153');
INSERT INTO `sys_role_function` VALUES ('1', '206');
INSERT INTO `sys_role_function` VALUES ('1', '63');
INSERT INTO `sys_role_function` VALUES ('1', '64');
INSERT INTO `sys_role_function` VALUES ('1', '65');
INSERT INTO `sys_role_function` VALUES ('1', '66');
INSERT INTO `sys_role_function` VALUES ('1', '61');
INSERT INTO `sys_role_function` VALUES ('1', '62');
INSERT INTO `sys_role_function` VALUES ('1', '80');
INSERT INTO `sys_role_function` VALUES ('1', '81');
INSERT INTO `sys_role_function` VALUES ('1', '107');
INSERT INTO `sys_role_function` VALUES ('1', '209');
INSERT INTO `sys_role_function` VALUES ('1', '36');
INSERT INTO `sys_role_function` VALUES ('1', '37');
INSERT INTO `sys_role_function` VALUES ('1', '69');
INSERT INTO `sys_role_function` VALUES ('1', '70');
INSERT INTO `sys_role_function` VALUES ('1', '71');
INSERT INTO `sys_role_function` VALUES ('1', '72');
INSERT INTO `sys_role_function` VALUES ('1', '39');
INSERT INTO `sys_role_function` VALUES ('1', '40');
INSERT INTO `sys_role_function` VALUES ('1', '97');
INSERT INTO `sys_role_function` VALUES ('1', '98');
INSERT INTO `sys_role_function` VALUES ('1', '154');
INSERT INTO `sys_role_function` VALUES ('1', '155');
INSERT INTO `sys_role_function` VALUES ('1', '156');
INSERT INTO `sys_role_function` VALUES ('1', '214');
INSERT INTO `sys_role_function` VALUES ('1', '219');
INSERT INTO `sys_role_function` VALUES ('1', '215');
INSERT INTO `sys_role_function` VALUES ('1', '216');
INSERT INTO `sys_role_function` VALUES ('1', '217');
INSERT INTO `sys_role_function` VALUES ('1', '244');

-- ----------------------------
-- Table structure for sys_subject
-- ----------------------------
DROP TABLE IF EXISTS `sys_subject`;
CREATE TABLE `sys_subject` (
  `SUBJECT_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `SUBJECT_NAME` varchar(50) NOT NULL DEFAULT '' COMMENT '专业名称',
  `STATUS` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态 0:默认 1:删除',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '创建时间',
  `PARENT_ID` int(11) DEFAULT '0' COMMENT '父ID',
  `sort` int(11) DEFAULT '0' COMMENT '排序字段',
  PRIMARY KEY (`SUBJECT_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=252 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='专业信息';

-- ----------------------------
-- Records of sys_subject
-- ----------------------------
INSERT INTO `sys_subject` VALUES ('202', '初二', '0', '2014-03-04 09:53:03', '0', '8');
INSERT INTO `sys_subject` VALUES ('203', '职称英语', '1', '2014-03-04 09:53:24', '202', '6');
INSERT INTO `sys_subject` VALUES ('204', '英语四级', '1', '2014-03-04 09:53:38', '202', '3');
INSERT INTO `sys_subject` VALUES ('206', '英语六级', '1', '2014-03-04 09:54:10', '202', '7');
INSERT INTO `sys_subject` VALUES ('208', '高一', '0', '2014-06-15 23:33:33', '0', '6');
INSERT INTO `sys_subject` VALUES ('209', '教师', '1', '2014-06-16 14:00:10', '208', '0');
INSERT INTO `sys_subject` VALUES ('210', '高二', '0', '2014-06-26 09:37:33', '0', '5');
INSERT INTO `sys_subject` VALUES ('211', '行测', '1', '2014-06-26 09:37:59', '210', '0');
INSERT INTO `sys_subject` VALUES ('213', '面试', '1', '2014-06-26 09:38:21', '210', '0');
INSERT INTO `sys_subject` VALUES ('214', '其他', '1', '2014-06-26 09:38:29', '210', '0');
INSERT INTO `sys_subject` VALUES ('215', '幼儿', '1', '2014-06-26 09:39:36', '209', '0');
INSERT INTO `sys_subject` VALUES ('216', '小学', '1', '2014-06-26 09:39:47', '208', '0');
INSERT INTO `sys_subject` VALUES ('217', '初中', '1', '2014-06-26 09:39:55', '208', '5');
INSERT INTO `sys_subject` VALUES ('218', '高中', '1', '2014-06-26 09:40:05', '208', '6');
INSERT INTO `sys_subject` VALUES ('221', '初三', '0', '2014-06-26 09:41:21', '0', '7');
INSERT INTO `sys_subject` VALUES ('222', '游戏开发', '1', '2014-06-26 09:41:32', '221', '0');
INSERT INTO `sys_subject` VALUES ('223', '初一', '0', '2014-06-26 09:41:41', '0', '9');
INSERT INTO `sys_subject` VALUES ('224', '高三', '0', '2014-06-26 09:41:51', '0', '4');
INSERT INTO `sys_subject` VALUES ('247', '新建专业', '1', '2015-09-10 10:32:19', '224', '0');
INSERT INTO `sys_subject` VALUES ('248', '新建专业', '1', '2015-09-10 10:34:50', '247', '0');
INSERT INTO `sys_subject` VALUES ('249', '新建专业', '1', '2015-09-10 10:34:56', '247', '0');
INSERT INTO `sys_subject` VALUES ('250', 'window', '1', '2015-09-10 10:35:07', '224', '0');
INSERT INTO `sys_subject` VALUES ('251', 'mysql', '1', '2015-09-10 10:35:56', '223', '0');

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `USER_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `LOGIN_NAME` varchar(20) NOT NULL DEFAULT '' COMMENT '登录名',
  `LOGIN_PWD` varchar(32) NOT NULL DEFAULT '' COMMENT '登录密码',
  `USER_NAME` varchar(50) DEFAULT NULL COMMENT '用户真实姓名名',
  `STATUS` tinyint(1) DEFAULT '0' COMMENT '状态.0: 正常,1:冻结,2：删除',
  `LAST_LOGIN_TIME` timestamp NULL DEFAULT NULL COMMENT '最后登录时间',
  `LAST_LOGIN_IP` varchar(20) DEFAULT NULL COMMENT '最后登录IP',
  `CREATE_TIME` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `EMAIL` varchar(50) DEFAULT NULL COMMENT '邮件地址',
  `TEL` varchar(12) DEFAULT NULL COMMENT '手机号码',
  `ROLE_ID` int(11) DEFAULT '0' COMMENT '所属角色ID',
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='系统用户表';

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES ('1', 'admin', '96e79218965eb72c92a549dd5a330112', '管理员', '0', '2016-11-18 17:09:26', '0:0:0:0:0:0:0:1', '2015-03-17 01:45:46', 'inxedu@gukeer.cc', '18688888888', '1');
INSERT INTO `sys_user` VALUES ('2', 'inxedu', '96e79218965eb72c92a549dd5a330112', '谷壳销售', '0', '2016-05-27 10:19:23', '192.168.245.1', '2015-03-17 01:45:46', 'inxedu2@gukeer.cc', '16888888888', '4');
INSERT INTO `sys_user` VALUES ('3', 'test', '96e79218965eb72c92a549dd5a330112', null, '2', null, null, null, null, null, '0');
